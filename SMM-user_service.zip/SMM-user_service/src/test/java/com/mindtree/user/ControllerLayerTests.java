package com.mindtree.user;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.user.controller.UserController;
import com.mindtree.user.entity.User;
import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserListResponse;
import com.mindtree.user.service.UserHateoasService;
import com.mindtree.user.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerLayerTests {
	
	@Mock
	UserService service;
	
	@Mock
	UserHateoasService hateoas;
	
	@InjectMocks
	@Spy
	UserController controller;
	
	@Test
	public void allUsersTest()
	{
		UserListResponse response=new UserListResponse();
		response.setStatus_code(200);
		when(service.getAllUsers()).thenReturn(response);
		assertEquals(200, controller.allUsers().getStatus_code());
	}
	
	@Test
	public void getByUsernameAdminTest()
	{
		User user=new User();
		user.setUsername("user@name.com");
		when(service.getByUsernameAdmin(user.getUsername())).thenReturn(Optional.of(user));
		assertEquals(Optional.of(user), controller.getByUsernameAdmin(user.getUsername()));
	}
	
	@Test
	public void registerTest()
	{
		Response response=new Response();
		response.setStatus_code(200);
		response.setMessage("Success");
		User user=new User();
		when(service.registerUser(user)).thenReturn(response);
		when(hateoas.registerUser(response)).thenReturn(new Resource<Response>(response));
		assertEquals(200, controller.register(user).getContent().getStatus_code());
	}
}