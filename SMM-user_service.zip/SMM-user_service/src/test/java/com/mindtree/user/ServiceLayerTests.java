package com.mindtree.user;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.user.dao.UserDao;
import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.service.impl.UserServiceImpl;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTests extends TestCase {

	@Mock
	private UserDao dao;
	
	@Mock
	PasswordEncoder encoder;
	
	@Mock
	Authentication auth;

	@InjectMocks
	@Spy
	private UserServiceImpl service;

	@Test
	public void getAllUsersTest1() {

		List<User> list = new ArrayList<User>();

		User user = new User();
		user.setUsername("Username");
		user.setName("name");
		user.setEnable(true);
		user.setMobile(1234567890);
		user.setPassword("password");

		list.add(user);

		try {
			when(dao.getAllUsers()).thenReturn(list);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(200, service.getAllUsers().getStatus_code());
	}

	@Test
	public void getAllUsersTest2() {

		List<User> list = new ArrayList<User>();

		try {
			when(dao.getAllUsers()).thenReturn(list);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getAllUsers().getStatus_code());
	}

	@Test
	public void getAllUsersTest3() {

		try {
			when(dao.getAllUsers()).thenThrow(new SQLException());
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getAllUsers().getStatus_code());
	}
	
	@Test
	public void getByUsernameTest1()
	{
		String username="hi@user.com";
		Optional<User> user = Optional.of(new User());
		user.get().setUsername(username);
		user.get().setPassword("password");
		user.get().setName("User");
		user.get().setMobile(1234567890);
		user.get().setEnable(true);
		user.get().setAddress(null);
		
		try {
			when(dao.getByUsername(username)).thenReturn(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, service.getByUsername(username).getStatus_code());
	}
	
	@Test
	public void getByUsernameTest2()
	{
		String username="hi@user.com";
		Optional<User> user = Optional.of(new User());
		user.get().setUsername("hi@usr.com");
		user.get().setPassword("password");
		user.get().setName("User");
		user.get().setMobile(1234567890);
		user.get().setEnable(false);
		user.get().setAddress(null);
		
		try {
			when(dao.getByUsername(username)).thenReturn(user);
		} catch (Exception e) { 
			e.printStackTrace();
		}
		
		assertEquals(204, service.getByUsername(username).getStatus_code());
	}
	
	@Test
	public void getByUsernameTest3()
	{
		String username="hi@user.com";
		try {
			when(dao.getByUsername(username)).thenThrow(new SQLException());
		} catch (Exception e) { 
			e.printStackTrace();
		}
		
		assertEquals(204, service.getByUsername(username).getStatus_code());
	}
	
	@Test
	public void getByUsernameAdmin1()
	{
		String username="hi@user.com";
		Optional<User> user = Optional.of(new User());
		user.get().setUsername("hi@usr.com");
		user.get().setPassword("password");
		user.get().setName("User");
		user.get().setMobile(1234567890);
		user.get().setEnable(true);
		user.get().setAddress(null);
		
		try {
			when(dao.getByUsername(username)).thenReturn(user);
		} catch (Exception e) {  
			e.printStackTrace();
		}
		
		assertNotNull(service.getByUsernameAdmin(username).get()); 
	}
	
	@Test
	public void getByUsernameAdmin2()
	{
		String username="hi@user.com";
		try {
			when(dao.getByUsername(username)).thenThrow(new SQLException());
		} catch (Exception e) {  
			e.printStackTrace();
		}
		assertEquals(null,service.getByUsernameAdmin(username));
	}
	
	@Test
	public void registerUser1()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser2()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setAddressId(101);
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser3()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser4()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser5()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("cdfgdfsg");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser6()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("user@com.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenThrow(new SQLException());
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser7()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenThrow(new SQLException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void registerUser8()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(null);
			when(encoder.encode(user.getPassword())).thenReturn(user.getPassword());
			when(dao.getByUsername(user.getUsername())).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.registerUser(user).getStatus_code());
	}
	
	@Test
	public void editProfileTest1()
	{
		String username="hi@user.com";
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.editProfile(username,user)).thenReturn(true);
			when(dao.getByUsername(username)).thenReturn(Optional.of(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200,service.editProfile(username, user).getStatus_code());
	}
	
	@Test
	public void editProfileTest2()
	{
		String username="hi@user.com";
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.editProfile(username,user)).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204,service.editProfile(username, user).getStatus_code());
	}
	
	@Test
	public void editProfileTest3()
	{
		String username="hi@user.com";
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.editProfile(username,user)).thenReturn(false);
			when(dao.getByUsername(username)).thenReturn(Optional.of(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204,service.editProfile(username, user).getStatus_code());
	}
	
	@Test
	public void editProfileTest4()
	{
		String username="hi@user.com";
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.editProfile(username,user)).thenThrow(new SQLException());
			when(dao.getByUsername(username)).thenReturn(Optional.of(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204,service.editProfile(username, user).getStatus_code());
	}
	
	@Test
	public void editProfileTest5()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		User newUser=new User();
		newUser.setAddress(address);
		newUser.setUsername("hi@usr.com");
		newUser.setName("User");
		newUser.setPassword("password");
		newUser.setEnable(true);
		newUser.setMobile(1234567890);
		
		try {
			when(dao.editProfile(user.getUsername(),newUser)).thenReturn(true);
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204,service.editProfile(user.getUsername(), newUser).getStatus_code());
	}
	
	@Test
	public void deactivateAccountTest1()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
			when(dao.deactivateAccount(user.getUsername())).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, service.deactivateAccount(user.getUsername()).getStatus_code());
	}
	
	@Test
	public void deactivateAccountTest2()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
			when(dao.deactivateAccount(user.getUsername())).thenReturn(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.deactivateAccount(user.getUsername()).getStatus_code());
	}
	
	@Test
	public void deactivateAccountTest3()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(false);
		user.setMobile(1234567890);
		
		try {
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
			when(dao.deactivateAccount(user.getUsername())).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.deactivateAccount(user.getUsername()).getStatus_code());
	}
	
	@Test
	public void deactivateAccountTest4()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.getByUsername(user.getUsername())).thenReturn(Optional.of(user));
			when(dao.deactivateAccount(user.getUsername())).thenThrow(new SQLException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.deactivateAccount(user.getUsername()).getStatus_code());
	}
	
	@Test
	public void getAddressDetails1()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.getAddressDetails(user.getUsername())).thenReturn(address);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(address, service.getAddressDetails(user.getUsername()));
	}
	
	@Test
	public void getAddressDetails2()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.getAddressDetails(user.getUsername())).thenThrow(new SQLException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(null, service.getAddressDetails(user.getUsername()));
	}
	
	@Test
	public void registerTest1()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenReturn(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		service.register(user);
	}
	
	@Test
	public void registerTest2()
	{
		User user=new User();
		UserAddress address =new UserAddress();
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Anything");
		user.setAddress(address);
		user.setUsername("hi@user.com");
		user.setName("User");
		user.setPassword("password");
		user.setEnable(true);
		user.setMobile(1234567890);
		
		try {
			when(dao.registerUser(user)).thenThrow(new SQLException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		service.register(user);
	}
}
