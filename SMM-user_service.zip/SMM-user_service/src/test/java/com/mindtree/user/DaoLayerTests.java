package com.mindtree.user;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.user.dao.impl.UserDaoImpl;
import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.utility.UserRepository;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DaoLayerTests extends TestCase {
	
	@Mock
	UserRepository repo;
	
	@InjectMocks
	@Spy
	UserDaoImpl daoImpl;
	
	@Test
	public void getAllUsersTest()
	{
		List<User> list=new ArrayList<User>();
		User user=new User();
		user.setName("name");
		user.setUsername("user@name.com");
		user.setPassword("password");
		user.setAddress(null);
		list.add(user);
		when(repo.findAll()).thenReturn(list);
		try {
			assertEquals(list, daoImpl.getAllUsers());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getByUsernameTest()
	{
		String username="user@name.com";
		User user=new User();
		user.setUsername(username);
		when(repo.findById(username)).thenReturn(Optional.of(user));
		try {
			assertEquals(Optional.of(user), daoImpl.getByUsername(username));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void registerUserTest()
	{
		User user=new User();
		user.setName("name");
		user.setUsername("user@name.com");
		user.setPassword("password");
		user.setAddress(null);
		when(repo.save(user)).thenReturn(user);
		try {
			assertEquals(user, daoImpl.registerUser(user));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void editProfileTest1()
	{
		String username="user@name.com";
		UserAddress address=new UserAddress();
		address.setState("State");
		address.setAddressId(101);
		address.setPincode(123456);
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("anything");
		User user=new User();
		user.setAddress(address);
		user.setName("name");
		user.setUsername("user@name.com");
		user.setPassword("password");
		user.setAddress(address);
		user.setMobile(1234567890);

		UserAddress newaddress=new UserAddress();
		newaddress.setState("");
		newaddress.setPincode(0);
		newaddress.setAddressline1("");
		newaddress.setArea("");
		newaddress.setCity("");
		User newuser=new User();
		newuser.setName("");
		newuser.setPassword("");
		newuser.setAddress(newaddress);
		newuser.setMobile(0);
		
		when(repo.findById(username)).thenReturn(Optional.of(user));
		when(repo.save(newuser)).thenReturn(newuser);
		try {
			assertEquals(true, daoImpl.editProfile(username, newuser));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void editProfileTest2()
	{
		String username="user@name.com";
		UserAddress address=new UserAddress();
		address.setState("State");
		address.setAddressId(101);
		address.setPincode(123456);
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("anything");
		User user=new User();
		user.setAddress(address);
		user.setName("name");
		user.setUsername("user@name.com");
		user.setPassword("password");
		user.setAddress(address);
		user.setMobile(1234567890);

		UserAddress newaddress=new UserAddress();
		newaddress.setState("KKR");
		newaddress.setPincode(987654);
		newaddress.setAddressline1("line");
		newaddress.setArea("model town");
		newaddress.setCity("bluru");
		User newuser=new User();
		newuser.setName("name");
		newuser.setPassword("password");
		newuser.setAddress(newaddress);
		user.setMobile(1234567890);
		
		when(repo.findById(username)).thenReturn(Optional.of(user));
		when(repo.save(newuser)).thenReturn(newuser);
		try {
			assertEquals(true, daoImpl.editProfile(username, newuser));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void deactivateAccountTest()
	{
		String username="user@name.com";
		User user=new User();
		user.setUsername(username);
		when(repo.findById(username)).thenReturn(Optional.of(user));
		user.setEnable(false);
		when(repo.save(user)).thenReturn(user);
		try {
			assertEquals(true, daoImpl.deactivateAccount(username));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}