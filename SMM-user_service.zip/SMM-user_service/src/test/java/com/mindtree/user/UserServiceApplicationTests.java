package com.mindtree.user;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SuppressWarnings("unused")
@SpringBootTest
@RunWith(Suite.class)
@SuiteClasses({ DaoLayerTests.class, ServiceLayerTests.class, ControllerLayerTests.class })
public class UserServiceApplicationTests {
}