package com.mindtree.user.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserResponse;

@Service
public interface UserHateoasService {

	Resource<Response> registerUser(Response response);

	Resource<UserResponse> getByUsername(UserResponse userResponse);

	Resource<Response> editProfile(Response response, String username);
}
