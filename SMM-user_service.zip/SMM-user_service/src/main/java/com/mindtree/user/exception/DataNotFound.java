package com.mindtree.user.exception;

@SuppressWarnings("serial")
public class DataNotFound extends Exception {

	public DataNotFound(String string) {
		super(string);
	}
}
