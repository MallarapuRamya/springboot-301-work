package com.mindtree.user.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;

@Service
public interface UserDao {

	public List<User> getAllUsers() throws Exception;

	public Optional<User> getByUsername(String username)throws Exception;

	public User registerUser(User user)throws Exception;

	public boolean editProfile(String username, User user_obj)throws Exception;

	public boolean deactivateAccount(String username)throws Exception;

	public UserAddress getAddressDetails(String username) throws Exception;
}
