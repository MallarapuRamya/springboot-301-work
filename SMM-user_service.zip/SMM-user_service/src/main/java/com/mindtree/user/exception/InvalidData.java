package com.mindtree.user.exception;

@SuppressWarnings("serial")
public class InvalidData extends Exception {
	public InvalidData(String string)
	{
		super(string);
	}

}
