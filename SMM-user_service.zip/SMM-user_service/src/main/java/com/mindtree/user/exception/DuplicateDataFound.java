package com.mindtree.user.exception;

@SuppressWarnings("serial")
public class DuplicateDataFound extends Exception {

	public DuplicateDataFound(String string)
	{
		super(string);
	}
}
