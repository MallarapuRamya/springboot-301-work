package com.mindtree.user.service.impl;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserResponse;
import com.mindtree.user.service.UserHateoasService;

@Service
public class UserServiceHateoasImpl implements UserHateoasService {

	@Value("${baseurl}")
	String endpoint;

	Logger LOG = Logger.getLogger(UserServiceHateoasImpl.class);

	@Override
	public Resource<Response> registerUser(Response response) {

		Resource<Response> resource = new Resource<Response>(response);

		if (response.getStatus_code() == 204) {
			return resource;
		}
		return resource;
	}

	@Override
	public Resource<UserResponse> getByUsername(UserResponse userResponse) {

		Resource<UserResponse> resource = new Resource<UserResponse>(userResponse);

		if (userResponse.getStatus_code() == 204) {
			return resource;
		}

		Link link1 = new Link(endpoint + "users/user/profile");
		resource.add(link1);
		Link link2 = new Link(endpoint + "users/user/deactivate");
		resource.add(link2);

		return resource;
	}

	@Override
	public Resource<Response> editProfile(Response response, String username) {

		Resource<Response> resource = new Resource<Response>(response);

		if (response.getStatus_code() == 204) {
			return resource;
		}

		Link link1 = new Link(endpoint + "users/user/profile");
		resource.add(link1);
		Link link2 = new Link(endpoint + "users/user/deactivate");
		resource.add(link2);

		return resource;
	}

}