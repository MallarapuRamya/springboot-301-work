package com.mindtree.user.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserListResponse;
import com.mindtree.user.response.entity.UserResponse;

@Service
public interface UserService {

	public UserListResponse getAllUsers();

	public UserResponse getByUsername(String username);

	public Response registerUser(User user);

	public Response editProfile(String username, User user_obj);

	public Response deactivateAccount(String username);

	public Optional<User> getByUsernameAdmin(String username);

	public UserAddress getAddressDetails(String username);
	
	public String getCurrentUserName();

	public void register(User user);
}
