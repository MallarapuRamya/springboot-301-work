package com.mindtree.user.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "smm_user")
@ApiModel(description="Profile information of the user registered to the application.")
public class User {

	@Id
	@Column(name = "userID")
	@ApiModelProperty(notes="Primary attribute for user identification.")
	private String username;

	@Column(name = "NAME")
	@ApiModelProperty(notes="Name of the user.")
	private String name;

	@Column(name = "PASSWORD")
	@ApiModelProperty(notes="Password for authentication purpose.")
	private String password;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "addressId", referencedColumnName = "addressId")
	@ApiModelProperty(notes="User addres details.")
    private UserAddress address;

	@Column(name = "MOBILE")
	@ApiModelProperty(notes="Contact number of the user.")
	private long mobile;

	@Column(name = "ACCOUNT_ENABLED")
	@ApiModelProperty(notes="Account activation status.")
	private boolean enable = true;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	public UserAddress getAddress() {
		return address;
	}

	public void setAddress(UserAddress address) {
		this.address = address;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", name=" + name + ", password=" + password + ", address=" + address
				+ ", mobile=" + mobile + ", enable=" + enable + "]";
	}

}
