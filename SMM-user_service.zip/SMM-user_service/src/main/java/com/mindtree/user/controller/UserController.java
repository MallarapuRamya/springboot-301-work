package com.mindtree.user.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserListResponse;
import com.mindtree.user.response.entity.UserResponse;
import com.mindtree.user.service.UserHateoasService;
import com.mindtree.user.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/user")
@Api(value = "Everything about User Info", description = "Services provided to the user", tags = { "User" })
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private UserHateoasService refLinks;
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)}) 
	@ApiOperation(value="Fetch details of all the registered users.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Internal Use", value = "Functionality Used for Microservices Communication.")})},
	produces = "application/json", notes = "This functionality is used for microservices communication. It will not be giving user friendly response.")
	@RequestMapping(value = "/allUsers", method = RequestMethod.GET)
	
	public UserListResponse allUsers() {
		return userService.getAllUsers();
	}

	
	
	@ApiOperation(value="Fetch user specific details.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Internal Use", value = "Functionality Used for Microservices Communication.")})},
	produces = "application/json", notes = "This functionality is used for microservices communication for getting user specific details. It will not be giving user friendly response.")
	@RequestMapping(value = "/username/{username}", method = RequestMethod.GET)
	
	public Optional<User> getByUsernameAdmin(@PathVariable String username) {
		return userService.getByUsernameAdmin(username);
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value="User registration.",extensions={@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Customer", value = "Customer is able to register to the application.")})},
	produces = "application/json", notes = "Customer should be able to get registered to the application.")
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	
	public Resource<Response> register(@RequestBody User user) {
		return refLinks.registerUser(userService.registerUser(user));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Sucess", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value="Getting profile info for current user.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the profile.")})},
	produces = "application/json", notes = "Customer is able get the profile info specifying it's username")
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	
	public Resource<UserResponse> getByUsername() {
		return refLinks.getByUsername(userService.getByUsername(userService.getCurrentUserName()));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Sucess", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value="Edit user profile info for current user.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the profile.")})},
	produces = "application/json", notes = "Customer is able modify the personal profile details. But has to provide every attribute name in postman whether leaving the value field empty.")
	@RequestMapping(value = "/profile", method = RequestMethod.PUT)
	
	public Resource<Response> editProfile(@RequestBody User user) {
		return refLinks.editProfile(userService.editProfile(userService.getCurrentUserName(), user), userService.getCurrentUserName());
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Sussess", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value="Deactivate user account for current user.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the profile.")})},
	produces = "application/json", notes = "Customer is able to unregister/deactivate it's user account.")
	@RequestMapping(value = "/deactivate", method = RequestMethod.PUT)
	
	public Response deactivateAccount() {
		return userService.deactivateAccount(userService.getCurrentUserName());
	}

	
	
	@ApiOperation(value="Fetch user specific details.", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Internal Use", value = "Functionality Used for Microservices Communication.")})},
	produces = "application/json", notes = "This functionality is used for microservices communication for getting user specific address details. It will not be giving user friendly response.")
	@RequestMapping(value = "/address/{username}", method = RequestMethod.GET)
	
	public UserAddress getAddressDetails(@PathVariable String username) {
		return userService.getAddressDetails(username);
	}
	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value="Persisting the social user database.",extensions={@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Customer", value = "Customer is able to register while using Social Login")})},
	produces = "application/json", notes = "This functionality is used for microservices communication for getting user specific address details. It will not be giving user friendly response.")
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public void registerUser(@RequestBody User user) {
		userService.register(user);
	}
}
