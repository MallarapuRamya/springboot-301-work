package com.mindtree.user.response.entity;

import com.mindtree.user.entity.User;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational response to be shown for the request.")
public class UserResponse extends Response {


	@ApiModelProperty(notes="User Details.")
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserResponse() {
	}

	public UserResponse(int status_code, String message, User user) {
		super(status_code, message);
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserResponse [user=" + user + "]";
	}
	
}
