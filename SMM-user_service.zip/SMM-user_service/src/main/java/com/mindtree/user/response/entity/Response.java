package com.mindtree.user.response.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Non-Informational response to be shown for the request.")
public class Response {

	@ApiModelProperty(notes="Status code for Response identification.")
	private int status_code;
	@ApiModelProperty(notes="Response message for the request.")
	private String message;
	
	public int getStatus_code() {
		return status_code;
	}
	
	public void setStatus_code(int status_code) {
		this.status_code = status_code;
	}
	
	public String getMessage() {
		return message;
	}
	
	public Response(int status_code, String message) {
		super();
		this.status_code = status_code;
		this.message = message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Response() {
	}
	
	@Override
	public String toString() {
		return "Response [status_code=" + status_code + ", message=" + message + "]";
	}
}
