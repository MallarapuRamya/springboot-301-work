package com.mindtree.user.beans;

import org.jboss.logging.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class EncryptionBean {

	private Logger logger = Logger.getLogger(EncryptionBean.class);

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		logger.debug("Encoder has been hitted");
		return new BCryptPasswordEncoder();
	}
}
