package com.mindtree.user.response.entity;

import java.util.List;

import com.mindtree.user.entity.User;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational(List) response to be shown for the request.")
public class UserListResponse extends Response {

	@ApiModelProperty(notes="List of user details.")
	private List<User> userList;

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public UserListResponse(int status_code, String message, List<User> userList) {
		super(status_code, message);
		this.userList = userList;
	}
	
	public UserListResponse() {
	}

	@Override
	public String toString() {
		return "UserListResponse [userList=" + userList + "]";
	}
	
}
