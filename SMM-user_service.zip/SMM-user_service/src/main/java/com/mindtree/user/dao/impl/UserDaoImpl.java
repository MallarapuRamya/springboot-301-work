package com.mindtree.user.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.user.dao.UserDao;
import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.utility.UserRepository;

@Service
public class UserDaoImpl implements UserDao {

	@Autowired
	UserRepository userRepository;

	@Override
	public List<User> getAllUsers() throws Exception {
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getByUsername(String username) throws Exception {
		return userRepository.findById(username);
	}

	@Override
	public User registerUser(User user) throws Exception {
		User registered = userRepository.save(user);
		return registered;
	}

	@Override
	public boolean editProfile(String username, User user) throws Exception {
		boolean success = false;
		User userRepo = userRepository.findById(username).get();
		userRepo.getAddress().setAddressId(userRepo.getAddress().getAddressId());

		if (userRepo != null) {
			
			if (user.getName() == null || user.getName().isEmpty())  {
				userRepo.setName(userRepo.getName());
			} 
			else {
				userRepo.setName(user.getName());
			}

			if (user.getAddress().getAddressline1() == null || user.getAddress().getAddressline1().isEmpty()) {
				userRepo.getAddress().setAddressline1(userRepo.getAddress().getAddressline1());
			} 
			else {
				userRepo.getAddress().setAddressline1(user.getAddress().getAddressline1());
			}

			if (user.getAddress().getArea() == null || user.getAddress().getArea().isEmpty()) {
				userRepo.getAddress().setArea(userRepo.getAddress().getArea());
			} else {
				userRepo.getAddress().setArea(user.getAddress().getArea());
			}

			if (user.getAddress().getCity() == null || user.getAddress().getCity().isEmpty()) {
				userRepo.getAddress().setCity(userRepo.getAddress().getCity());
			} else {
				userRepo.getAddress().setCity(user.getAddress().getCity());
			}

			if (user.getAddress().getPincode() == 0 || Long.toString(user.getAddress().getPincode()).isEmpty()) {
				userRepo.getAddress().setPincode(userRepo.getAddress().getPincode());
			} else {
				userRepo.getAddress().setPincode(user.getAddress().getPincode());
			}

			if (user.getAddress().getState() == null || user.getAddress().getState().isEmpty()) {
				userRepo.getAddress().setState(userRepo.getAddress().getState());
			} else {
				userRepo.getAddress().setState(user.getAddress().getState());
			}

			userRepo.setEnable(user.isEnable());

			if (user.getMobile() == 0 || Long.toString(user.getMobile()).isEmpty()) {
				userRepo.setMobile(userRepo.getMobile());
			} else {
				userRepo.setMobile(user.getMobile());
			}

			if (user.getPassword() == null || user.getPassword().isEmpty()) {
				userRepo.setPassword(userRepo.getPassword());
			} else {
				userRepo.setPassword(user.getPassword());
			}

			success = true;
			userRepository.save(userRepo);
		}
		return success;
	}

	@Override
	public boolean deactivateAccount(String username) throws Exception {

		boolean success = false;

		User user = userRepository.findById(username).get();
		user.setEnable(false);

		User deactivated = userRepository.save(user);

		if (deactivated != null) {
			success = true;
		}

		return success;
	}

	@Override
	public UserAddress getAddressDetails(String username) throws Exception {

		Optional<User> user = getByUsername(username);
		UserAddress userAddress = user.get().getAddress();

		return userAddress;
	}

}
