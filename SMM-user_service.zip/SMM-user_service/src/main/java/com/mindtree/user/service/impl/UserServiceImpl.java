package com.mindtree.user.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mindtree.user.dao.UserDao;
import com.mindtree.user.entity.User;
import com.mindtree.user.entity.UserAddress;
import com.mindtree.user.exception.DataNotFound;
import com.mindtree.user.exception.DuplicateDataFound;
import com.mindtree.user.exception.InvalidData;
import com.mindtree.user.response.entity.Response;
import com.mindtree.user.response.entity.UserListResponse;
import com.mindtree.user.response.entity.UserResponse;
import com.mindtree.user.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Autowired
	private PasswordEncoder passwordEncoder;

	private final Logger LOG = Logger.getLogger(UserServiceImpl.class);

	@Override
	public UserListResponse getAllUsers() {

		UserListResponse userListResponse = new UserListResponse();

		try {
			List<User> userlist = userDao.getAllUsers();

			if (!CollectionUtils.isEmpty(userlist)) {
				userlist.forEach(user -> user.setPassword("********"));
				userListResponse.setUserList(userlist);
				userListResponse.setStatus_code(200);
				userListResponse.setMessage("List of users.");
			} 
			else {
				userListResponse.setStatus_code(204);
				userListResponse.setMessage("No users found.");
				userListResponse.setUserList(null);
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getMessage() + "Database issue.");
			return new UserListResponse(204, "Something went wrong, Please try again later.", null);
		}
		
		return userListResponse;
	}

	@Override
	public UserResponse getByUsername(String username) {

		UserResponse userResponse = new UserResponse();

		try {
			Optional<User> user = userDao.getByUsername(username);

			try {

				if (!user.isPresent() || !user.get().isEnable()) {
					throw new DataNotFound("User not found");
				} 
				else {
					userResponse.setStatus_code(200);
					userResponse.setMessage("User found.");
					userResponse.setUser(user.get());
				}
			} 
			catch (DataNotFound e) {
				e.printStackTrace();
				LOG.error(e.getMessage() + "For username : " + username);
				return new UserResponse(204, "User account not present / deactivated for " + username, null);
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getMessage() + "Database issue.");
			return new UserResponse(204, "Something went wrong, Please try again later", null);
		}

		return userResponse;
	}

	@Override
	public Optional<User> getByUsernameAdmin(String username) {

		Optional<User> user = null;

		try {
			user = userDao.getByUsername(username);
		} 
		catch (Exception e) {
			LOG.error(e.getMessage());
		}
		return user;
	}

	@Override
	public Response registerUser(User user) {

		Response response = new Response();
		String emailRegex = "^[a-zA-Z0-9]+(?:\\." + "[a-zA-Z0-9]+)*@" + "(?:[a-zA-Z0-9]+\\.)+[a-z" + "A-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);

		try {
			if (user.getAddress().getAddressId() != 0) {
				throw new InvalidData("Address Id given manually.");
			}
		} 
		catch (InvalidData e1) {
			LOG.error(e1.getMessage());
			return new Response(204, "User addressId is auto generated.");
		}
		Optional<User> registeredToBe = null;
		try {
			registeredToBe = userDao.getByUsername(user.getUsername());
		}  
		catch (Exception e) {
			e.printStackTrace();
			return new Response(204, "Something went wrong, Please try again later...");
		}

		try {
			if (registeredToBe != null) {
				if (registeredToBe.get().getAddress() != null) {
					if (registeredToBe.isPresent()) {
						throw new DuplicateDataFound("User already exists.");
					}
				}
			}
		} 
		catch (DuplicateDataFound e) {
			e.printStackTrace();
			LOG.error(e.getMessage());
			return new Response(204, "User already exists.");
		}

		try {

			if (user.getUsername() == null || user.getUsername().isEmpty() || user.getPassword() == null
					|| user.getPassword().isEmpty() || user.getName() == null || user.getName().isEmpty()
					|| user.getAddress().getPincode() == 0 || Long.toString(user.getAddress().getPincode()).isEmpty()
					|| user.getAddress().getAddressline1() == null || user.getAddress().getAddressline1().isEmpty()
					|| user.getAddress().getCity() == null || user.getAddress().getCity().isEmpty()
					|| user.getAddress().getState() == null || user.getAddress().getState().isEmpty()) {
				throw new InvalidData("Mandatory fields given empty.");
			}
		} 
		catch (InvalidData e) {
			LOG.error("Mandatory fields are given null.");
			return new Response(204, "Mandatory fields are given empty.");
		}

		try {
			if (pat.matcher(user.getUsername()).matches()) {

				user.setPassword(passwordEncoder.encode(user.getPassword()));
				User registered = userDao.registerUser(user);

				if (registered != null) {
					response.setStatus_code(200);
					response.setMessage("Registered successfully");
				} else {
					response.setStatus_code(204);
					response.setMessage("Not Registered, Please try again.");
				}
			} 
			else {
				response.setStatus_code(204);
				response.setMessage("Please enter valid username(email).");
			}
		} 
		catch (Exception e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new Response(204, "Something went wrong, Please try again later.");
		}

		return response;
	}

	@Override
	public Response editProfile(String username, User user_obj) {

		Response response = new Response();
		try {

			Optional<User> user = userDao.getByUsername(username);
			try {
				if(user.get().getAddress()!=null)
				{if (user_obj.getAddress().getAddressId() != user.get().getAddress().getAddressId()
						|| !user_obj.getUsername().equals(user.get().getUsername())) {
					LOG.info("=========>INFORMATION"+user_obj.getAddress().getAddressId()+"==="+user.get().getAddress().getAddressId()+"==="+user_obj.getUsername()+"==="+user.get().getUsername());
					throw new InvalidData("Use information is restricted to be modified.");
				}}
				else{
					registerUser(user_obj);
				}
			} 
			catch (InvalidData e) {
				LOG.error(e.getMessage());
				return new Response(204, "User information is restricted to be modified.");
			}
			try {
				user_obj.setPassword(passwordEncoder.encode(user_obj.getPassword()));
				boolean success = userDao.editProfile(username, user_obj);

				if (success == true) {
					response.setStatus_code(200);
					response.setMessage("Profile updated successfully.");
				} else {
					response.setStatus_code(204);
					response.setMessage("Failed to update the profile. Please try Again.");
				}
			} 
			catch (Exception e) {
				LOG.error(e.getMessage() + " User " + username + " does not exist.");
				return new Response(204, "User does not exist.");
			}
		} 
		catch (Exception e) {
			LOG.error(e.getMessage());
			return new Response(204, "Something went wrong, Please try again later.");
		}
		return response;
	}

	@Override
	public Response deactivateAccount(String username) {

		Response response = new Response();

		try {

			Optional<User> user = userDao.getByUsername(username);

			try {
				if (user.get().isEnable() == false) {
					throw new DataNotFound("User not found/already deactivated.");
				} else if (userDao.deactivateAccount(username)) {
					response.setStatus_code(200);
					response.setMessage("Profile deactivated successfully.");
				} else {
					response.setStatus_code(204);
					response.setMessage("Failed to deactivate the profile. Please try Again.");
				}
			} catch (DataNotFound e) {
				e.printStackTrace();
				LOG.error(e.getMessage() + "For username : " + username);
				return new Response(204, "User account not present / already deactivated for " + username);
			}
		} catch (Exception e) {
			LOG.error(e.getMessage() + "Database issue.");
			return new UserResponse(204, "Something went wrong, Please try again later", null);
		}
		return response;
	}

	@Override
	public UserAddress getAddressDetails(String username) {

		UserAddress userAddress = null;
		try {
			userAddress = userDao.getAddressDetails(username);
		} catch (Exception e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
		}
		return userAddress;
	}

	@Override
	public String getCurrentUserName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		return currentPrincipalName;
	}

	@Override
	public void register(User user) {
		try {
			if (!userDao.getByUsername(user.getUsername()).isPresent()) {
				userDao.registerUser(user);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOG.info(e.getMessage());
		}
	}

}