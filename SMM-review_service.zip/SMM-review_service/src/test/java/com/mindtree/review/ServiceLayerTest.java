package com.mindtree.review;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.review.dao.ReviewDao;
import com.mindtree.review.entity.Product;
import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.exceptions.InvalidDataException;
import com.mindtree.review.exceptions.ReviewNotFoundException;
import com.mindtree.review.response.entity.ProductListResponse;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.service.ProductServiceProxy;
import com.mindtree.review.service.impl.ReviewServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTest {

	@Mock
	private ReviewDao reviewDao;

	@Mock
	ProductServiceProxy psp;

	@InjectMocks
	@Spy
	private ReviewServiceImpl service;

	@Test
	public void getAllReviews1() {
		Review review = new Review();
		review.setProductId(1011);
		review.setReview("    gfd");
		review.setReviewId(12);
		review.setUserName("chakka.jamath@gmail.com");
		List<Review> reviews = new ArrayList<Review>();
		reviews.add(review);
		try {
			when(reviewDao.getAllReviewsForUser("chakka.jamath@gmail.com")).thenReturn(reviews);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.getAllReviewsForUser("chakka.jamath@gmail.com").getStatusCode());

	}

	@Test
	public void getAllReviews2() {
		Review review = new Review();
		review.setProductId(1011);
		review.setReview("    gfd");
		review.setReviewId(12);
		review.setUserName("chakka.jamath@gmail.com");
		List<Review> reviews = new ArrayList<Review>();
		try {
			when(reviewDao.getAllReviewsForUser("chakka.jamath@gmail.com")).thenReturn(reviews);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllReviewsForUser("chakka.jamath@gmail.com").getStatusCode());

	}

	@Test
	public void getAllReviews3() {
		Review review = new Review();
		review.setProductId(1011);
		review.setReview("    gfd");
		review.setReviewId(12);
		review.setUserName("chakka.jamath@gmail.com");
		List<Review> reviews = new ArrayList<Review>();
		reviews.add(review);
		try {
			when(reviewDao.getAllReviewsForUser("chakka.jamath@gmail.com")).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllReviewsForUser("chakka.jamath@gmail.com").getStatusCode());

	}

	@Test
	public void getAllRatings1() {
		Rating ratings = new Rating();
		ratings.setProductId(102);
		ratings.setRating(3);
		ratings.setRatingId(1);
		ratings.setUserName("chakka.jamath@gmail.com");
		List<Rating> rating = new ArrayList<Rating>();
		rating.add(ratings);
		try {
			when(reviewDao.getAllRatingsForUser("chakka.jamath@gmail.com")).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.getAllRatingsForUser("chakka.jamath@gmail.com").getStatusCode());
	}

	@Test
	public void getAllRatings2() {
		Rating ratings = new Rating();
		ratings.setProductId(102);
		ratings.setRating(3);
		ratings.setRatingId(1);
		ratings.setUserName("chakka.jamath@gmail.com");
		List<Rating> rating = new ArrayList<Rating>();
		try {
			when(reviewDao.getAllRatingsForUser("chakka.jamath@gmail.com")).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllRatingsForUser("chakka.jamath@gmail.com").getStatusCode());
	}

	@Test
	public void getAllRatings3() {
		Rating ratings = new Rating();
		ratings.setProductId(102);
		ratings.setRating(3);
		ratings.setRatingId(1);
		ratings.setUserName("chakka.jamath@gmail.com");
		List<Rating> rating = new ArrayList<Rating>();
		rating.add(ratings);
		try {
			when(reviewDao.getAllRatingsForUser("chakka.jamath@gmail.com")).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllRatingsForUser("chakka.jamath@gmail.com").getStatusCode());
	}

	@Test
	public void getReviewById1() {
		String username = "chakka.jamath@gmail.com";

		Review reviews = new Review();
		reviews.setReviewId(1);
		reviews.setUserName(username);
		reviews.setProductId(101);
		Optional<Review> review = Optional.of(reviews);
		try {
			when(reviewDao.getByReviewId(1, username)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(200, service.getReviewById(1, username).getStatusCode());
	}

	@Test
	public void getReviewById2() {
		String username = "chakka.jamath@gmail.com";

		Review reviews = new Review();
		reviews.setReviewId(1);
		reviews.setUserName(username);
		reviews.setProductId(101);
		Optional<Review> review = Optional.of(reviews);
		try {
			when(reviewDao.getByReviewId(1, username)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getReviewById(0, username).getStatusCode());
	}

	@Test
	public void getReviewById3() {
		String username = "chakka.jamath@gmail.com";

		Review reviews = new Review();
		reviews.setReviewId(1);
		reviews.setUserName(username);
		reviews.setProductId(101);
		try {
			when(reviewDao.getByReviewId(1, username)).thenReturn(Optional.ofNullable(null));
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getReviewById(1, username).getStatusCode());
	}

	@Test
	public void getReviewById4() {
		String username = "chakka.jamath@gmail.com";

		Review reviews = new Review();
		reviews.setReviewId(1);
		reviews.setUserName(username);
		reviews.setProductId(101);
		try {
			when(reviewDao.getByReviewId(1, username)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getReviewById(1, username).getStatusCode());
	}

	@Test
	public void getRatingById1() {
		String username = "chakka.jamath@gmail.com";
		Rating ratings = new Rating();
		ratings.setProductId(101);
		ratings.setRating(5);
		ratings.setUserName(username);
		ratings.setRatingId(3);

		Optional<Rating> rating = Optional.of(ratings);
		;
		try {
			when(reviewDao.getByRatingId(3, username)).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(200, service.getRatingById(3, username).getStatusCode());
	}

	@Test
	public void getRatingById2() {
		String username = "chakka.jamath@gmail.com";
		Rating ratings = new Rating();
		ratings.setProductId(101);
		ratings.setRating(5);
		ratings.setUserName(username);
		ratings.setRatingId(3);

		Optional<Rating> rating = Optional.of(ratings);
		;
		try {
			when(reviewDao.getByRatingId(3, username)).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getRatingById(3, "").getStatusCode());
	}

	@Test
	public void getRatingById3() {
		String username = "chakka.jamath@gmail.com";
		Rating ratings = new Rating();
		ratings.setProductId(101);
		ratings.setRating(5);
		ratings.setUserName(username);
		ratings.setRatingId(3);

		Optional<Rating> rating = Optional.of(ratings);
		try {
			when(reviewDao.getByRatingId(3, username)).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getRatingById(0, username).getStatusCode());
	}

	@Test
	public void getRatingByI4() {
		String username = "chakka.jamath@gmail.com";
		Rating ratings = new Rating();
		ratings.setProductId(101);
		ratings.setRating(5);
		ratings.setUserName(username);
		ratings.setRatingId(3);
		try {
			when(reviewDao.getByRatingId(3, username)).thenReturn(Optional.ofNullable(null));
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getRatingById(3, username).getStatusCode());
	}

	@Test
	public void getRatingById5() {
		String username = "chakka.jamath@gmail.com";
		Rating ratings = new Rating();
		ratings.setProductId(101);
		ratings.setRating(5);
		ratings.setUserName(username);
		ratings.setRatingId(3);

		try {
			when(reviewDao.getByRatingId(3, username)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.getRatingById(3, username).getStatusCode());
	}

	@Test
	public void createReview1() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		Response response = new Response();
		review.setProductId(101);
		review.setReview("cool product");
		review.setReviewId(10);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("product is present");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);
		
		List<Review> reviewList=new ArrayList<Review>();
		reviewList.add(review);

		try {
			when(reviewDao.getAllReviewsForUser(username)).thenReturn(reviewList);
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.createReview(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.createReview(101, "cool product", username).getStatusCode());
	}

	@Test
	public void createReview2() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		Response response = new Response();
		review.setProductId(101);
		review.setReview("affordable");
		review.setReviewId(10);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.createReview(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.createReview(101, "affordable", username).getStatusCode());
	}

	@Test
	public void createReview3() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		Response response = new Response();
		review.setProductId(101);
		review.setReview("average product");
		review.setReviewId(10);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.createReview(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.createReview(101, "", username).getStatusCode());
	}

	@Test
	public void createReview4() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		Response response = new Response();
		review.setProductId(101);
		review.setReview("nice product");
		review.setReviewId(10);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.createReview(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.createReview(0, "nice mobile", username).getStatusCode());
	}
	
	@Test
	public void createReview5() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		Response response = new Response();
		review.setProductId(101);
		review.setReview("cool product");
		review.setReviewId(10);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(104);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("product is present");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);
		
		List<Review> reviewList=new ArrayList<Review>();

		try {
			when(reviewDao.getAllReviewsForUser(username)).thenReturn(reviewList);
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.createReview(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.createReview(101, "cool product", username).getStatusCode());
	}

	@Test
	public void giveRatingTest1() {
		String username = "chakka.jamath@gmail.com";
		Rating review = new Rating();
		Response response = new Response();
		review.setProductId(101);
		review.setRating(4);
		review.setRatingId(1);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("keypad");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.giveRating(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204,
				service.giveRating(review.getProductId(), review.getRating(), review.getUserName()).getStatusCode());
	}

	@Test
	public void giveRatingTest2() {
		String username = "chakka.jamath@gmail.com";
		Rating review = new Rating();
		Response response = new Response();
		review.setProductId(101);
		review.setRating(4);
		review.setRatingId(1);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("jio");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.giveRating(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.giveRating(0, review.getRating(), review.getUserName()).getStatusCode());
	}

	@Test
	public void giveRatingTest3() {
		String username = "chakka.jamath@gmail.com";
		Rating review = new Rating();
		Response response = new Response();
		review.setProductId(101);
		review.setRating(4);
		review.setRatingId(1);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.giveRating(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204,
				service.giveRating(review.getProductId(), review.getRating(), review.getUserName()).getStatusCode());
	}

	@Test
	public void giveRatingTest4() {
		String username = "chakka.jamath@gmail.com";
		Rating review = new Rating();
		Response response = new Response();
		review.setProductId(101);
		review.setRating(4);
		review.setRatingId(1);
		review.setUserName(username);
		response.setStatusCode(200);
		response.setStatusMessage("success");

		Product product = new Product();
		product.setDescription("wohoo");
		product.setModelName("sam");
		product.setPrice(20000.0);
		product.setProductId(101);
		product.setSellerType("nokia");
		product.setType("smart");

		List<Product> productList = new ArrayList<Product>();
		productList.add(product);

		ProductListResponse plr = new ProductListResponse();
		plr.setProductList(productList);
		plr.setStatusCode(200);
		plr.setStatusMessage("wohoooooo");

		List<Integer> productIds = new ArrayList<Integer>();
		productIds.add(101);

		try {
			when(psp.getByProductIds(productIds)).thenReturn(plr);
			when(reviewDao.giveRating(review)).thenReturn(review);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.giveRating(review.getProductId(), 7, review.getUserName()).getStatusCode());
	}

	@Test
	public void updateReviewTest1() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		review.setProductId(101);
		review.setReview("not good");
		review.setReviewId(10);
		review.setUserName(username);

		try {
			when(reviewDao.getByReviewId(review.getReviewId(), username)).thenReturn(Optional.of(review));
			when(reviewDao.updateReview(review.getReviewId(), review.getReview(), username)).thenReturn(review);
		} catch (InvalidDataException e) {
			e.printStackTrace();
		} catch (ReviewNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.updateReview(review.getReviewId(), review.getReview(),review.getUserName()).getStatusCode());

	}

	@Test
	public void updateReviewTest2() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		review.setProductId(101);
		review.setReview("please don't buy");
		review.setReviewId(10);
		review.setUserName(username);

		try {
			when(reviewDao.getByReviewId(review.getReviewId(), username)).thenReturn(Optional.of(review));
			when(reviewDao.updateReview(review.getReviewId(), review.getReview(), username)).thenReturn(review);
		} catch (InvalidDataException e) {
			e.printStackTrace();
		} catch (ReviewNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.updateReview(0, review.getReview(),review.getUserName()).getStatusCode());

	}

	@Test
	public void updateReviewTest3() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		review.setProductId(101);
		review.setReview("very nice product");
		review.setReviewId(10);
		review.setUserName(username);

		try {
			when(reviewDao.getByReviewId(review.getReviewId(), username)).thenReturn(Optional.ofNullable(null));
			when(reviewDao.updateReview(review.getReviewId(), review.getReview(), username)).thenReturn(review);
		} catch (InvalidDataException e) {
			e.printStackTrace();
		} catch (ReviewNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.updateReview(review.getReviewId(), review.getReview(),username).getStatusCode());

	}

	@Test
	public void updateReviewTest4() {
		String username = "chakka.jamath@gmail.com";
		Review review = new Review();
		review.setProductId(101);
		review.setReview("ok for the price");
		review.setReviewId(10);
		review.setUserName(username);

		try {
			when(reviewDao.getByReviewId(review.getReviewId(), username)).thenReturn(Optional.of(review));
			when(reviewDao.updateReview(review.getReviewId(), review.getReview(),username)).thenThrow(new RuntimeException());
		} catch (InvalidDataException e) {
			e.printStackTrace();
		} catch (ReviewNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, service.updateReview(review.getReviewId(), review.getReview(),username).getStatusCode());

	}

	
	
	@Test
	public void getAllRatings()
	{
		Rating ratings = new Rating();
		ratings.setProductId(102);
		ratings.setRating(3);
		ratings.setRatingId(1);
		ratings.setUserName("chakka.jamath@gmail.com");
		List<Rating> rating = new ArrayList<Rating>();
		rating.add(ratings);
		try {
			when(reviewDao.getAllRatings()).thenReturn(rating);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.getAllRatings().getStatusCode());
	}
	
	@Test
	public void getAllReviews()
	{
		Review review = new Review();
		review.setProductId(1011);
		review.setReview("    gfd");
		review.setReviewId(12);
		review.setUserName("chakka.jamath@gmail.com");
		List<Review> reviews = new ArrayList<Review>();
		reviews.add(review);
		try {
			when(reviewDao.getAllReviews()).thenReturn(reviews);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.getAllReviews().getStatusCode());
	}
	
	@Test
	public void getAllReviews22()
	{
		Review review = new Review();
		review.setProductId(1011);
		review.setReview("    gfd");
		review.setReviewId(12);
		review.setUserName("chakka.jamath@gmail.com");
		List<Review> reviews = new ArrayList<Review>();
		reviews.add(review);
		try {
			when(reviewDao.getAllReviews()).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllReviews().getStatusCode());
	}
	
	
	@Test
	public void getAllRatings22()
	{
		Rating ratings = new Rating();
		ratings.setProductId(102);
		ratings.setRating(3);
		ratings.setRatingId(1);
		ratings.setUserName("chakka.jamath@gmail.com");
		List<Rating> rating = new ArrayList<Rating>();
		rating.add(ratings);
		try {
			when(reviewDao.getAllRatings()).thenReturn(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.getAllRatings().getStatusCode());
	}
}