package com.mindtree.review;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.review.dao.impl.ReviewDaoImpl;
import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.utility.RatingRepository;
import com.mindtree.review.utility.ReviewRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DaoLayerTest {

	@Mock
	ReviewRepository reviewRepo;

	@Mock
	RatingRepository ratingRepo;

	@InjectMocks
	@Spy
	ReviewDaoImpl daoImpl;

	@Test
	public void giveReviewTest() {
		Review review = new Review();
		review.setProductId(102);
		review.setReview("nice product");
		review.setReviewId(22);
		review.setUserName("chakka.jamath@gmail.com");
		when(reviewRepo.save(review)).thenReturn(review);

		try {
			assertEquals(review, daoImpl.createReview(review));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void giveRatingTest() {
		Rating rating = new Rating();
		rating.setProductId(102);
		rating.setRating(2);
		rating.setRatingId(420);
		rating.setUserName("chakka.jamath@gmail.com");
		when(ratingRepo.save(rating)).thenReturn(rating);

		try {
			assertEquals(rating, daoImpl.giveRating(rating));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void getReviewIdTest() {
		Review review = new Review();
		int reviewID = 22;
		review.setProductId(102);
		review.setReview("nice product");
		review.setReviewId(22);
		review.setUserName("chakka.jamath@gmail.com");
		when(reviewRepo.findById(reviewID)).thenReturn(Optional.of(review));

		try {
			assertEquals(Optional.of(review), daoImpl.getByReviewId(reviewID, "chakka.jamath@gmail.com"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void getRatingIdTest() {
		Rating review = new Rating();
		int ratingID = 22;
		review.setProductId(102);
		review.setRating(5);
		review.setRatingId(22);
		review.setUserName("chakka.jamath@gmail.com");
		when(ratingRepo.findById(ratingID)).thenReturn(Optional.of(review));

		try {
			assertEquals(Optional.of(review), daoImpl.getByRatingId(ratingID, "chakka.jamath@gmail.com"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
