package com.mindtree.review;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(Suite.class)
@SuiteClasses({ ServiceLayerTest.class, HateoasTest.class, ControllerTests.class ,DaoLayerTest.class})
@SpringBootTest
public class SmmReviewServiceApplicationTests {

}
