package com.mindtree.review;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ReviewResponse;
import com.mindtree.review.service.ReviewHateaosService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HateoasTest {

	@Autowired
	ReviewHateaosService hateoasService;

	@Test
	public void createReviewTestCase1() {
		Response response = new Response();
		response.setStatusCode(204);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.createReview(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void createReviewTestCase2() {
		Response response = new Response();
		response.setStatusCode(200);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.createReview(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
	}

	@Test
	public void giveRatingTestCase1() {
		Response response = new Response();
		response.setStatusCode(204);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.giveRating(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void giveRatingTestCase2() {
		Response response = new Response();
		response.setStatusCode(200);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.giveRating(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
	}

	@Test
	public void getReviewByIdTestCase1() {
		ReviewResponse response = new ReviewResponse();
		Review review = new Review();
		response.setStatusCode(204);
		response.setStatusMessage("");
		response.setReviewObject(review);
		Resource<ReviewResponse> resource = hateoasService.getReviewById(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void getReviewByIdTestCase2() {
		ReviewResponse response = new ReviewResponse();
		Review review = new Review();
		review.setProductId(100);
		review.setReview("review description");
		review.setReviewId(5);
		review.setUserName("userName");
		response.setStatusCode(200);
		response.setStatusMessage("");
		response.setReviewObject(review);
		Resource<ReviewResponse> resource = hateoasService.getReviewById(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
		assertNotNull(resource.getContent().getReviewObject());
	}

	@Test
	public void getRatingByIdTestCase1() {
		RatingResponse response = new RatingResponse();
		Rating rating = new Rating();
		response.setStatusCode(204);
		response.setStatusMessage("");
		response.setRatingObject(rating);
		Resource<RatingResponse> resource = hateoasService.getRatingById(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void getRatingByIdTestCase2() {
		RatingResponse response = new RatingResponse();
		Rating rating = new Rating();
		rating.setProductId(100);
		rating.setRating(3);
		rating.setRatingId(5);
		rating.setUserName("userName");
		response.setStatusCode(200);
		response.setStatusMessage("");
		response.setRatingObject(rating);
		Resource<RatingResponse> resource = hateoasService.getRatingById(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
		assertNotNull(resource.getContent().getRatingObject());
	}

	@Test
	public void updateReviewTestCase1() {
		Response response = new Response();
		response.setStatusCode(204);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.updateReview(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void updateReviewTestCase2() {
		Response response = new Response();
		response.setStatusCode(200);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.updateReview(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
	}

	@Test
	public void updateRatingTestCase1() {
		Response response = new Response();
		response.setStatusCode(204);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.updateRating(response);
		assertEquals(204, resource.getContent().getStatusCode());
		List<Link> links = new ArrayList<Link>();
		assertEquals(links, resource.getLinks());
	}

	@Test
	public void updateRatingTestCase2() {
		Response response = new Response();
		response.setStatusCode(200);
		response.setStatusMessage("");
		Resource<Response> resource = hateoasService.updateRating(response);
		assertEquals(200, resource.getContent().getStatusCode());
		assertNotNull(resource.getLinks());
	}
}
