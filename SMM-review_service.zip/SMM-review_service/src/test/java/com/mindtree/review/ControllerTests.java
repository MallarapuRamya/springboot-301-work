package com.mindtree.review;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.review.controller.ReviewController;
import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;
import com.mindtree.review.service.ReviewHateaosService;
import com.mindtree.review.service.ReviewService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerTests {

	@Mock
	ReviewService reviewService;

	@Mock
	ReviewHateaosService hate;

	@InjectMocks
	@Spy
	ReviewController reviewController;

	@Test
	public void getAllReviewsTest() {
		String username = "chakka.jamath@gmail.com";
		ResponseReviewList response = new ResponseReviewList();
		List<Review> reviewList = new ArrayList<Review>();
		Review review = new Review();
		review.setUserName(username);
		review.setReview("");
		review.setProductId(101);

		reviewList.add(review);
		response.setReviewList(reviewList);
		response.setStatusCode(200);
		when(reviewService.getAllReviewsForUser(username)).thenReturn(response);
		try {
			assertEquals(200, reviewController.getAllReviewsForUser().getStatusCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void getAllRatingsTest() {
		String username = "chakka.jamath@gmail.com";
		RatingResponseList response = new RatingResponseList();
		List<Rating> rating = new ArrayList<Rating>();
		Rating ratings = new Rating();
		ratings.setRatingId(12);
		ratings.setRating(5);
		ratings.setProductId(101);
		ratings.setUserName(username);
		rating.add(ratings);
		response.setStatusCode(200);
		when(reviewService.getAllRatingsForUser(username)).thenReturn(response);

		try {
			assertEquals(200, reviewController.getAllRatingsForUser().getStatusCode());
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	@Test
	public void getReviewById() {
		String username = "chakka.jamath@gmail.com";
		ReviewResponse response = new ReviewResponse();
		response.setStatusCode(200);
		Review review = new Review();
		review.setProductId(102);
		review.setReviewId(2);
		review.setReview("trew");
		review.setUserName(username);
		response.setReviewObject(review);
		when(reviewService.getReviewById(2, username)).thenReturn(response);

		assertEquals(null, reviewController.getReviewById(2));

	}

	@Test
	public void getRatingById() {
		String username = "chakka.jamath@gmail.com";
		RatingResponse response = new RatingResponse();
		response.setStatusCode(200);
		response.setStatusMessage("wefg");
		Rating rating = new Rating();
		rating.setProductId(102);
		rating.setRating(5);
		rating.setUserName(username);
		rating.setRatingId(6);
		response.setRatingObject(rating);
		when(reviewService.getRatingById(6, username)).thenReturn(response);
		assertEquals(null, reviewController.getRatingById(6));
	}

}
