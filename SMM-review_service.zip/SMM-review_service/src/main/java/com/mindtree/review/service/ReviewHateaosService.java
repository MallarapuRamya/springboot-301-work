package com.mindtree.review.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;

@SuppressWarnings("unused")
@Service
public interface ReviewHateaosService {

	Resource<Response> createReview(Response response);

	Resource<Response> giveRating(Response response);

	Resource<ReviewResponse> getReviewById(ReviewResponse reviewResponse);

	Resource<RatingResponse> getRatingById(RatingResponse ratingResponse);

	Resource<Response> updateReview(Response response);

	Resource<Response> updateRating(Response reponse);
}
