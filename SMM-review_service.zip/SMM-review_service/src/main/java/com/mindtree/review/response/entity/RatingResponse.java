package com.mindtree.review.response.entity;

import com.mindtree.review.entity.Rating;

public class RatingResponse extends Response {

	private Rating ratingObject;

	public Rating getRatingObject() {
		return ratingObject;
	}

	public void setRatingObject(Rating ratingObject) {
		this.ratingObject = ratingObject;
	}

}
