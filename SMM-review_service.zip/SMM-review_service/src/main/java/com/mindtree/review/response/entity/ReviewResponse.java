package com.mindtree.review.response.entity;

import com.mindtree.review.entity.Review;

public class ReviewResponse extends Response {

	private Review reviewObject;

	public Review getReviewObject() {
		return reviewObject;
	}

	public void setReviewObject(Review reviewObject) {
		this.reviewObject = reviewObject;
	}

}
