package com.mindtree.review.response.entity;

import java.util.List;

import com.mindtree.review.entity.Product;

public class ProductListResponse extends Response {

	private List<Product> productList;

	public ProductListResponse() {
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

}
