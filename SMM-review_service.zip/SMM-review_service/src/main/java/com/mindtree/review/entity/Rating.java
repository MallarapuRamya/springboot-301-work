package com.mindtree.review.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "smm_rating")
@ApiModel(description = "Information of the Ratings")
public class Rating {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RatingId")
	@ApiModelProperty(notes = "Id attribute for rating identification.")
	private int ratingId;

	@Column(name = "Rating")
	@ApiModelProperty(notes = "Rating for the product.")
	private int rating;

	@Column(name = "userId")
	@ApiModelProperty(notes = "User who can give a rating.")
	private String userName;

	@Column(name = "productId")
	@ApiModelProperty(notes = "Id of the product for which a user can provide a rating.")
	private int productId;

	public int getRatingId() {
		return ratingId;
	}

	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
}
