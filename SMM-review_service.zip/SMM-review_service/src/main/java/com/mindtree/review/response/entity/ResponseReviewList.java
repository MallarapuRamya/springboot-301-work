package com.mindtree.review.response.entity;

import java.util.List;

import com.mindtree.review.entity.Review;

public class ResponseReviewList extends Response {
	private List<Review> reviewList;

	public List<Review> getReviewList() {
		return reviewList;
	}

	public void setReviewList(List<Review> reviewList) {
		this.reviewList = reviewList;
	}

}
