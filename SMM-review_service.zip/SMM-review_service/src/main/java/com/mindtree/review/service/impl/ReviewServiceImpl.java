package com.mindtree.review.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mindtree.review.dao.ReviewDao;
import com.mindtree.review.entity.Product;
import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.exceptions.InvalidDataException;
import com.mindtree.review.exceptions.ProductNotFoundException;
import com.mindtree.review.exceptions.RatingNotFoundException;
import com.mindtree.review.exceptions.ReviewNotFoundException;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;
import com.mindtree.review.service.ProductServiceProxy;
import com.mindtree.review.service.ReviewService;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDao reviewDao;

	@Autowired
	private ProductServiceProxy productServiceProxy;

	Logger LOG = Logger.getLogger(ReviewServiceImpl.class);

	public Response createReview(int productId, String review, String username) {
		Response response = new Response();
		try {
			Review reviewObject = createReviewModel(productId, review, username);
			LOG.info("===============>" + reviewObject.toString());
			Review dbReviewObject = reviewDao.createReview(reviewObject);
			response.setStatusCode(200);
			response.setStatusMessage("Your review has been saved ,review ID is : " + dbReviewObject.getReviewId());
		} catch (InvalidDataException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (ProductNotFoundException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			response.setStatusCode(204);
			response.setStatusMessage("Something went wrong please try again");
			e.printStackTrace();
		}
		return response;
	}

	public Review createReviewModel(int productId, String review, String username)
			throws InvalidDataException, ProductNotFoundException {

		Review reviews = new Review();
		try {

			Integer.parseInt(Integer.toString(productId));
		} catch (Exception e) {
			throw new InvalidDataException("Please enter a product Id");
		}

		if (productId == 0) {
			throw new InvalidDataException("Id cannot be zero, please enter an ID");
		}

		List<Integer> id = new ArrayList<Integer>();
		id.add(productId);
		if (getProducts(id) == null) {
			LOG.info("===============================>" + getProducts(id));
			throw new ProductNotFoundException("There is no product with this id");
		}

		List<Review> reviewList;
		try {
			reviewList = reviewDao.getAllReviewsForUser(username);
			int flag=0;
			for(Review rat:reviewList)
			{
				if(rat.getProductId()==productId)
					flag=-1;
			}
			if(flag==-1)
			{
				throw new InvalidDataException("Multiple reviews can not be given");
			}
		} catch (Exception e) {
			throw new InvalidDataException("Multiple reviews can not be given");
		}

		if (review.isEmpty()) {
			throw new InvalidDataException("Please enter a review");
		}
		Review reviewObject = new Review();
		reviewObject.setReview(review);
		reviewObject.setProductId(productId);
		reviewObject.setUserName(username);
		return reviewObject;

	}

	public Response giveRating(int productId, int rating, String username) {

		Response response = new Response();

		try {
			Rating ratingObject = giveRatingModel(productId, rating, username);
			Rating dbRatingObject = reviewDao.giveRating(ratingObject);

			response.setStatusCode(200);
			response.setStatusMessage("Your rating has been saved ,rating ID is : " + dbRatingObject.getRatingId());
		} catch (InvalidDataException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (ProductNotFoundException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			response.setStatusCode(204);
			response.setStatusMessage("Something went wrong please try again later");
		}
		return response;
	}

	public Rating giveRatingModel(int productId, int rating, String username)
			throws InvalidDataException, ProductNotFoundException {

		Rating ratings = new Rating();

		try {
			Integer.parseInt(Integer.toString(productId));
		} catch (Exception e) {
			throw new InvalidDataException("please enter a productId");
		}

		if (productId == 0) {
			throw new InvalidDataException("Id cannot be zero, please enter an ID");
		}
		List<Integer> id = new ArrayList<Integer>();
		id.add(productId);
		if (getProducts(id) == null) {
			LOG.info("===============================>" + getProducts(id));
			throw new ProductNotFoundException("There is no product with this id");
		}
		List<Rating> ratingList;
		try {
			int flag=0;
			ratingList = reviewDao.getAllRatingsForUser(username);
			for(Rating rat:ratingList)
			{
				if(rat.getProductId()==productId)
					flag=-1;
			}
			if(flag==-1)
			{
				throw new InvalidDataException("Multiple ratings can not be given");
			}
				
		} catch (Exception e) {
			throw new InvalidDataException("Multiple ratings can not be given");
		}

		try {
			Integer.parseInt(Integer.toString(rating));
		} catch (Exception e) {
			throw new InvalidDataException("please enter a rating");
		}
		if (rating <= 0 || rating > 5) {
			throw new InvalidDataException("Rating should be in the range of 1-5");
		}

		Rating ratingObject = new Rating();
		ratingObject.setRating(rating);
		ratingObject.setProductId(productId);
		ratingObject.setUserName(username);
		return ratingObject;
	}

	public ResponseReviewList getAllReviewsForUser(String username) {
		ResponseReviewList responseReviewList = new ResponseReviewList();

		try {
			List<Review> reviews = reviewDao.getAllReviewsForUser(username);
			if (reviews.size() == 0) {
				throw new InvalidDataException("There are no reviews found for user with user name " + username);
			}
			responseReviewList.setReviewList(reviews);
			responseReviewList.setStatusCode(200);
			responseReviewList.setStatusMessage("Your Reviews are");
		} catch (InvalidDataException e) {
			responseReviewList.setStatusCode(204);
			responseReviewList.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			responseReviewList.setStatusCode(204);
			responseReviewList.setStatusMessage("Something went wrong");
		}
		return responseReviewList;
	}

	public RatingResponseList getAllRatingsForUser(String username) {
		RatingResponseList ratingResponseList = new RatingResponseList();
		try {
			List<Rating> ratings = reviewDao.getAllRatingsForUser(username);
			if (ratings.size() == 0) {
				throw new InvalidDataException("There are no ratings found for user with user name " + username);
			}
			ratingResponseList.setRating(ratings);
			ratingResponseList.setStatusCode(200);
			ratingResponseList.setStatusMessage("Your Ratings are");
		} catch (InvalidDataException e) {
			ratingResponseList.setStatusCode(204);
			ratingResponseList.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			ratingResponseList.setStatusCode(204);
			ratingResponseList.setStatusMessage("Something went wrong");
		}
		return ratingResponseList;
	}

	public ReviewResponse getReviewById(int reviewId, String username) {
		ReviewResponse reviewResponse = new ReviewResponse();
		try {
			try {
				Integer.parseInt(Integer.toString(reviewId));
			} catch (Exception e) {
				throw new InvalidDataException("Please enter a Review Id");
			}

			if (reviewId == 0) {
				throw new InvalidDataException("Id cannot be zero ,please enter an id");
			}
			Optional<Review> reviewObject = reviewDao.getByReviewId(reviewId, username);
			if (!reviewObject.isPresent()) {
				throw new ReviewNotFoundException("there is no review with this rating ID");
			}
			reviewResponse.setReviewObject(reviewObject.get());
			reviewResponse.setStatusCode(200);
			reviewResponse.setStatusMessage("Your Review Information is");
		} catch (InvalidDataException e) {
			reviewResponse.setStatusCode(204);
			reviewResponse.setStatusMessage(e.getMessage());
		} catch (ReviewNotFoundException e) {
			reviewResponse.setStatusCode(204);
			reviewResponse.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			reviewResponse.setStatusCode(204);
			reviewResponse.setStatusMessage("Something went wrong");
		}
		return reviewResponse;
	}

	public RatingResponse getRatingById(int ratingId, String username) {
		RatingResponse ratingResponse = new RatingResponse();
		try {
			if (username.isEmpty()) {
				throw new InvalidDataException("Please enter a valid username");
			}
			try {
				Integer.parseInt(Integer.toString(ratingId));
			} catch (Exception e) {
				throw new InvalidDataException("Please enter a rating Id");
			}

			if (ratingId == 0) {
				throw new InvalidDataException("Id cannot be zero ,please enter an id");
			}
			Optional<Rating> ratingObject = reviewDao.getByRatingId(ratingId, username);
			if (!ratingObject.isPresent()) {
				throw new RatingNotFoundException("there is no rating with this rating ID");
			}
			ratingResponse.setRatingObject(ratingObject.get());
			ratingResponse.setStatusCode(200);
			ratingResponse.setStatusMessage("Your rating information is");
		} catch (InvalidDataException e) {
			ratingResponse.setStatusCode(204);
			ratingResponse.setStatusMessage(e.getMessage());
		} catch (RatingNotFoundException e) {
			ratingResponse.setStatusCode(204);
			ratingResponse.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			ratingResponse.setStatusCode(204);
			ratingResponse.setStatusMessage("Something went wrong");
		}
		return ratingResponse;
	}

	@Override
	public Response updateReview(int reviewId, String review,String username) {
		Review reviewObject;
		Review reviewObjects = null;
		Response response = new Response();
		try {
			reviewObject = updateReviewModel(reviewId, review,getCurrentUserName());
			reviewObjects = reviewDao.updateReview(reviewId, review,getCurrentUserName());
			response.setStatusCode(200);
			response.setStatusMessage("Review with id " + reviewObjects.getReviewId() + " updated successfully ");
		} catch (InvalidDataException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (ReviewNotFoundException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			response.setStatusCode(204);
			response.setStatusMessage("Something went wrong");
		}
		return response;
	}

	public Review updateReviewModel(int reviewId, String review,String username)
			throws InvalidDataException, ReviewNotFoundException, Exception {
		Optional<Review> reviewObject = null;
		try {
			Integer.parseInt(Integer.toString(reviewId));
		} catch (Exception e) {
			throw new InvalidDataException("Please provide a reviewId");
		}
		if (reviewId == 0) {
			throw new InvalidDataException("review id cannot be zero , please enter an reviewID");
		}
		reviewObject = reviewDao.getByReviewId(reviewId, getCurrentUserName());
		if (!reviewObject.isPresent()) {
			throw new ReviewNotFoundException("There is no review with the reviewId :" + reviewId);
		}
		else{
			if(!reviewObject.get().getUserName().equals(username)){
				throw new InvalidDataException("You cannot update a different user's Review.");
			}
		}
		reviewObject.get().setReview(review);

		return reviewObject.get();
	}

	@Override
	public Response updateRating(int ratingId, int rating,String username) {
		Rating ratingObject;
		Rating ratingObjects = null;
		Response response = new Response();
		try {
			ratingObject = updateRatingModel(ratingId, rating,username);
			ratingObjects = reviewDao.updateRating(ratingId, rating,username);
			response.setStatusCode(200);
			response.setStatusMessage("Rating with id " + ratingObjects.getRatingId() + " updated successfully ");
		} catch (InvalidDataException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (RatingNotFoundException e) {
			response.setStatusCode(204);
			response.setStatusMessage(e.getMessage());
		} catch (Exception e) {
			response.setStatusCode(204);
			response.setStatusMessage("Something went wrong");
		}
		return response;
	}

	public Rating updateRatingModel(int ratingId, int rating,String username)
			throws InvalidDataException, RatingNotFoundException, Exception {
		Optional<Rating> ratingObject = null;
		try {
			Integer.parseInt(Integer.toString(ratingId));
		} catch (Exception e) {
			throw new InvalidDataException("Please provide a ratingId");
		}
		if (ratingId == 0) {
			throw new InvalidDataException("Id cannot be zero, please enter an ID");
		}
		ratingObject = reviewDao.getByRatingId(ratingId, getCurrentUserName());
		if (!ratingObject.isPresent()) {
			throw new RatingNotFoundException("There is no rating with the rating Id: " + ratingId);
		}
		else{
			if(!ratingObject.get().getUserName().equals(username)){
				throw new InvalidDataException("You cannot update a different user's Rating");
			}
		}
		if (rating <= 0 || rating > 5) {
			throw new InvalidDataException("Rating should be in the range of 1-5");
		}
		ratingObject.get().setRating(rating);
		return ratingObject.get();
	}

	public List<Product> getProducts(List<Integer> idList) {
		return productServiceProxy.getByProductIds(idList).getProductList();
	}

	@Override
	public String getCurrentUserName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		return currentPrincipalName;
	}

	@Override
	public ResponseReviewList getAllReviews() {
		ResponseReviewList responseReviewList = new ResponseReviewList();

		try {
			List<Review> reviews = reviewDao.getAllReviews();
			if (reviews.size() == 0) {
				throw new InvalidDataException("There are no reviews found");
			}
			responseReviewList.setReviewList(reviews);
			responseReviewList.setStatusCode(200);
			responseReviewList.setStatusMessage("Your Reviews are");
		} catch (Exception e) {
			responseReviewList.setStatusCode(204);
			responseReviewList.setStatusMessage("Something went wrong");
		}
		return responseReviewList;
	}

	@Override
	public RatingResponseList getAllRatings() {
		RatingResponseList ratingResponseList = new RatingResponseList();
		try {
			List<Rating> ratings = reviewDao.getAllRatings();
			if (ratings.size() == 0) {
				throw new InvalidDataException("There are no ratings found");
			}
			ratingResponseList.setRating(ratings);
			ratingResponseList.setStatusCode(200);
			ratingResponseList.setStatusMessage("Ratings are ");
		} catch (Exception e) {
			ratingResponseList.setStatusCode(204);
			ratingResponseList.setStatusMessage("Something went wrong");
		}
		return ratingResponseList;
	}

}
