package com.mindtree.review.controller;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;
import com.mindtree.review.service.ReviewHateaosService;
import com.mindtree.review.service.ReviewService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/review")
@Api(value = " Review and Rating service for users", description = "Review and Rating service is used to provide,update,view reviews&ratings for a particular product based on productId,.", tags = {
		"Review and Rating Service" })
public class ReviewController {
	private Logger log = Logger.getLogger(ReviewController.class);

	@Autowired
	ReviewService reviewService;

	@Autowired
	ReviewHateaosService refLinks;

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })

	@ApiOperation(value = "To provide a review for a product based on it's product Id by an User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to give a review for a product")
	@RequestMapping(value = "/giveReview", method = RequestMethod.POST)
	public Resource<Response> createReview(@RequestParam String review, @RequestParam int productId) {
		log.info("productid is-->" + productId);
		log.info("review is-->" + review);
		log.info("user name is-->" + reviewService.getCurrentUserName());
		return refLinks
				.createReview((reviewService.createReview(productId, review, reviewService.getCurrentUserName())));
	}

	@GetMapping("/getAllReviewsForUser")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 704, message = "Error", response = Response.class) })
	@ApiOperation(value = "To get all the reviews given by the User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to view all his/her reviews")
	public ResponseReviewList getAllReviewsForUser() {
		log.info("getting all the reviews of a particular user");
		return reviewService.getAllReviewsForUser(reviewService.getCurrentUserName());
	}

	@RequestMapping(value = "/giveRating", method = RequestMethod.POST)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "To provide a rating for a product based on it's product Id by an User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to give a rating for a product")
	public Resource<Response> giveRating(@RequestParam int rating, @RequestParam int productId) {
		log.info("productId-->" + productId);
		log.info("reting is-->" + rating);
		return refLinks.giveRating((reviewService.giveRating(productId, rating, reviewService.getCurrentUserName())));
	}

	@GetMapping("/getAllRatingsForUser")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 704, message = "Error", response = Response.class) })
	@ApiOperation(value = "To get all the ratings given by the User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to view all his/her ratings")
	public RatingResponseList getAllRatingsForUser() {
		log.info("getting all the reviews of a particular user");
		return reviewService.getAllRatingsForUser(reviewService.getCurrentUserName());
	}

	@GetMapping("/getReview")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "To obtain a particular review of a particular product based on review Id", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to view  his/her review based on review Id")
	public Resource<ReviewResponse> getReviewById(@RequestParam int reviewId) {
		return refLinks.getReviewById((reviewService.getReviewById(reviewId, reviewService.getCurrentUserName())));
	}

	@GetMapping("/getRating")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "To obtain a particular rating of a particular product based on rating Id", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to view  his/her review based on rating Id")
	public Resource<RatingResponse> getRatingById(@RequestParam int ratingId) {
		return refLinks.getRatingById((reviewService.getRatingById(ratingId, reviewService.getCurrentUserName())));
	}

	@PutMapping("/updateReview")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "To update a particular review of a particular product based on review Id which is previously given by User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to update  his/her review based on review Id")
	public Resource<Response> updateReview(@RequestParam int reviewId, @RequestParam String review) {
		return refLinks.updateReview((reviewService.updateReview(reviewId, review,reviewService.getCurrentUserName())));
	}

	@PutMapping("/updateRating")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "To update a particular rating of a particular product based on rating Id which is previously given by User", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform operations about review and rating") }) }, produces = "application/json", notes = "Customer is allowed to update  his/her rating based on rating Id")
	public Resource<Response> updateRating(@RequestParam int ratingId, @RequestParam int rating) {
		return refLinks.updateRating((reviewService.updateRating(ratingId, rating,reviewService.getCurrentUserName())));
	}

	@GetMapping("/getAllReviews")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 704, message = "Error", response = Response.class) })
	@ApiOperation(value = "To get all the reviews")
	public ResponseReviewList getAllReviews() {
		log.info("getting all the reviews of a particular user");
		return reviewService.getAllReviews();
	}

	@GetMapping("/getAllRatings")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 704, message = "Error", response = Response.class) })
	@ApiOperation(value = "To get all the ratings ")
	public RatingResponseList getAllRatings() {
		log.info("getting all the reviews of a particular user");
		return reviewService.getAllRatings();
	}
}
