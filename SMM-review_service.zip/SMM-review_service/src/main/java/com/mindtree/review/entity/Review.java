package com.mindtree.review.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "smm_review")
@ApiModel(description = "Information of the Reviews")
public class Review {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReviewID")
	@ApiModelProperty(notes = "Id attribute for review identification.")
	private int reviewId;

	@Column(name = "Description")
	@ApiModelProperty(notes = "Review for the product.")
	private String description;

	@Column(name = "userId")
	@ApiModelProperty(notes = "User who can give a review.")
	private String userName;

	@Column(name = "productId")
	@ApiModelProperty(notes = "Id of the product for which a user can provide a review.")
	private int productId;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public String getReview() {
		return description;
	}

	public void setReview(String description) {
		this.description = description;
	}

}
