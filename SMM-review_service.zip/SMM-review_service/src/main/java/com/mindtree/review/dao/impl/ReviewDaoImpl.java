package com.mindtree.review.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.review.dao.ReviewDao;
import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.utility.RatingRepository;
import com.mindtree.review.utility.ReviewRepository;

@Service
public class ReviewDaoImpl implements ReviewDao {

	@Autowired
	ReviewRepository reviewRepository;

	@Autowired
	ReviewDao reviewDao;

	@Autowired
	RatingRepository ratingRepository;

	public Review createReview(Review review) throws Exception {
		return reviewRepository.save(review);
	}

	public List<Review> getAllReviewsForUser(String username) throws Exception {
		return reviewRepository.findReviewByUserName(username);
	}

	public Rating giveRating(Rating rating) throws Exception {
		return ratingRepository.save(rating);
	}

	public List<Rating> getAllRatingsForUser(String username) throws Exception {
		return ratingRepository.findRatingByUserName(username);
	}

	public Optional<Review> getByReviewId(int reviewId, String username) throws Exception {
		return reviewRepository.findById(reviewId);
	}

	public Optional<Rating> getByRatingId(int ratingId, String username) throws Exception {
		return ratingRepository.findById(ratingId);
	}

	public Review updateReview(int reviewId, String review,String username) throws Exception {
		Review reviewObject = reviewRepository.findById(reviewId).get();

		reviewObject.setReview(review);
		return reviewRepository.save(reviewObject);

	}

	public Rating updateRating(int ratingId, int rating,String username) throws Exception {
		Rating ratingObject = ratingRepository.findById(ratingId).get();
		ratingObject.setRating(rating);
		return ratingRepository.save(ratingObject);
	}

	@Override
	public List<Review> getAllReviews() throws Exception {
		List<Review> reviews = reviewRepository.findAll();
		return reviews;
	}

	@Override
	public List<Rating> getAllRatings() throws Exception {
		List<Rating> ratings = ratingRepository.findAll();
		return ratings;
	}

}
