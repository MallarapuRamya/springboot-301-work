package com.mindtree.review.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;
import com.mindtree.review.service.ReviewHateaosService;

@SuppressWarnings("unused")
@Service
public class ReviewHateaosServiceImpl implements ReviewHateaosService {

	@Value("${baseurl}")
	String baseurl;

	@Override
	public Resource<Response> createReview(Response response) {
		Resource<Response> resource = new Resource<Response>(response);
		if (response.getStatusCode() == 204) {
			return resource;
		}
		Link link1 = new Link(baseurl + "reviews/review/getAllReviews");
		resource.add(link1);
		return resource;
	}

	@Override
	public Resource<Response> giveRating(Response response) {
		Resource<Response> resource = new Resource<Response>(response);
		if (response.getStatusCode() == 204) {
			return resource;
		}
		Link link1 = new Link(baseurl + "reviews/review/getAllRatings");
		resource.add(link1);
		return resource;
	}

	@Override
	public Resource<ReviewResponse> getReviewById(ReviewResponse reviewResponse) {
		Resource<ReviewResponse> resource = new Resource<ReviewResponse>(reviewResponse);
		if (reviewResponse.getStatusCode() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl + "reviews/review/getAllReviews");
		resource.add(link1);
		return resource;
	}

	@Override
	public Resource<RatingResponse> getRatingById(RatingResponse ratingResponse) {
		Resource<RatingResponse> resource = new Resource<RatingResponse>(ratingResponse);
		if (ratingResponse.getStatusCode() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl + "reviews/review/getAllRatings");
		resource.add(link1);
		return resource;
	}

	@Override
	public Resource<Response> updateReview(Response response) {
		Resource<Response> resource = new Resource<Response>(response);
		if (response.getStatusCode() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl + "reviews/review/getAllReviews");
		resource.add(link1);
		return resource;
	}

	@Override
	public Resource<Response> updateRating(Response response) {
		Resource<Response> resource = new Resource<Response>(response);
		if (response.getStatusCode() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl + "reviews/review/getAllRatings");
		resource.add(link1);
		return resource;
	}

}
