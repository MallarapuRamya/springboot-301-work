package com.mindtree.review.exceptions;

public class RatingNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public RatingNotFoundException() {
		super();
	}

	public RatingNotFoundException(String arg0) {
		super(arg0);
	}
}
