package com.mindtree.review.service;

import org.springframework.stereotype.Service;
import com.mindtree.review.response.entity.RatingResponse;
import com.mindtree.review.response.entity.RatingResponseList;
import com.mindtree.review.response.entity.Response;
import com.mindtree.review.response.entity.ResponseReviewList;
import com.mindtree.review.response.entity.ReviewResponse;

@Service
public interface ReviewService {

	public Response createReview(int ProductId, String review, String username);

	public ResponseReviewList getAllReviewsForUser(String username);

	public Response giveRating(int productId, int rating, String username);

	public RatingResponseList getAllRatingsForUser(String username);

	public ReviewResponse getReviewById(int reviewId, String username);

	public RatingResponse getRatingById(int ratingId, String username);

	public Response updateReview(int reviewId, String review,String username);

	public Response updateRating(int ratingId, int rating,String username);

	public String getCurrentUserName();

	public ResponseReviewList getAllReviews();

	public RatingResponseList getAllRatings();
}
