package com.mindtree.review.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.review.entity.Rating;
import com.mindtree.review.entity.Review;

@Service
public interface ReviewDao {

	public Review createReview(Review review) throws Exception;

	public List<Review> getAllReviewsForUser(String username) throws Exception;

	public Rating giveRating(Rating rating) throws Exception;

	public List<Rating> getAllRatingsForUser(String username) throws Exception;

	public Optional<Review> getByReviewId(int reviewId, String username) throws Exception;

	public Optional<Rating> getByRatingId(int ratingId, String username) throws Exception;

	public Review updateReview(int reviewId, String review,String username) throws Exception;

	public Rating updateRating(int ratingId, int rating,String username) throws Exception;

	public List<Review> getAllReviews() throws Exception;

	public List<Rating> getAllRatings() throws Exception;
}
