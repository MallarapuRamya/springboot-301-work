package com.mindtree.review.response.entity;

import java.util.List;

import com.mindtree.review.entity.Rating;

public class RatingResponseList extends Response {

	private List<Rating> rating;

	public List<Rating> getRating() {
		return rating;
	}

	public void setRating(List<Rating> rating) {
		this.rating = rating;
	}

}
