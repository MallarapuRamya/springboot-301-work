package com.mindtree.review.utility;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.mindtree.review.entity.Rating;

@Service
public interface RatingRepository extends JpaRepository<Rating, Integer> {

	public List<Rating> findRatingByUserName(String username);
}
