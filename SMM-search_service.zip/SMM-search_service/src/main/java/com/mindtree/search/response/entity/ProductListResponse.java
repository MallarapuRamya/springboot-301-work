package com.mindtree.search.response.entity;

import java.util.List;

import com.mindtree.search.entity.Product;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational(List) response to be shown for the request.")
public class ProductListResponse extends Response {

	@ApiModelProperty(notes="List of Product details")
	private List<Product> productList;

	public ProductListResponse() {
	}

	public ProductListResponse(int status_code, String message, List<Product> productList) {
		super(status_code, message);
		this.productList = productList;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

}
