package com.mindtree.search.service.impl;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.search.entity.Product;
import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.service.SearchHateoasService;

@Service
public class SearchHateoasServiceImpl implements SearchHateoasService {
	@Value("${baseurl}")
	String baseurl;

	@Override
	public Resource<ProductListResponse> getAllProducts(ProductListResponse allProducts) {

		Resource<ProductListResponse> resource = new Resource<ProductListResponse>(allProducts);

		if (!CollectionUtils.isEmpty(allProducts.getProductList())) {
			
			for (Product product : allProducts.getProductList()) {

				Link link1 = new Link(
						baseurl + "products/modelName/" + product.getModelName().replaceAll(" ", "%20"));
				resource.add(link1);

				Link link2 = new Link(baseurl + "products/budget/" + product.getPrice());
				resource.add(link2);

				Link link3 = new Link(baseurl + "products/type/" + product.getType());
				resource.add(link3);

				Link link4 = new Link(baseurl + "products/sellerType/" + product.getSellerType());
				resource.add(link4);

			}
		}

		return resource;

	}

	@Override
	public Resource<ProductListResponse> getByModelName(ProductListResponse allProducts) {
		
		Resource<ProductListResponse> resource = new Resource<ProductListResponse>(allProducts);
		
		if (!CollectionUtils.isEmpty(allProducts.getProductList())) {
			
			Link link1 = new Link(baseurl + "products/all");
			resource.add(link1);
			
			for (Product product : allProducts.getProductList()) {
				Link link2 = new Link(baseurl + "products/budget/" + product.getPrice());
				resource.add(link2);
				Link link3 = new Link(baseurl + "products/type/" + product.getType());
				resource.add(link3);
				Link link4 = new Link(baseurl + "products/sellerType/" + product.getSellerType());
				resource.add(link4);
			}
		}

		return resource;
	}

	@Override
	public Resource<ProductListResponse> getByBudget(ProductListResponse allProducts) {
		
		Resource<ProductListResponse> resource = new Resource<ProductListResponse>(allProducts);
		
		if (!CollectionUtils.isEmpty(allProducts.getProductList())) {
			
			Link link1 = new Link(baseurl + "products/all");
			resource.add(link1);
			
			for (Product product : allProducts.getProductList()) {
				Link link2 = new Link(
						baseurl + "products/modelName/" + product.getModelName().replaceAll(" ", "%20"));
				resource.add(link2);
				Link link3 = new Link(baseurl + "products/type/" + product.getType());
				resource.add(link3);
				Link link4 = new Link(baseurl + "products/sellerType/" + product.getSellerType());
				resource.add(link4);
			}
		}

		return resource;
	}

	@Override
	public Resource<ProductListResponse> getByType(ProductListResponse allProducts) {
		
		Resource<ProductListResponse> resource = new Resource<ProductListResponse>(allProducts);
		
		if (!CollectionUtils.isEmpty(allProducts.getProductList())) {
			
			Link link1 = new Link(baseurl + "products/all");
			resource.add(link1);
			for (Product product : allProducts.getProductList()) {
				Link link2 = new Link(
						baseurl + "products/modelName/" + product.getModelName().replaceAll(" ", "%20"));
				resource.add(link2);

				Link link3 = new Link(baseurl + "products/budget/" + product.getPrice());
				resource.add(link3);
				Link link4 = new Link(baseurl + "products/sellerType/" + product.getSellerType());
				resource.add(link4);

			}
		}

		return resource;

	}

	@Override
	public Resource<ProductListResponse> getBySellerType(ProductListResponse allProducts) {
		
		Resource<ProductListResponse> resource = new Resource<ProductListResponse>(allProducts);
		
		if (!CollectionUtils.isEmpty(allProducts.getProductList())) {
			
			Link link1 = new Link(baseurl + "products/all");
			resource.add(link1);
			for (Product product : allProducts.getProductList()) {
				Link link2 = new Link(
						baseurl + "products/modelName/" + product.getModelName().replaceAll(" ", "%20"));
				resource.add(link2);

				Link link3 = new Link(baseurl + "products/budget/" + product.getPrice());
				resource.add(link3);

				Link link4 = new Link(baseurl + "products/type/" + product.getType());
				resource.add(link4);

			}
		}

		return resource;
	}
}
