package com.mindtree.search.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.search.response.entity.ProductListResponse;

@Service
public interface SearchHateoasService {

	Resource<ProductListResponse> getAllProducts(ProductListResponse allProducts);

	Resource<ProductListResponse> getByModelName(ProductListResponse allProducts);

	Resource<ProductListResponse> getByBudget(ProductListResponse allProducts);

	Resource<ProductListResponse> getByType(ProductListResponse allProducts);

	Resource<ProductListResponse> getBySellerType(ProductListResponse allProducts);

}
