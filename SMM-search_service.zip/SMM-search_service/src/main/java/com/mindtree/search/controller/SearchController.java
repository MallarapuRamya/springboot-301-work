package com.mindtree.search.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.response.entity.ProductResponse;
import com.mindtree.search.response.entity.Response;
import com.mindtree.search.service.SearchHateoasService;
import com.mindtree.search.service.SearchService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/products")
@Api(value = " Search service for users", description = "Search service is used to search products based on Model-Name, Type, Budget and Seller-Type.", tags = { "Product Search" })
public class SearchController {

	@Autowired
	private SearchService searchService;

	@Autowired
	private SearchHateoasService refLinks;

	private static final Logger LOG = LoggerFactory.getLogger(SearchController.class);
	
	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get all available products", notes="This functionality is used for internal service communication")
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	
	public ProductListResponse getAllProducts() {	
		LOG.debug("Entered Controller of Get All Available products");
		return searchService.getAllProducts();
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get products on the basis of Model Name")
	@RequestMapping(value = "/modelName/{modelName}", method = RequestMethod.GET)
	
	public Resource<ProductListResponse> getByModelName(@PathVariable String modelName) {	
		LOG.debug("Entered Controller of Get Products On the basis of Model Name");
		return refLinks.getByModelName(searchService.findProductByModelName(modelName));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get products on the basis of Budget")
	@RequestMapping(value = "/budget/{price}", method = RequestMethod.GET)
	
	public Resource<ProductListResponse> getByBudget(@PathVariable double price) {
		LOG.debug("Entered Controller of Get Products On the basis of Budget");
		return refLinks.getByBudget(searchService.findProductByBudget(price));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get products on the basis of Type")
	@RequestMapping(value = "/type/{type}", method = RequestMethod.GET)
	
	public Resource<ProductListResponse> getByType(@PathVariable String type)	{
		LOG.debug("Entered Controller of Get Products On the basis of Type");
		return refLinks.getByType(searchService.findProductByType(type));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get products on the basis of SellerType ")
	@RequestMapping(value = "/sellerType/{sellerType}", method = RequestMethod.GET)
	
	public Resource<ProductListResponse> getBySellerType(@PathVariable String sellerType) {	
		LOG.debug("Entered Controller of Get products on the basis of SellerType");
		return refLinks.getBySellerType(searchService.findProductBySellerType(sellerType));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get products details on the basis of ProductIds",notes="This functionality is used for internal microservices communication. Hence only the filtered/validated data should be passed as argument as it's already validated at cart service and order service.")
	@RequestMapping(value = "/productsByIds", method = RequestMethod.POST,consumes="application/json")
	
	public ProductListResponse getByProductIds(@RequestBody List<Integer> productIds) {	
		LOG.debug("Entered Controller of Get Product Details On the basis of ProductIds");
		return searchService.findProductsByProductIds(productIds);
	}
	
	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "Get product details on the basis of ProductId",notes="This functionality is used for internal microservices communication. Hence only the filtered/validated data should be passed as argument as it's already validated at cart service and order service")
	@RequestMapping(value = "/productById/{productId}", method = RequestMethod.GET)
	
	public ProductResponse getProductByProductId(@PathVariable int productId) {	
		LOG.debug("Entered Controller of Get Product Details On the basis of ProductId");
		return searchService.findProductByProductId(productId);
	}
}