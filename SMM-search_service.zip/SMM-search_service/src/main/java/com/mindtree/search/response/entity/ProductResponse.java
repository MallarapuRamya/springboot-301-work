package com.mindtree.search.response.entity;

import com.mindtree.search.entity.Product;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel(description="Informational response to be shown for the request.")
public class ProductResponse extends Response {
	
	@ApiModelProperty(notes="Product Details.")
	private Product product;

	public ProductResponse() {

	}

	public ProductResponse(int status_code, String message,Product product) {
		super(status_code, message);
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
}
