package com.mindtree.search.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.search.response.entity.ProductResponse;
import com.mindtree.search.response.entity.ProductListResponse;

@Service
public interface SearchService {

	public ProductListResponse findProductByModelName(String modelName);

	public ProductListResponse findProductByBudget(double price);

	public ProductListResponse findProductByType(String type);

	public ProductListResponse findProductBySellerType(String sellerType);

	public ProductListResponse getAllProducts();

	public ProductListResponse findProductsByProductIds(List<Integer> productIds);
	
	public ProductResponse findProductByProductId(int productId);
}
