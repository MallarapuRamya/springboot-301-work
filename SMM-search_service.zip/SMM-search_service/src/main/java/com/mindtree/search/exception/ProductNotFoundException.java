package com.mindtree.search.exception;

@SuppressWarnings("serial")
public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String msg) {
		super(msg);
	}
}
