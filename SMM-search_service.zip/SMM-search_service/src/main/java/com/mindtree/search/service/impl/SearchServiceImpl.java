package com.mindtree.search.service.impl;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mindtree.search.dao.impl.SearchDaoImpl;
import com.mindtree.search.entity.Product;
import com.mindtree.search.exception.ProductNotFoundException;
import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.response.entity.ProductResponse;
import com.mindtree.search.service.SearchService;

@Service
public class SearchServiceImpl implements SearchService {

	private static final Logger LOG = LoggerFactory.getLogger(SearchServiceImpl.class);

	@Value("${success_code}")
	private int success_code;
	@Value("${error_code}")
	private int error_code;

	@Autowired
	SearchDaoImpl daoImpl;

	@Override
	public ProductListResponse findProductByModelName(String modelName) {

		LOG.debug("Entered Service implementation of Get Products By ModelName");
		ProductListResponse productListResponse = new ProductListResponse();

		try {
			List<Product> productlist = daoImpl.findProductByModelName(modelName);
			try {

				if (!CollectionUtils.isEmpty(productlist)) {
					productListResponse.setProductList(productlist);
					productListResponse.setStatus_code(success_code);
					productListResponse.setMessage("List of Products.");
				} else {
					throw new ProductNotFoundException("No results found for Model Name : " + modelName);
				}

			} catch (ProductNotFoundException e) {
				e.printStackTrace();
				LOG.error(e.getMessage());
				productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results Found");
				productListResponse.setProductList(null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Something went wrong, please refer logs");
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}
		return productListResponse;
	}

	@Override
	public ProductListResponse findProductByBudget(double price) {

		LOG.debug("Entered Service implementation of Get Products By Budget");
		ProductListResponse productListResponse = new ProductListResponse();
		try {
			List<Product> productlist = daoImpl.findProductByBudget(price);

			try {

				if (!CollectionUtils.isEmpty(productlist)) {
					productListResponse.setProductList(productlist);
					productListResponse.setStatus_code(success_code);
					productListResponse.setMessage("List of Products.");
				} else {
					throw new ProductNotFoundException("No results found of Budget : " + price);
				}

			} catch (ProductNotFoundException e) {
				e.printStackTrace();
				LOG.error(e.getMessage());
				productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results Found ");
				productListResponse.setProductList(null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Something went wrong, please refer logs");
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}

		return productListResponse;
	}

	@Override
	public ProductListResponse findProductByType(String type) {

		LOG.debug("Entered Service implementation of Get Products By Type");
		ProductListResponse productListResponse = new ProductListResponse();
		try {
			List<Product> productlist = daoImpl.findProductByType(type);
			try {

				if (!CollectionUtils.isEmpty(productlist)) {

					productListResponse.setProductList(productlist);
					productListResponse.setStatus_code(success_code);
					productListResponse.setMessage("List of Products.");
				} else {
					throw new ProductNotFoundException("No results found for Type : " + type);
				}

			} catch (ProductNotFoundException e) {
				LOG.error(e.getMessage());
				e.printStackTrace();
				productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results Found");
				productListResponse.setProductList(null);
			}
		} catch (Exception e) {
			LOG.error("Something went wrong, please refer logs");
			e.printStackTrace();
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}
		return productListResponse;

	}

	@Override
	public ProductListResponse findProductBySellerType(String sellerType) {

		LOG.debug("Entered Service implementation of Get Products By SellerType");
		ProductListResponse productListResponse = new ProductListResponse();
		try {
			List<Product> productlist = daoImpl.findProductBySellerType(sellerType);

			try {

				if (!CollectionUtils.isEmpty(productlist)) {

					productListResponse.setProductList(productlist);
					productListResponse.setStatus_code(success_code);
					productListResponse.setMessage("List of Products.");
				} else {
					throw new ProductNotFoundException("No results found for SellerType : " + sellerType);
				}

			} catch (ProductNotFoundException e) {
				LOG.error(e.getMessage());
				e.printStackTrace();
				productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results Found");
				productListResponse.setProductList(null);

			}
		} catch (Exception e) {
			LOG.error("Something went wrong, please refer logs");
			e.printStackTrace();
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}
		return productListResponse;
	}

	public ProductListResponse getAllProducts() {

		LOG.debug("Entered Service implementation of Get All Products");
		ProductListResponse productListResponse = new ProductListResponse();
		try {
			
			List<Product> productlist = daoImpl.getAllProducts();
            try
            {
			if (!CollectionUtils.isEmpty(productlist)) {

				productListResponse.setProductList(productlist);
				productListResponse.setStatus_code(success_code);
				productListResponse.setMessage("List of Products.");
			} else {
				throw new ProductNotFoundException("No results found");
			}
            }
            catch(ProductNotFoundException e){
            	LOG.error(e.getMessage());
				e.printStackTrace();
            	productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results Found");
				productListResponse.setProductList(null);
            }
		} catch (Exception e) {
			LOG.error("Something went wrong, please refer logs");
			e.printStackTrace();
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}
		return productListResponse;
	}

	@Override
	public ProductListResponse findProductsByProductIds(List<Integer> productIds) {
		LOG.debug("entered Service Implementation of Get Products by Product Ids");
		ProductListResponse productListResponse = new ProductListResponse();
		try
		{
	     	List<Product> productlist = daoImpl.findProductsByProductIds(productIds);
	     	try
            {
			if (!CollectionUtils.isEmpty(productlist)) {

				productListResponse.setProductList(productlist);
				productListResponse.setStatus_code(success_code);
				productListResponse.setMessage("List of Products.");
			} else {
				throw new ProductNotFoundException("No results found");
			}
            }
            catch(ProductNotFoundException e){
            	LOG.error(e.getMessage());
				e.printStackTrace();
            	productListResponse.setStatus_code(error_code);
				productListResponse.setMessage("No results found");
				productListResponse.setProductList(null);
            }
		} 
		catch (Exception e) {
			LOG.error("Something went wrong, please refer logs");
			e.printStackTrace();
			return new ProductListResponse(204, "Something went Wrong while Connectiong to database, Please Try again Later", null);
		}		 
		return productListResponse;
	}

	@Override
	public ProductResponse findProductByProductId(int productId) {
		LOG.debug("entered Service Implementation of Get Product by Product Id");
		ProductResponse productResponse = new ProductResponse();
		try {
			
			Optional<Product> product = daoImpl.findProductByProductId(productId);
			try {
				if (product.isPresent()) {
					productResponse.setProduct(product.get());
					productResponse.setStatus_code(success_code);
					productResponse.setMessage("Product Details");
				} else {
					throw new ProductNotFoundException("No results found for given product Id " + productId);
				}
			} catch (ProductNotFoundException e) {
				LOG.error(e.getMessage());
				e.printStackTrace();
				productResponse.setStatus_code(error_code);
				productResponse.setMessage("No results Found for given product Id");
				productResponse.setProduct(null);
			}
			
		} catch (Exception e) {
			LOG.error("Something went wrong while Connectiong to database, please refer logs");
			e.printStackTrace();
			return new ProductResponse(204, "Something went wrong while Connectiong to database, Please Try again Later", null);
		}
		return productResponse;

	}
}
