package com.mindtree.search.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.search.dao.SearchDao;
import com.mindtree.search.entity.Product;
import com.mindtree.search.exception.ProductNotFoundException;
import com.mindtree.search.repository.SearchRepository;

@Service
public class SearchDaoImpl implements SearchDao {

	private static final Logger LOG = LoggerFactory.getLogger(SearchDaoImpl.class);

	@Autowired
	SearchRepository searchRepository;

	@Override
	public List<Product> findProductByModelName(String modelName) throws Exception {

		LOG.debug("Entered Dao Implementation of Get Products by model name");
		List<Product> products = searchRepository.findProductByModelName((modelName));
		return products;
	}

	@Override
	public List<Product> findProductByBudget(double price) throws Exception {
		LOG.debug("Entered Dao Implementation of Get Products by Budget");
		return searchRepository.findProductByBudget(price);
	}

	@Override
	public List<Product> findProductByType(String type) throws Exception {
		LOG.debug("Entered Dao Implementation of Get Products by Type");
		return searchRepository.findProductByType(type);
	}

	@Override
	public List<Product> findProductBySellerType(String sellerType) throws Exception {
		LOG.debug("Entered Dao Implementation of Get Products by SellerType");
		return searchRepository.findProductBySellerType(sellerType);
	}

	@Override
	public List<Product> getAllProducts() throws Exception {
		LOG.debug("Entered Dao Implementation of Get All Products");
		return searchRepository.findAll();
	}

	public Optional<Product> findProductByProductId(int productId) throws Exception {
		LOG.info("Entered Implementation of Get Product by productId");
		return searchRepository.findById(productId);
	}

	@SuppressWarnings("finally")
	public List<Product> findProductsByProductIds(List<Integer> productIds) throws Exception {
		LOG.info("Entered Implementation of Get Products by productIds");
		List<Product> productList = new ArrayList<>();
		try {
			for (Integer productId : productIds) {
				try
				{
				Optional<Product> product = searchRepository.findById(productId);
				if (product.isPresent()) {
					productList.add(product.get());
				} else {
					throw new ProductNotFoundException("No results found for given product Ids " + productId);
				}
				}
				catch (ProductNotFoundException e) {
					LOG.error(e.getMessage());
					e.printStackTrace();
				}
			}
		}  finally {
			return productList;
		}
	}
}
