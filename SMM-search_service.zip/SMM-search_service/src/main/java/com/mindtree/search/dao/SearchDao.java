package com.mindtree.search.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.search.entity.Product;

@Service
public interface SearchDao {
	public List<Product> findProductByModelName(String modelName) throws Exception;

	public List<Product> findProductByBudget(double price) throws Exception;

	public List<Product> findProductByType(String type) throws Exception;

	public List<Product> findProductBySellerType(String sellerType) throws Exception;

	public List<Product> getAllProducts() throws Exception;

	public Optional<Product> findProductByProductId(int productId) throws Exception;
	 
	public List<Product> findProductsByProductIds(List<Integer> productIds) throws Exception;
}
