package com.mindtree.search.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.search.entity.Product;

@Repository
public interface SearchRepository extends MongoRepository<Product, Integer> {

	public List<Product> findProductByModelName(String model_name);

	public List<Product> findProductByType(String type);

	public List<Product> findProductBySellerType(String seller_type);

	@Query("{ 'price' : { $lte: ?0 } }")
	public List<Product> findProductByBudget(double price);
}
