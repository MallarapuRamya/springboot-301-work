package com.mindtree.search;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.dao.impl.SearchDaoImpl;
import com.mindtree.search.entity.Product;
import com.mindtree.search.repository.SearchRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DaoLayerTests {
	@Mock
	SearchRepository repository;

	@InjectMocks
	@Spy
	SearchDaoImpl daoImpl;

	@Autowired
	SearchDaoImpl searchDaoImpl;

	@Test
	public void getAllProductsTestCase1() throws Exception {
		try {
			List<Product> products = searchDaoImpl.getAllProducts();
			assertNotNull(products);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}
	}

	@Test
	public void findProductByModelNameTestCase1() throws Exception {
		Product product = new Product();
		List<Product> products = new ArrayList<>();
		product.setProductId(100);
		product.setModelName("Galaxy S9");
		product.setPrice(25000);
		product.setSellerType("samsung");
		product.setType("smartphone");
		product.setDescription("product description");
		products.add(product);
		when(repository.findProductByModelName("Galaxy S9")).thenReturn(products);
		try {
			assertEquals(products, daoImpl.findProductByModelName("Galaxy S9"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void findProductByModelNameTestCase2() throws Exception {

		try {
			List<Product> productlist = new ArrayList<>();
			List<Product> products = searchDaoImpl.findProductByModelName("abcdefg");
			assertEquals(productlist, products);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}

	}

	@Test
	public void findProductByTypeTestCase1() throws Exception {
		Product product = new Product();
		List<Product> products = new ArrayList<>();
		product.setProductId(100);
		product.setModelName("Galaxy S9");
		product.setPrice(25000);
		product.setSellerType("samsung");
		product.setType("smartphone");
		product.setDescription("product description");
		products.add(product);
		when(repository.findProductByType("smartphone")).thenReturn(products);
		try {
			assertEquals(products, daoImpl.findProductByType("smartphone"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void findProductByTypeTestCase2() throws Exception {

		try {
			List<Product> productlist = new ArrayList<>();
			List<Product> products = searchDaoImpl.findProductByType("abcd");
			assertEquals(productlist, products);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}

	}

	@Test
	public void findProductByBudgetTestCase1() throws Exception {
		Product product = new Product();
		List<Product> products = new ArrayList<>();
		product.setProductId(100);
		product.setModelName("Galaxy S9");
		product.setPrice(25000);
		product.setSellerType("samsung");
		product.setType("smartphone");
		product.setDescription("product description");
		products.add(product);
		when(repository.findProductByBudget(50000)).thenReturn(products);
		try {
			assertEquals(products, daoImpl.findProductByBudget(50000));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void findProductByBudgetTestCase2() throws Exception {
		try {
			List<Product> productlist = new ArrayList<>();
			List<Product> products = searchDaoImpl.findProductByBudget(0);
			assertEquals(productlist, products);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}
	}

	@Test
	public void findProductBySellerTypeTestCase1() throws Exception {
		Product product = new Product();
		List<Product> products = new ArrayList<>();
		product.setProductId(100);
		product.setModelName("Galaxy S9");
		product.setPrice(25000);
		product.setSellerType("samsung");
		product.setType("smartphone");
		product.setDescription("product description");
		products.add(product);
		when(repository.findProductBySellerType("samsung")).thenReturn(products);
		try {
			assertEquals(products, daoImpl.findProductBySellerType("samsung"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void findProductBySellerTypeTestCase2() throws Exception {
		try {
			List<Product> productlist = new ArrayList<>();
			List<Product> products = searchDaoImpl.findProductBySellerType("abcd");
			assertEquals(productlist, products);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}
	}

	@Test
	public void findProductByIdTestCase1() throws Exception {
		Product product = new Product();
		product.setProductId(100);
		product.setModelName("Galaxy S9");
		product.setPrice(25000);
		product.setSellerType("samsung");
		product.setType("smartphone");
		product.setDescription("product description");
		when(repository.findById(100)).thenReturn(Optional.of(product));
		try {
			assertEquals(product, (daoImpl.findProductByProductId(100)).get());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void findProductByIdTestCase2() throws Exception {
		
		Product product=null;
		try {
			List<Product> productlist=new ArrayList<>();
			product = searchDaoImpl.findProductByProductId(00).get();
			assertEquals(productlist, product);
		} catch (Exception e) {
			assertThat(e.getMessage(), is(e.getMessage()));
		}
	}
}
