package com.mindtree.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.controller.SearchController;
import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.response.entity.ProductResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerLayerTests {
	@Autowired
	private SearchController searchController;

	@Test
	public void getAllProductsTestCase() {
		ProductListResponse products = searchController.getAllProducts();
		assertNotNull(products);
		assertNotNull(products.getProductList());
		assertEquals(200, products.getStatus_code());
	}

	@Test
	public void getByModelNameTestCase() {
		Resource<ProductListResponse> products = searchController.getByModelName("abcd");
		assertNull(products.getContent().getProductList());
		assertEquals(204, products.getContent().getStatus_code());
	}

	@Test
	public void getByBudgetTestCase() {
		Resource<ProductListResponse> products = searchController.getByBudget(0);
		assertNull(products.getContent().getProductList());
		assertEquals(204, products.getContent().getStatus_code());
	}

	@Test
	public void getByTypeTestCase() {
		Resource<ProductListResponse> products = searchController.getByType("abcd");
		assertNull(products.getContent().getProductList());
		assertEquals(204, products.getContent().getStatus_code());
	}

	@Test
	public void getBySellerTypeTestCase() {
		Resource<ProductListResponse> products = searchController.getBySellerType("abcd");
		assertNull(products.getContent().getProductList());
		assertEquals(204, products.getContent().getStatus_code());
	}

	@Test
	public void getByProductIdsTestCase() {
		List<Integer> productIdList=new ArrayList<>();
		ProductListResponse products = searchController.getByProductIds(productIdList);
		assertNull(products.getProductList());
		assertEquals(204, products.getStatus_code());
	}

	@Test
	public void getProductByProductIdTestCase() {
		ProductResponse product = searchController.getProductByProductId(00);
		assertNull(product.getProduct());
		assertEquals(204, product.getStatus_code());
	}
}
