package com.mindtree.search;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.entity.Product;
import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.service.SearchHateoasService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HateoasTests {

	@Autowired
	SearchHateoasService hateoasService;
	
	@Test
	public void getAllProductsTestCase1()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		products.add(new Product(100,"Galaxy S9",20000,"smartphone","samsung","product description"));
		products.add(new Product(101,"Lenovo",10000,"smartphone","Lenovo","product description"));
		allProducts.setProductList(products);
		allProducts.setStatus_code(200);
		allProducts.setMessage("List of Products.");
		Resource<ProductListResponse> resource=hateoasService.getAllProducts(allProducts);
		assertNotNull(resource);
		assertNotNull(resource.getContent().getProductList());
		assertEquals(200,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getAllProductsTestCase2()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		allProducts.setProductList(products);
		allProducts.setStatus_code(204);
		allProducts.setMessage("No results Found");
		Resource<ProductListResponse> resource=hateoasService.getAllProducts(allProducts);
		assertEquals(products,resource.getContent().getProductList());
		assertEquals(204,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByModelNameTestCase1()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		products.add(new Product(100,"Galaxy S9",20000,"smartphone","samsung","product description"));
		products.add(new Product(101,"Lenovo",10000,"smartphone","Lenovo","product description"));
		allProducts.setProductList(products);
		allProducts.setStatus_code(200);
		allProducts.setMessage("List of Products.");
		Resource<ProductListResponse> resource=hateoasService.getByModelName(allProducts);
		assertNotNull(resource);
		assertNotNull(resource.getContent().getProductList());
		assertEquals(200,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByModelNameTestCase2()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		allProducts.setProductList(products);
		allProducts.setStatus_code(204);
		allProducts.setMessage("No results Found");
		Resource<ProductListResponse> resource=hateoasService.getByModelName(allProducts);
		assertEquals(products,resource.getContent().getProductList());
		assertEquals(204,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByBudgetTestCase1()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		products.add(new Product(100,"Galaxy S9",20000,"smartphone","samsung","product description"));
		products.add(new Product(101,"Lenovo",10000,"smartphone","Lenovo","product description"));
		allProducts.setProductList(products);
		allProducts.setStatus_code(200);
		allProducts.setMessage("List of Products.");
		Resource<ProductListResponse> resource=hateoasService.getByBudget(allProducts);
		assertNotNull(resource);
		assertNotNull(resource.getContent().getProductList());
		assertEquals(200,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByBudgetTestCase2()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		allProducts.setProductList(products);
		allProducts.setStatus_code(204);
		allProducts.setMessage("No results Found");
		Resource<ProductListResponse> resource=hateoasService.getByBudget(allProducts);
		assertEquals(products,resource.getContent().getProductList());
		assertEquals(204,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByTypeTestCase1()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		products.add(new Product(100,"Galaxy S9",20000,"smartphone","samsung","product description"));
		products.add(new Product(101,"Lenovo",10000,"smartphone","Lenovo","product description"));
		allProducts.setProductList(products);
		allProducts.setStatus_code(200);
		allProducts.setMessage("List of Products.");
		Resource<ProductListResponse> resource=hateoasService.getByType(allProducts);
		assertNotNull(resource);
		assertNotNull(resource.getContent().getProductList());
		assertEquals(200,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getByTypeTestCase2()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		allProducts.setProductList(products);
		allProducts.setStatus_code(204);
		allProducts.setMessage("No results Found");
		Resource<ProductListResponse> resource=hateoasService.getByType(allProducts);
		assertEquals(products,resource.getContent().getProductList());
		assertEquals(204,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getBySellerTypeTestCase1()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		products.add(new Product(100,"Galaxy S9",20000,"smartphone","samsung","product description"));
		products.add(new Product(101,"Lenovo",10000,"smartphone","Lenovo","product description"));
		allProducts.setProductList(products);
		allProducts.setStatus_code(200);
		allProducts.setMessage("List of Products.");
		Resource<ProductListResponse> resource=hateoasService.getBySellerType(allProducts);
		assertNotNull(resource);
		assertNotNull(resource.getContent().getProductList());
		assertEquals(200,resource.getContent().getStatus_code());
	}
	
	@Test
	public void getBySellerTypeTestCase2()
	{
		ProductListResponse allProducts=new ProductListResponse();
		List<Product> products=new ArrayList<>();
		allProducts.setProductList(products);
		allProducts.setStatus_code(204);
		allProducts.setMessage("No results Found");
		Resource<ProductListResponse> resource=hateoasService.getBySellerType(allProducts);
		assertEquals(products,resource.getContent().getProductList());
		assertEquals(204,resource.getContent().getStatus_code());
	}

}
