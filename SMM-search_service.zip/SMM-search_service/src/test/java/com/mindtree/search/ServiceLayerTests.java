package com.mindtree.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.dao.SearchDao;
import com.mindtree.search.entity.Product;
import com.mindtree.search.exception.ProductNotFoundException;
import com.mindtree.search.response.entity.ProductListResponse;
import com.mindtree.search.response.entity.ProductResponse;
import com.mindtree.search.service.impl.SearchServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTests {
	@Mock
	SearchDao searchDao;
	
	@InjectMocks
	@Spy
	SearchServiceImpl serviceImpl;
	
	@Autowired
	SearchServiceImpl searchServiceImpl;

	@Test
	public void getAllProductsTestCase1() {
		ProductListResponse products = searchServiceImpl.getAllProducts();
		assertNotNull(products);
		assertNotNull(products.getProductList());
		assertEquals(200, products.getStatus_code());
		assertNotNull(products.getMessage());
	}
	
	@Test
	public void getAllProductsTestCase2() {
		List<Product> productList = new ArrayList<>();

		try {
			when(searchDao.getAllProducts()).thenReturn(productList);
		} catch (Exception e) {
			e.printStackTrace();
		}

		assertEquals(204, serviceImpl.getAllProducts().getStatus_code());
		assertNull(serviceImpl.getAllProducts().getProductList());
		assertNotNull(serviceImpl.getAllProducts().getMessage());
	}

	@Test
	public void findProductByModelNameTestCase() throws ProductNotFoundException {

		ProductListResponse productlist = new ProductListResponse();
		ProductListResponse products=null;
		try
		{
			products = searchServiceImpl.findProductByModelName("abcd");
		}
		catch(Exception e)
		{
		assertEquals(productlist.getProductList(), products.getProductList());
		assertEquals(204, products.getStatus_code());
		}
	}

	@Test
	public void findProductByBudgetTestCase() throws ProductNotFoundException{
		
		ProductListResponse productlist = new ProductListResponse();
		ProductListResponse products=null;
		try
		{
		   products = searchServiceImpl.findProductByBudget(0);
		}
		catch(Exception e)
		{
		assertEquals(productlist.getProductList(), products.getProductList());
		assertEquals(204, products.getStatus_code());
		}
	}

	@Test
	public void findProductByTypeTestCase() throws ProductNotFoundException {

		ProductListResponse productlist = new ProductListResponse();
		ProductListResponse products=null;
		try
		{
		   products = searchServiceImpl.findProductByType("abcd");
		}
		catch(Exception e)
		{
		assertEquals(productlist.getProductList(), products.getProductList());
		assertEquals(204, products.getStatus_code());
		}
	}


	@Test
	public void findProductBySellerTypeTestCase() throws ProductNotFoundException {
	
		ProductListResponse productlist = new ProductListResponse();
		ProductListResponse products=null;
		try{
			products = searchServiceImpl.findProductBySellerType("abcd");
		}
		catch(Exception e)
		{
		assertEquals(productlist.getProductList(), products.getProductList());
		assertEquals(204, products.getStatus_code());
		}
		}

	@Test
	public void findProductByProductIdTestCase() throws ProductNotFoundException {
		ProductResponse product=null;
		try
		{
		    product = searchServiceImpl.findProductByProductId(00);
		}
		catch(Exception e)
		{
		assertNull(product.getProduct());
		assertEquals(204, product.getStatus_code());
		}
		}
	

	@Test
	public void getProductsByProductIdsTestCase() throws ProductNotFoundException {
		List<Integer> productIdList=new ArrayList<>();
		ProductListResponse product=null;
		try
		{
		product = searchServiceImpl.findProductsByProductIds(productIdList);
		}
		catch(Exception e)
		{
		assertNull(product.getProductList());
		assertEquals(204, product.getStatus_code());
		}
	}
}
