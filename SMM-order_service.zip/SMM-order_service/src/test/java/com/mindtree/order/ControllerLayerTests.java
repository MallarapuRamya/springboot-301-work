package com.mindtree.order;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.controller.OrderController;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.OrderServiceHateoas;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerLayerTests {

	@Mock
	OrderService service;
	
	@Mock
	OrderServiceHateoas hateoas;
	
	@InjectMocks
	OrderController controller;
	
	UserAddress address=new UserAddress();
	OrderIdResponse orderIdResponse=new OrderIdResponse();
	Cart cart=new Cart();
	Map<Integer,Integer> items= new HashMap<Integer, Integer>();
	CartResponse cartresponse=new CartResponse();
	Order order=new Order();
	OrderListResponse olr=new OrderListResponse();
	Response response=new Response();
	List<Order> orderlist=new ArrayList<Order>();
	OrderResponse orderesponse=new OrderResponse();
	
	String username="user@user.use";
	
	@Before
	public void initialize()
	{
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Line1");
		address.setAddressId(10);
		
		orderIdResponse.setOrder(new Order());
		orderIdResponse.setStatus_code(200);
		orderIdResponse.setOrderId(101);
		orderIdResponse.setMessage("Message");
		
		cart.setActive(true);
		cart.setCartId(1);
		cart.setItems(items);
		cart.setTotalAmount(20000);
		cart.setUserName(username);
		
		items.put(101, 1);
		items.put(102, 5);
		items.put(104, 3);
		items.put(106, 2);
		
		cartresponse.setCart(cart);

		order.setAddress(address);
		order.setItems(cart.getItems());
		order.setOrderId(10);
		order.setUserName(username);
		order.setTotalAmount(cart.getTotalAmount());
		
		response.setStatus_code(200);
		response.setMessage("message");

		orderlist.add(order);
		olr.setStatus_code(200);
		olr.setMessage("Message");
		olr.setUserList(orderlist);
		
		orderesponse.setStatus_code(200);
		orderesponse.setMessage("Success");
		orderesponse.setOrder(order);
	}
	
	@Test
	public void cancelOrderTest()
	{
		when(service.cancelOrder(order.getOrderId())).thenReturn(response);
		assertEquals(200, controller.cancelOrder(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void viewOrderByUsernameTest()
	{
		when(service.getCurrentUserName()).thenReturn(username);
		when(service.viewOrderByUsername(username)).thenReturn(olr);
		assertEquals(200, controller.viewOrderByUsername().getStatus_code());
	}
	
	@Test
	public void updateOrderTest()
	{
		when(service.updateOrder(order.getOrderId(), address)).thenReturn(orderesponse);
		when(hateoas.updateOrder(order.getOrderId(), orderesponse)).thenReturn(new Resource<OrderResponse>(orderesponse));
		assertEquals(200, controller.updateOrder(order.getOrderId(), address).getContent().getStatus_code());
	}
	
	@Test
	public void viewOrderByOrderIdTest()
	{
		when(service.viewOrderByOrderId(order.getOrderId())).thenReturn(orderesponse);
		when(hateoas.viewOrderByOrderId(orderesponse)).thenReturn(new Resource<OrderResponse>(orderesponse));
		assertEquals(200, controller.viewOrderByOrderId(order.getOrderId()).getContent().getStatus_code());
	}
	
	@Test
	public void placeOrderTest()	
	{
		when(service.getCurrentUserName()).thenReturn(username);
		when(service.placeOrder(username)).thenReturn(orderIdResponse);
		when(hateoas.placeOrder(orderIdResponse)).thenReturn(new Resource<OrderIdResponse>(orderIdResponse));
		assertEquals(200, controller.placeOrder().getContent().getStatus_code());
	}
}