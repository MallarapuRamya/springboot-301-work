package com.mindtree.order;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.dao.OrderDao;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.CartServiceProxy;
import com.mindtree.order.service.UserServiceProxy;
import com.mindtree.order.service.impl.OrderServiceImpl;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTests extends TestCase{

	@Mock
	OrderDao dao;
	
	@Mock
	UserServiceProxy userproxy;
	
	@Mock
	CartServiceProxy cartproxy;
	
	@InjectMocks
	@Spy
	private OrderServiceImpl service;
	
	UserAddress address=new UserAddress();
	OrderIdResponse orderIdResponse=new OrderIdResponse();
	Cart cart=new Cart();
	Map<Integer,Integer> items= new HashMap<Integer, Integer>();
	CartResponse cartresponse=new CartResponse();
	Order order=new Order();
	OrderListResponse olr=new OrderListResponse();
	Response response=new Response();
	List<Order> orderlist=new ArrayList<Order>();
	OrderResponse orderesponse=new OrderResponse();
	
	String username="user@user.use";
	
	@Before
	public void initialize()
	{
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Line1");
		address.setAddressId(10);
		
		orderIdResponse.setOrder(new Order());
		orderIdResponse.setStatus_code(200);
		orderIdResponse.setOrderId(101);
		orderIdResponse.setMessage("Message");
		
		cart.setActive(true);
		cart.setCartId(1);
		cart.setItems(items);
		cart.setTotalAmount(20000);
		cart.setUserName(username);
		
		items.put(101, 1);
		items.put(102, 5);
		items.put(104, 3);
		items.put(106, 2);
		
		cartresponse.setCart(cart);

		order.setAddress(address);
		order.setItems(cart.getItems());
		order.setOrderId(10);
		order.setUserName(username);
		order.setTotalAmount(cart.getTotalAmount());
		
		response.setStatus_code(200);
		response.setMessage("message");

		orderlist.add(order);
		olr.setStatus_code(200);
		olr.setMessage("Message");
		olr.setUserList(orderlist);
		
		orderesponse.setStatus_code(200);
		orderesponse.setMessage("Success");
		orderesponse.setOrder(order);
	}
	
	@Test
	public void placeOrderTest1()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest2()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(null);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest3()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenThrow(new SQLException());
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest4()
	{ cartresponse.getCart().setActive(false);
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest5()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(null);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest6()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void placeOrderTest7()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.insertAddress(address)).thenReturn(address);
			when(cartproxy.getActiveCartForOrder(username)).thenReturn(cartresponse);
			when(service.setOrderInfo(cart, address)).thenReturn(order);
			when(service.findUserByUsername(username)).thenThrow(new RuntimeException());
			when(dao.placeOrder(order)).thenReturn(order);
			when(cartproxy.deactivateCart(username)).thenReturn(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.placeOrder(username).getStatus_code());
	}
	
	@Test
	public void viewOrderByOrderIdTest1()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.viewOrderByOrderId(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void viewOrderByOrderIdTest2()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.viewOrderByOrderId(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void viewOrderByOrderIdTest3()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.ofNullable(null));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.viewOrderByOrderId(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void viewOrderByUsernameTest1()
	{
		try {
			when(dao.viewOrderByUsername(username)).thenReturn(orderlist);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.viewOrderByUsername(username).getStatus_code());
	}
	
	@Test
	public void viewOrderByUsernameTest2()
	{
		orderlist.remove(order);
		try {
			when(dao.viewOrderByUsername(username)).thenReturn(orderlist);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.viewOrderByUsername(username).getStatus_code());
	}
	
	@Test
	public void viewOrderByUsernameTest3()
	{
		orderlist.remove(order);
		try {
			when(dao.viewOrderByUsername(username)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.viewOrderByUsername(username).getStatus_code());
	}
	
	@Test
	public void updateOrderTest1()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.updateOrder(order.getOrderId(), address)).thenReturn(Optional.of(order));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, service.updateOrder(order.getOrderId(), address).getStatus_code());
	}
	
	@Test
	public void updateOrderTest2()
	{
		UserAddress newadd=address;
		newadd.setAddressId(4);
		try {
			when(service.findUserByUsername(username)).thenReturn(address);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.updateOrder(order.getOrderId(), newadd).getStatus_code());
	}
	
	@Test
	public void updateOrderTest3()
	{
		order.setOrderId(0);
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.updateOrder(order.getOrderId(), address)).thenReturn(Optional.of(order));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.updateOrder(order.getOrderId(), address).getStatus_code());
	}
	
	@Test
	public void updateOrderTest4()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.updateOrder(order.getOrderId(), address)).thenReturn(Optional.ofNullable(null));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.updateOrder(order.getOrderId(), address).getStatus_code());
	}
	
	@Test
	public void updateOrderTest5()
	{
		try {
			when(userproxy.getAddressDetails(username)).thenReturn(address);
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.updateOrder(order.getOrderId(), address)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(204, service.updateOrder(order.getOrderId(), address).getStatus_code());
	}
	
	@Test
	public void cancelOrderTest1()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.cancelOrder(order.getOrderId())).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(200, service.cancelOrder(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void cancelOrderTest2()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenReturn(Optional.of(order));
			when(dao.cancelOrder(order.getOrderId())).thenReturn(false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.cancelOrder(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void cancelOrderTest3()
	{
		try {
			when(dao.viewOrderByOrderId(order.getOrderId())).thenThrow(new RuntimeException());
			when(dao.cancelOrder(order.getOrderId())).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(204, service.cancelOrder(order.getOrderId()).getStatus_code());
	}
	
	@Test
	public void getAddressDetailsTest()
	{
		when(userproxy.getAddressDetails(username)).thenReturn(address);
		assertNotNull(service.getAddressDetails(username));
	}
}
