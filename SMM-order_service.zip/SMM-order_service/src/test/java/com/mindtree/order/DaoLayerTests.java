package com.mindtree.order;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.dao.impl.OrderDaoImpl;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.utility.AddressRepository;
import com.mindtree.order.utility.CustomRepository;
import com.mindtree.order.utility.OrderRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DaoLayerTests {
	

	@Mock
	AddressRepository addrepo;
	
	@Mock
	CustomRepository customrepo;
	
	@Mock
	OrderRepository orderrepo;
	
	@InjectMocks
	@Spy
	OrderDaoImpl daoimpl;
	
	UserAddress address=new UserAddress();
	OrderIdResponse orderIdResponse=new OrderIdResponse();
	Cart cart=new Cart();
	Map<Integer,Integer> items= new HashMap<Integer, Integer>();
	CartResponse cartresponse=new CartResponse();
	Order order=new Order();
	OrderListResponse olr=new OrderListResponse();
	Response response=new Response();
	List<Order> orderlist=new ArrayList<Order>();
	OrderResponse orderesponse=new OrderResponse();
	
	String username="user@user.use";
	
	@Before
	public void initialize()
	{
		address.setPincode(123456);
		address.setState("State");
		address.setCity("City");
		address.setArea("Area");
		address.setAddressline1("Line1");
		address.setAddressId(10);
		
		orderIdResponse.setOrder(new Order());
		orderIdResponse.setStatus_code(200);
		orderIdResponse.setOrderId(101);
		orderIdResponse.setMessage("Message");
		
		cart.setActive(true);
		cart.setCartId(1);
		cart.setItems(items);
		cart.setTotalAmount(20000);
		cart.setUserName(username);
		
		items.put(101, 1);
		items.put(102, 5);
		items.put(104, 3);
		items.put(106, 2);
		
		cartresponse.setCart(cart);

		order.setAddress(address);
		order.setItems(cart.getItems());
		order.setOrderId(10);
		order.setUserName(username);
		order.setTotalAmount(cart.getTotalAmount());
		
		response.setStatus_code(200);
		response.setMessage("message");

		orderlist.add(order);
		olr.setStatus_code(200);
		olr.setMessage("Message");
		olr.setUserList(orderlist);
		
		orderesponse.setStatus_code(200);
		orderesponse.setMessage("Success");
		orderesponse.setOrder(order);
	}
	
	@Test
	public void placeOrderTest()
	{
		when(orderrepo.save(order)).thenReturn(order);
		try {
			assertNotNull(daoimpl.placeOrder(order));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void viewOrderByOrderIdTest()
	{
		when(orderrepo.findById(order.getOrderId())).thenReturn(Optional.of(order));
		try {
			assertNotNull(daoimpl.viewOrderByOrderId(order.getOrderId()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void viewOrderByUsernameTest()
	{
		when(customrepo.findByUserName(username)).thenReturn(orderlist);
		try {
			assertNotNull(daoimpl.viewOrderByUsername(username));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void updateOrderTest()
	{
		when(orderrepo.findById(order.getOrderId())).thenReturn(Optional.of(order));
		when(orderrepo.save(order)).thenReturn(order);
		try {
			assertNotNull(daoimpl.updateOrder(order.getOrderId(), address));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void cancelOrderTest()
	{
		when(orderrepo.findById(order.getOrderId())).thenReturn(Optional.of(order));
		try {
			assertTrue(daoimpl.cancelOrder(order.getOrderId()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void insertAddressTest()
	{
		when(addrepo.save(address)).thenReturn(address);
		try {
			assertNotNull(daoimpl.insertAddress(address));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
	
