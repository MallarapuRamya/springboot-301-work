package com.mindtree.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.OrderServiceHateoas;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/order")
@Api(value = "Everything about Order Info", description = "Services provided by order", tags = { "Order service" })
public class OrderController {

	@Autowired
	OrderService orderService;

	@Autowired
	OrderServiceHateoas orderServiceHateoas;

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "User can place a new order", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform several operations on the profile.") }) }, 
			produces = "application/json", notes = "Customer is allowed to place a new order")
	
	@RequestMapping(value = "/", method = RequestMethod.POST)	
	public Resource<OrderIdResponse> placeOrder() {
		return orderServiceHateoas.placeOrder(orderService.placeOrder(orderService.getCurrentUserName()));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "User can fetch details of order based on orderID", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform several operations on the profile.") }) }, 
			produces = "application/json", notes = "Customer is allowed to view an individual order")
	@RequestMapping(value = "/{orderId}", method = RequestMethod.GET)
	
	public Resource<OrderResponse> viewOrderByOrderId(@PathVariable int orderId) {
		return orderServiceHateoas.viewOrderByOrderId(orderService.viewOrderByOrderId(orderId));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class)})
	@ApiOperation(value = "User can fetch details of order based on userName", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Customer", value = "Customer is allowed to perform several operations on the profile.") }) }, 
			produces = "application/json", notes = "Customer is allowed to view all his placed orders")
	@RequestMapping(value = "/", method = RequestMethod.GET)
	
	public OrderListResponse viewOrderByUsername() {
		return orderService.viewOrderByUsername(orderService.getCurrentUserName());
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "User can edit details of placed order", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Internal Use", value = "Customer is allowed to perform several operations on the profile.") }) }, 
			produces = "application/json", notes = "Customer is allowed to modify the address details of the placed order")
	@RequestMapping(value = "/{orderId}", method = RequestMethod.PUT)
	
	public Resource<OrderResponse> updateOrder(@PathVariable int orderId, @RequestBody UserAddress address) {
		return orderServiceHateoas.updateOrder(orderId, orderService.updateOrder(orderId, address));
	}

	
	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = Response.class),
			@ApiResponse(code = 204, message = "Error", response = Response.class) })
	@ApiOperation(value = "User can delete the order", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "Internal Use", value = "Customer is allowed to perform several operations on the profile.") }) }, 
			produces = "application/json", notes = "Customer is allowed to cancel the placed order")
	@RequestMapping(value = "/{orderId}", method = RequestMethod.DELETE)
	
	public Response cancelOrder(@PathVariable int orderId) {
		return orderService.cancelOrder(orderId);
	}

}