package com.mindtree.order.response.entity;

import java.util.List;

import com.mindtree.order.entity.Order;

public class OrderListResponse extends Response {

	private List<Order> orderList;

	public OrderListResponse() {

	}

	public OrderListResponse(int status_code, String message, List<Order> orderList) {
		super(status_code, message);
		this.orderList = orderList;
	}

	public List<Order> getUserList() {
		return orderList;
	}

	public void setUserList(List<Order> userList) {
		this.orderList = userList;
	}

}