package com.mindtree.order.response.entity;

import com.mindtree.order.entity.Order;

public class OrderResponse extends Response {

	private Order order;

	public OrderResponse() {

	}

	public OrderResponse(int status_code, String message, Order order) {
		super(status_code, message);
		this.order = order;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order2) {
		this.order = order2;
	}

}