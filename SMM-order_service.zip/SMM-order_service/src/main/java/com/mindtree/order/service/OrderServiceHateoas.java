package com.mindtree.order.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderResponse;

@Service
public interface OrderServiceHateoas {

	Resource<OrderIdResponse> placeOrder(OrderIdResponse orderIdResponse);

	Resource<OrderResponse> viewOrderByOrderId(OrderResponse orderResponse);

	Resource<OrderResponse> updateOrder(int orderId, OrderResponse response);

}