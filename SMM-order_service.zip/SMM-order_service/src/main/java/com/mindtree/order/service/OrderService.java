package com.mindtree.order.service;

import org.springframework.stereotype.Service;

import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;

@Service
public interface OrderService {

	public OrderIdResponse placeOrder(String userName);

	public OrderResponse viewOrderByOrderId(int orderId);

	public OrderListResponse viewOrderByUsername(String userName);

	public OrderResponse updateOrder(int orderId, UserAddress userAddress);

	public Response cancelOrder(int orderId);

	public UserAddress getAddressDetails(String username);
	
	public String getCurrentUserName();

}