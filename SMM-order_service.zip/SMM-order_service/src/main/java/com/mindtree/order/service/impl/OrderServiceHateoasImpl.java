package com.mindtree.order.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.OrderServiceHateoas;

@Service
public class OrderServiceHateoasImpl implements OrderServiceHateoas {

	@Value("${baseurl}")
	String baseurl;
	
	@Override
	public Resource<OrderIdResponse> placeOrder(OrderIdResponse orderIdResponse) {

		Resource<OrderIdResponse> resource = new Resource<OrderIdResponse>(orderIdResponse);

		if (orderIdResponse.getStatus_code() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl+ "/orders/order/");
		resource.add(link1);

		Link link2 = new Link(baseurl+"/orders/order/"+orderIdResponse.getOrderId());
		resource.add(link2);

		return resource;
	}

	
	
	@Override
	public Resource<OrderResponse> viewOrderByOrderId(OrderResponse orderResponse) {

		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderResponse);

		if (orderResponse.getStatus_code() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl+ "/orders/order/");
		resource.add(link1);

		Link link2 = new Link(baseurl+"/orders/order/"+orderResponse.getOrder().getOrderId());
		resource.add(link2);

		return resource;
	}

	
	
	@Override
	public Resource<OrderResponse> updateOrder(int orderId, OrderResponse orderResponse) {

		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderResponse);

		if (orderResponse.getStatus_code() == 204) {
			return resource;
		}

		Link link1 = new Link(baseurl+ "/orders/order/");
		resource.add(link1);

		Link link2 = new Link(baseurl+"/orders/order/"+orderResponse.getOrder().getOrderId());
		resource.add(link2);

		return resource;
	}

}