package com.mindtree.order.response.entity;

import java.util.List;

import com.mindtree.order.entity.Product;

public class ProductListResponse extends Response {

	private List<Product> productList;

	public ProductListResponse() {
	}

	public ProductListResponse(int status_code, String message, List<Product> productList) {
		super(status_code, message);
		this.productList = productList;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

}
