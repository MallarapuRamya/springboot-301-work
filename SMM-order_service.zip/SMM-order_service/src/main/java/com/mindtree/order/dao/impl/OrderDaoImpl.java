package com.mindtree.order.dao.impl;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.order.dao.OrderDao;
import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.utility.AddressRepository;
import com.mindtree.order.utility.CustomRepository;
import com.mindtree.order.utility.OrderRepository;

@Service
public class OrderDaoImpl implements OrderDao {

	Logger LOG = Logger.getLogger(OrderDaoImpl.class);
	@Autowired
	OrderRepository orderRepository;

	@Autowired
	AddressRepository userRepository;

	@Autowired
	CustomRepository customRepository;

	
	
	@Override
	public Order placeOrder(Order order) throws Exception{
		Order placed = orderRepository.save(order);
		return placed;
	}

	
	
	@Override
	public Optional<Order> viewOrderByOrderId(int orderId) throws Exception {
		return orderRepository.findById(orderId);
	}

	
	
	@Override
	public List<Order> viewOrderByUsername(String userName) throws Exception {
		return customRepository.findByUserName(userName);
	}

	
	
	@Override
	public Optional<Order> updateOrder(int orderId, UserAddress address) throws Exception {

		Optional<Order> order = orderRepository.findById(orderId);

		order.get().getAddress().setAddressline1(address.getAddressline1());
		order.get().getAddress().setArea(address.getArea());
		order.get().getAddress().setCity(address.getCity());
		order.get().getAddress().setPincode(address.getPincode());
		order.get().getAddress().setState(address.getState());

		orderRepository.save(order.get());
		return order;
	}

	
	
	@Override
	public boolean cancelOrder(int orderId) throws Exception {

		boolean status = false;
		Optional<Order> order = orderRepository.findById(orderId);

		Order getOrder = order.get();
		orderRepository.delete(getOrder);
		status = true;
		return status;
	}

	
	
	@Override
	public UserAddress insertAddress(UserAddress address) throws Exception{
		return userRepository.save(address);

	}

}