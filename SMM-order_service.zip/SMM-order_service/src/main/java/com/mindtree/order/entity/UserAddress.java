package com.mindtree.order.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "smm_address")
@ApiModel(description = "Postal address information of the user registered to the application.")
public class UserAddress {

	@Id
	@Column(updatable = false)
	@ApiModelProperty(notes = "Primary attribute for user address identification.")
	private int addressId;

	@Column(nullable = false)
	@ApiModelProperty(notes = "Pincode for postal address.")
	private long pincode;

	@ApiModelProperty(notes = "Attribute for address reference.")
	private String addressline1;

	@Column(nullable = false)
	@ApiModelProperty(notes = "Area for postal address.")
	private String area;

	@Column(nullable = false)
	@ApiModelProperty(notes = "City for user postal address.")
	private String city;

	@Column(nullable = false)
	@ApiModelProperty(notes = "State for user postal address.")
	private String state;

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getAddressline1() {
		return addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "UserAddress [addressId=" + addressId + ", pincode=" + pincode + ", addressline1=" + addressline1
				+ ", area=" + area + ", city=" + city + ", state=" + state + "]";
	}

	public UserAddress() {
	}

}
