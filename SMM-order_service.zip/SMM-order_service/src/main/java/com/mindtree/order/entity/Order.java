package com.mindtree.order.entity;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.UpdateTimestamp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "smm_order")
@ApiModel(description = "Information of the order placed by the user registered to the application.")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ORDERID")
	@ApiModelProperty(notes = "Primary attritube for order identification")
	private int orderId;

	@ElementCollection
	@MapKeyColumn(name = "productId")
	@ApiModelProperty(notes = "Product ID and quantity pair.")
	private Map<Integer, Integer> items = new HashMap<Integer, Integer>();

	@Column(name = "USERNAME")
	@ApiModelProperty(notes = "Primary attribute for user identification.")
	private String userName;

	@Column(name = "ORDERDATEANDTIME")
	@UpdateTimestamp
	@ApiModelProperty(notes = "Date and time of order placed")
	private LocalDateTime orderDateAndTime;

	@Column(name = "TOTALAMOUNT")
	@ApiModelProperty(notes = "Total amount of the order placed")
	private double totalAmount;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "addressId", referencedColumnName = "addressId")
	@ApiModelProperty(notes = "Address of the customer")
	private UserAddress address;

	public int getOrderId() {
		return orderId;
	}

	public Map<Integer, Integer> getItems() {
		return items;
	}

	public String getUserName() {
		return userName;
	}

	public LocalDateTime getOrderDateAndTime() {
		return orderDateAndTime;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public UserAddress getAddress() {
		return address;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public void setItems(Map<Integer, Integer> items) {
		this.items = items;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setOrderDateAndTime(LocalDateTime orderDateAndTime) {
		this.orderDateAndTime = orderDateAndTime;
	}

	public void setTotalAmount(double d) {
		this.totalAmount = d;
	}

	public void setAddress(UserAddress address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", items=" + items + ", userName=" + userName + ", orderDateAndTime="
				+ orderDateAndTime + ", totalAmount=" + totalAmount + ", address=" + address + "]";
	}

}