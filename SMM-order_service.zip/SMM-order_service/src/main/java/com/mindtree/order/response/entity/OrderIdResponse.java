package com.mindtree.order.response.entity;

import com.mindtree.order.entity.Order;

public class OrderIdResponse extends Response {

	private int orderId;
	private Order order;

	public OrderIdResponse() {

	}

	public OrderIdResponse(int status_code, String message, int orderId) {
		super(status_code, message);
		this.orderId = orderId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public OrderIdResponse(int orderId, Order order) {
		super();
		this.orderId = orderId;
		this.order = order;
	}

}