package com.mindtree.order.entity;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Information of the products in cart of the user registered to the application.")
public class Cart {

	@Id
	@ApiModelProperty(notes = "Primary attribute for cart identification.")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;

	@JoinColumn
	@ElementCollection
	@MapKeyColumn(name = "productId")
	@ApiModelProperty(notes = "Product ID and quantity pair.")
	private Map<Integer, Integer> items = new HashMap<Integer, Integer>();

	@ApiModelProperty(notes = "Total amount the products.")
	private double totalAmount;

	@ApiModelProperty(notes = "Primary attribute for user identification.")
	private String userName;

	@ApiModelProperty(notes = "Cart activation status.")
	private boolean isActive;

	public Cart() {
		super();
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public Map<Integer, Integer> getItems() {
		return items;
	}

	public void setItems(Map<Integer, Integer> items) {
		this.items = items;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", items=" + items + ", totalAmount=" + totalAmount + ", userName=" + userName
				+ ", isActive=" + isActive + "]";
	}

}
