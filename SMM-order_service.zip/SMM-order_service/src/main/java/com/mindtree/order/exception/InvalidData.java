package com.mindtree.order.exception;

@SuppressWarnings("serial")
public class InvalidData extends Exception {
	public InvalidData(String string)
	{
		super(string);
	}

}
