package com.mindtree.order.utility;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.order.entity.UserAddress;

public interface AddressRepository extends JpaRepository<UserAddress, Integer> {

}
