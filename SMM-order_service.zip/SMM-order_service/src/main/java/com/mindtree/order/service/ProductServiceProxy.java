package com.mindtree.order.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mindtree.order.response.entity.ProductListResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@FeignClient("SMM-searchService")
@Service
@RequestMapping(value = "/products")
@Api(value = "Feign client of product service", description = "Used to get product details from product service", tags = {
"Communication between product and order service" })
public interface ProductServiceProxy {

	@ApiOperation(value="Fetch user specific details", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Internal Use", value = "Functionality Used for Microservices Communication.")})},
	produces = "application/json", notes = "This functionality is used for microservices communication for getting user specific details. It will not be giving user friendly response.")
	
	@RequestMapping(value = "/productsByIds", method = RequestMethod.POST, consumes = "application/json")
	public ProductListResponse getByProductIds(@RequestBody List<Integer> productIds);

}