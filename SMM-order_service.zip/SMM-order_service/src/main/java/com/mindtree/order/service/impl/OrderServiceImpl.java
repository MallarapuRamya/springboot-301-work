package com.mindtree.order.service.impl;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mindtree.order.dao.OrderDao;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;
import com.mindtree.order.exception.DataNotFound;
import com.mindtree.order.exception.InvalidData;
import com.mindtree.order.exception.TransactionError;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderIdResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.CartServiceProxy;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.UserServiceProxy;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderDao orderDao;

	@Autowired
	private UserServiceProxy userProxy;

	@Autowired
	private CartServiceProxy cartProxy;

	private final Logger LOG = Logger.getLogger(OrderServiceImpl.class);

	@Override
	public OrderIdResponse placeOrder(String userName) {

		OrderIdResponse orderIdResponse = new OrderIdResponse();

		try {
			
			UserAddress address = findUserByUsername(userName);
			try{
				if(address!=null){
					address = orderDao.insertAddress(address);
				}
				else{
					throw new DataNotFound("Could not fetch address details.");
				}
			}
			catch(DataNotFound e){
				LOG.error(e.getMessage());
				e.printStackTrace();
				orderIdResponse.setMessage("Could not fetch details for "+userName);
				orderIdResponse.setOrder(null);
				orderIdResponse.setOrderId(0);
				orderIdResponse.setStatus_code(204);
				return orderIdResponse;
			}
			catch(Exception e)
			{
				LOG.error(e.getMessage());
				e.printStackTrace();
				orderIdResponse.setStatus_code(204);
				orderIdResponse.setMessage("Something went wrong, Please try later.");
				orderIdResponse.setOrder(null);
				orderIdResponse.setOrderId(0);
				return orderIdResponse;
			}
			
			
			Cart cart = findCartByUserName(userName);
			LOG.info("==================>"+cart.toString());
			if (cart == null || cart.isActive()==false) {
				LOG.error("No Cart for user" + userName);
				orderIdResponse.setStatus_code(204);
				orderIdResponse.setMessage("No items found in the cart, Please add items to cart.");
				orderIdResponse.setOrderId(0);
				orderIdResponse.setOrder(null);
				return orderIdResponse;
			}
			else if (cart.isActive() == true) {
				Order order = setOrderInfo(cart, address);
				order.setUserName(userName);
				Order placed = orderDao.placeOrder(order);
				try {
					if (placed!=null && placed.getOrderId()!=0) {
						orderIdResponse.setOrderId(placed.getOrderId());
						orderIdResponse.setStatus_code(200);
						orderIdResponse.setMessage("Order is successfully placed!!");
						orderIdResponse.setOrder(placed);
						try{
							cartProxy.deactivateCart(cart.getUserName());
						}
						catch(Exception e)
						{
							LOG.error(e.getMessage());
							cancelOrder(placed.getOrderId());
							orderIdResponse.setStatus_code(204);
							orderIdResponse.setMessage("Order can not be placed. Please try again later.");
							orderIdResponse.setOrderId(0);
							orderIdResponse.setOrder(null);
							return orderIdResponse;
						}
					} 
					else {
						throw new TransactionError("Order not placed for " + userName);
					}
				} 
				catch (TransactionError e) {
					LOG.error(e.getMessage());
					orderIdResponse.setStatus_code(204);
					orderIdResponse.setMessage("Order can not be placed. Please try again later.");
					orderIdResponse.setOrderId(0);
					orderIdResponse.setOrder(null);
				}
			}
		}
		catch (Exception e) {
			LOG.error("Something went wrong. Please try later.");
			e.printStackTrace();	
			return new OrderIdResponse(204, "Something went wrong, PLease try later.", 0);
		}
		return orderIdResponse;
	}

	
	public Order setOrderInfo(Cart cart, UserAddress address) throws Exception {

		Order order = new Order();
		order.setAddress(address);
		order.setItems(cart.getItems());
		order.setTotalAmount(cart.getTotalAmount());

		return order;
	}

	
	
	@Override
	public OrderResponse viewOrderByOrderId(int orderId) {

		OrderResponse orderResponse = new OrderResponse();
		
		try {
			Optional<Order> order = orderDao.viewOrderByOrderId(orderId);
			
			try {
				if (order.isPresent()) {
					orderResponse.setOrder(order.get());
					orderResponse.setStatus_code(200);
					orderResponse.setMessage("Order found successfully.");
				} 
				else {
					throw new DataNotFound("Invalid OrderId / No orders found.");
				}
			} 
			catch (DataNotFound e) {
				LOG.error(e.getMessage() + " " + orderId);
				orderResponse.setStatus_code(204);
				orderResponse.setMessage("No orders found for the given orderId "+orderId);
				orderResponse.setOrder(null);
			}
		} 
		catch (Exception e) {
			LOG.error("Something went wrong. Please refer logs.");
			e.printStackTrace();
			return new OrderResponse(204, "Could not connect, please try later.", null);
		}
		return orderResponse;
	}

	
	
	@Override
	public OrderListResponse viewOrderByUsername(String userName) {

		OrderListResponse orderListResponse = new OrderListResponse();
		List<Order> orderList;

		try {
			orderList = orderDao.viewOrderByUsername(userName);

			try {
				if (!CollectionUtils.isEmpty(orderList)) {
					orderListResponse.setUserList(orderList);
					orderListResponse.setStatus_code(200);
					orderListResponse.setMessage("Order information fetched successfully.");
				} 
				else {
					throw new DataNotFound("No orders found for " + userName);
				}
			} 
			catch (DataNotFound e) {
				LOG.error(e.getMessage());
				orderListResponse.setUserList(null);
				orderListResponse.setStatus_code(204);
				orderListResponse.setMessage("No orders found");
			}
		}
		catch (Exception e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderListResponse(204,"Something went wrong, Please try later.", null);
		}

		return orderListResponse;
	}

	
	
	@Override
	public OrderResponse updateOrder(int orderId, UserAddress userAddress) {

		Optional<Order> orderIdValid=null;
		OrderResponse orderResponse = new OrderResponse();
		Optional<Order> order=null;
		try{
			UserAddress dbaddress= findUserByUsername(viewOrderByOrderId(orderId).getOrder().getUserName());
			if(dbaddress.getAddressId()!=userAddress.getAddressId())
			{
				throw new InvalidData("Address field is restricted to be modified.");
			}
			
		}
		catch(InvalidData e)
		{
			e.printStackTrace();
			LOG.error(e.getMessage());
			return new OrderResponse(204, e.getMessage(), null);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOG.error(e.getMessage());
			return new OrderResponse(204, "Something went wrong, Please try later.", null);
		}
		try{
			if(orderId==0 || Integer.toString(orderId).isEmpty() 
				||	userAddress.getAddressline1()==null || userAddress.getAddressline1().isEmpty()
				||	userAddress.getCity()==null || userAddress.getCity().isEmpty()
				||	userAddress.getPincode()==0 || Long.toString(userAddress.getPincode()).isEmpty()
				||  userAddress.getState()==null || userAddress.getState().isEmpty()){
				
				throw new InvalidData("Mandatory fields left empty.");
			}
			else{
				try{
					orderIdValid=orderDao.viewOrderByOrderId(orderId);
					if(orderIdValid.isPresent()){
						order = orderDao.updateOrder(orderId, userAddress);
						try {
							if (order.isPresent()){
								orderResponse.setStatus_code(200);
								orderResponse.setMessage("Order updated successfully");
								orderResponse.setOrder(order.get());
							}
							else{
								throw new TransactionError("Could not update order with orderId " + orderId);
							}
						}
						catch (TransactionError e) {
							LOG.error(e.getMessage() + " " + orderId);
							return new OrderResponse(204, "Could not update order.", null);
						}
					}
					else{
						throw new InvalidData("Invalid orderId");
					}
				}
				catch(InvalidData e){
					LOG.error(e.getMessage());
					return new OrderResponse(204, "Invalid OrderId.", null);
				}
				catch(Exception e){
					LOG.error(e.getMessage());
					return new OrderResponse(204, "Something went wrong, Please try again later.",null);
				}
			}
		}
		catch(InvalidData e){
			LOG.error(e.getMessage()+"");
			return new OrderResponse(204,e.getMessage(), null);
		}
		return orderResponse;
	} 


	
	
	@Override
	public Response cancelOrder(int orderId) {

		Response response = new Response();
		Optional<Order> orderIdValid=null;
		
		try{
			orderIdValid=orderDao.viewOrderByOrderId(orderId);
			if(orderIdValid.isPresent()){
				boolean deactivated = orderDao.cancelOrder(orderId);
				if(deactivated==true){
					response.setStatus_code(200);
					response.setMessage("Order cancelled Successfully");
				}
				else{
					response.setStatus_code(204);
					response.setMessage("Can not cancel the order, Please try later.");
				}
			}
			else{
				throw new InvalidData("Invalid Order Id");
			}
		}
		catch(InvalidData e){
			LOG.error(e.getMessage());
			return new OrderResponse(204, "Invalid OrderId", null);
		}
		catch(Exception e){
			LOG.error(e.getMessage());
			return new OrderResponse(204, "Something went wrong, Please try later.",null);
		}
		
		return response;
	}

	
	
	@Override
	public UserAddress getAddressDetails(String username) {
		UserAddress userAddress = userProxy.getAddressDetails(username);
		return userAddress;
	}


	
	public UserAddress findUserByUsername(String userName) throws Exception {
		return userProxy.getAddressDetails(userName);
	}

	
	
	private Cart findCartByUserName(String userName) {
		LOG.info("===============>CALLING CART"+userName);
		CartResponse cart=cartProxy.getActiveCartForOrder(userName);
		LOG.info("===============>"+cart.toString());
		return cart.getCart();
	}


	@Override
	public String getCurrentUserName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		return currentPrincipalName;

	}

}