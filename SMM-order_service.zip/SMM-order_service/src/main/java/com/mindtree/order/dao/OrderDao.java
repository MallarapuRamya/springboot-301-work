package com.mindtree.order.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.order.entity.Order;
import com.mindtree.order.entity.UserAddress;

@Service
public interface OrderDao {

	public Order placeOrder(Order order) throws Exception;

	public Optional<Order> viewOrderByOrderId(int orderId) throws Exception;

	public List<Order> viewOrderByUsername(String userName) throws Exception;

	public Optional<Order> updateOrder(int orderId, UserAddress userAddress) throws Exception;

	public boolean cancelOrder(int orderId) throws Exception;

	public UserAddress insertAddress(UserAddress address) throws Exception;

}