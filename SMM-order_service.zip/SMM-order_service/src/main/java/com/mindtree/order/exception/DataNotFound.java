package com.mindtree.order.exception;

@SuppressWarnings("serial")
public class DataNotFound extends Exception {
	public DataNotFound(String string)
	{
		super(string);
	}

}
