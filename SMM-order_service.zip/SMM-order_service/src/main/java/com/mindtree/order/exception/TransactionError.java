package com.mindtree.order.exception;

@SuppressWarnings("serial")
public class TransactionError extends Exception {
	public TransactionError(String string)
	{
		super(string);
	}

}
