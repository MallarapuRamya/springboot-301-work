package com.mindtree;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.CartServiceApplication;
import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.entity.Product;
import com.mindtree.cart.entity.User;
import com.mindtree.cart.exception.NoActiveCartFoundException;
import com.mindtree.cart.exception.QuantityMisMatchException;
import com.mindtree.cart.response.entity.ProductListResponse;
import com.mindtree.cart.service.ProductServiceProxy;
import com.mindtree.cart.service.UserServiceProxy;
import com.mindtree.cart.service.impl.CartServiceImpl;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CartServiceApplication.class })
public class ServiceLayerTest extends TestCase {
	
	@Mock 
	UserServiceProxy proxy;
	
	@Mock
	ProductServiceProxy productProxy;
	
	@Mock
	CartDao cartDao;
	
	
	@Mock
	Authentication auth;
	
	@Mock
	PasswordEncoder encoder;
	
	@InjectMocks
	@Spy
	private CartServiceImpl cartServiceImpl;
	
	@Test
	public void createNewCartTest() {
		
		String userName = "vikas@gmail.com";
		Cart cart = new Cart();
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(201, 1);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.getStackTrace();
		}
	}	

	
	@Test
	public void getActiveCartTest1() {
		
		String userName = "vikas@gmail.com";
		Cart cart = new Cart();
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(201, 1);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertNotNull(cartServiceImpl.getActiveCart(userName));
	}
	
	@Test
	public void getActiveCartTest2() {
		
		String userName = "dishant@gmail.com";
		Cart cart = new Cart();
		cart.setUserName(userName);
		cart.setTotalAmount(70000);
		
		cart.setItems(null);
		cart.setActive(false);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertNotNull(cartServiceImpl.getActiveCart(userName));	}
	
	@Test
	public void getActiveCartTest3() {
		
		String userName = "moksh@gmail.com";
		
		try {
			when(cartDao.getActiveCart(userName)).thenThrow(new NoActiveCartFoundException(userName));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertNotNull(cartServiceImpl.getActiveCart(userName));
	}
	
	@Test
	public void getActiveCartTest4() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(200, cartServiceImpl.getActiveCart(userName).getStatus_code());
	}
	
	@Test
	public void getActiveCartTest5() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(false);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.getActiveCart(userName).getStatus_code());
	}
	
	@Test
	public void removeProductTest3() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(false);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void removeProductTest4() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void removeProductTest5() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, -1).getStatus_code());
	}
	
	@Test
	public void removeProductTest6() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(null);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void removeProductTest7() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenThrow(new RuntimeException());
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void getActiveCartTest6() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(false);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.getActiveCart(userName).getStatus_code());
	}
	
	@Test
	public void removeCartTest1() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.saveCart(cart)).thenReturn(cart);
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(cart.getUserName())).thenReturn(Optional.of(cart));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(200, cartServiceImpl.removeCart(userName).getStatus_code());
	}
	
	@Test
	public void removeCartTest2() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(false);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.saveCart(cart)).thenReturn(cart);
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(cart.getUserName())).thenReturn(Optional.of(cart));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeCart(userName).getStatus_code());
	}
	
	@Test
	public void removeCartTest3() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.saveCart(cart)).thenReturn(cart);
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(cart.getUserName())).thenReturn(Optional.ofNullable(null));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeCart(userName).getStatus_code());
	}
	
	@Test
	public void removeCartTest4() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.saveCart(cart)).thenReturn(null);
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(cart.getUserName())).thenReturn(Optional.of(cart));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeCart(userName).getStatus_code());
	}
	@Test
	public void removeCartTest5() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		cart.setActive(true);
		
		try {
			when(cartDao.createNewCart(cart)).thenReturn(cart);
			when(cartDao.saveCart(cart)).thenReturn(cart);
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(cart.getUserName())).thenThrow(new RuntimeException());
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeCart(userName).getStatus_code());
	}
	
	@Test
	public void removeProductTest1() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(200, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void removeProductTest2() {
		
		User user=new User();
		String userName = "nimish@chandra.com";
		user.setEnable(true);

		user.setUsername(userName);
		Cart cart = new Cart();
		cart.setCartId(31);
		cart.setUserName(userName);
		cart.setTotalAmount(40000);
		cart.setActive(true);
		
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		Product product1 = new Product();
		product1.setDescription("description");
		product1.setModelName("modelName");
		product1.setPrice(20000);
		product1.setProductId(101);
		product1.setSellerType("sellerType");
		product1.setType("type");
		
		List<Product> productList = new ArrayList<Product>();
		productList.add(product1);
		ProductListResponse productListResponse=new ProductListResponse();
		productListResponse.setProductList(productList);
		
		List<Integer> product = new ArrayList<Integer>();
		product.add(101);
		
		try {
			when(proxy.getByUsernameAdmin(userName)).thenReturn(Optional.of(user));
			when(cartDao.getActiveCart(userName)).thenReturn(Optional.ofNullable(null));
			when(productProxy.getByProductIds(product)).thenReturn(productListResponse);
			when(cartDao.saveCart(cart)).thenReturn(cart);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		
		assertEquals(204, cartServiceImpl.removeProduct("nimish@chandra.com", 101, 2).getStatus_code());
	}
	
	@Test
	public void setFiltersAndReturnNewCartTest1() {
		
		Cart cart = new Cart();
		
		try {
			when(cartServiceImpl.setFiltersAndReturnNewCart("nimish@chandra.com", 101, 2, 400000)).thenReturn(cart);
		} catch (QuantityMisMatchException exception) {
			exception.printStackTrace();
		}
		
		assertNotNull(cart);
	}
	
	@Test
	public void setFiltersAndReturnNewCartTest2() {
		
		Cart cart = new Cart();
		
		try {
			when(cartServiceImpl.setFiltersAndReturnNewCart("nimish@chandra.com", 101, 0, 400000)).thenReturn(cart);
		} catch (QuantityMisMatchException exception) {
			exception.printStackTrace();
		}
		
		assertNotNull(cart);
	}
	
	@Test
	public void calculateTotalAmountTest() {
		
		try {
			assertEquals(40000.0, cartServiceImpl.calculateTotalAmount(101, 2));
		} catch(Exception exception) {
			exception.getStackTrace();
		}
		
	}
	
	@Test
	public void productTest() {
		
		Product product = new Product();
		
		try {
			product.setDescription("description");
			product.setModelName("modelName");
			product.setPrice(40000);
			product.setProductId(3);
			product.setSellerType("sellerType");
			product.setType("type");
			
			new Product(1, "modelName", 40000, "type", "sellerType", "description");
		} catch(Exception exception) {
			exception.getStackTrace();
		}
	}

	@Test
	public void beforeAddToCartHookTest1()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setItems(items);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(cart);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNotNull(cartServiceImpl.beforeAddToCartHook(userName, 101, 3, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	@Test
	public void beforeAddToCartHookTest2()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setItems(items);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(cart);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNotNull(cartServiceImpl.beforeAddToCartHook(userName, 101, -1, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	@Test
	public void beforeAddToCartHookTest3()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setItems(items);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(cart);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.ofNullable(null));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNull(cartServiceImpl.beforeAddToCartHook(userName, 101, 3, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	@Test
	public void beforeAddToCartHookTest4()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(cart);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNull(cartServiceImpl.beforeAddToCartHook(userName, 101, -1, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	@Test
	public void beforeAddToCartHookTest5()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(cart);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNotNull(cartServiceImpl.beforeAddToCartHook(userName, 101, 3, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	@Test
	public void beforeAddToCartHookTest6()
	{	
			User user=new User();
			String userName = "nimish@chandra.com";
			user.setEnable(true);

			user.setUsername(userName);
			Cart cart = new Cart();
			cart.setCartId(31);
			cart.setUserName(userName);
			cart.setTotalAmount(40000);
			
			Map<Integer, Integer> items = new HashMap<Integer, Integer>();
			items.put(101, 2);
			cart.setItems(items);
			cart.setActive(true);
			
			try {
				when(cartDao.saveCart(cart)).thenReturn(null);
				when(cartDao.getActiveCart(userName)).thenReturn(Optional.of(cart));
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
			try {
				assertNotNull(cartServiceImpl.beforeAddToCartHook(userName, 101, 3, 20000.0));
			} catch (QuantityMisMatchException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
