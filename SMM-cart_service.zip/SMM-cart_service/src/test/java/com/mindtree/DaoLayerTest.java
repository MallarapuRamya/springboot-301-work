package com.mindtree;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.CartServiceApplication;
import com.mindtree.cart.dao.impl.CartDaoImpl;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.exception.DatabaseConnectionException;
import com.mindtree.cart.exception.ServiceNoActiveCartFoundException;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.utility.CartRepository;

import junit.framework.TestCase;;

@SuppressWarnings("unused")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CartServiceApplication.class })
public class DaoLayerTest extends TestCase {

	@Mock
	CartRepository cartRepo;
	
	@InjectMocks
	@Spy
	CartDaoImpl cartDaoImpl;
	
	@Test
	public void createNewCartTest1() {
	
		Cart cart = new Cart();
		
		cart.setUserName("test@mindtree.com");
		cart.setActive(true);
		cart.setTotalAmount(40000);

		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		when(cartRepo.save(cart)).thenReturn(cart);
		
		try {
			assertEquals(cart, cartDaoImpl.createNewCart(cart));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	
	@Test
	public void getActiveCartTest1() {
		
		Optional<Cart> cart = cartDaoImpl.getActiveCart("nimish@chandra.com");
		when(cartRepo.getActiveCart("nimish@chandra.com")).thenReturn(cart);
		
		try {
			assertNotNull(cart);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	@Test
	public void addToCartTest1() {
		
		Cart cart = new Cart();
		
		cart.setUserName("nimish@chandra.com");
		cart.setActive(true);
		cart.setTotalAmount(40000);

		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		when(cartRepo.save(cart)).thenReturn(cart);
		
		try {
			assertNotNull(cartDaoImpl.addToCart(cart));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void addToCartTest2() {
		
		Cart cart = null;
		
		when(cartRepo.save(cart)).thenReturn(cart);
		
		try {
			assertFalse(cartDaoImpl.addToCart(cart));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void getCartByIdTest() {
		
		int cartId = 31;
		Cart cart = new Cart();
		
		cart.setCartId(cartId);
		cart.setUserName("nimish@chandra.com");
		cart.setActive(true);
		cart.setTotalAmount(40000);

		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		when(cartRepo.findById(cartId)).thenReturn(Optional.of(cart));
		
		try {
			assertEquals(cart, cartDaoImpl.getCartById(cartId));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	
	@Test
	public void saveCartTest1() {
	
		Cart cart = new Cart();
		
		cart.setUserName("test@mindtree.com");
		cart.setActive(true);
		cart.setTotalAmount(40000);

		Map<Integer, Integer> items = new HashMap<Integer, Integer>();
		items.put(101, 2);
		cart.setItems(items);
		
		when(cartRepo.save(cart)).thenReturn(cart);
		
		try {
			assertEquals(cart, cartDaoImpl.saveCart(cart));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	
	@Test
	public void getTotalPriceTest() {
		
		double amount = 20000;
		
		when(cartRepo.getTotalPrice(101, "nimish@chandra.com")).thenReturn(amount);
		
		try {
			assertEquals(amount, cartDaoImpl.getTotalPrice(101, "nimish@chandra.com"));
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	

}
