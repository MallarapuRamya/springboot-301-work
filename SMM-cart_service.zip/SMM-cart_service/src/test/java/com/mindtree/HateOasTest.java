package com.mindtree;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.CartServiceApplication;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CartServiceApplication.class })
public class HateOasTest {

	@Autowired
	CartHateoasService hatOas;
	
	@Test
	public void getActiveCartTest()
	{
		CartResponse cartRes= new CartResponse();
		Cart cart = new Cart();
		cartRes.setCart(cart);
		cartRes.setStatus_code(200);
		Resource<CartResponse> resource = hatOas.getActiveCart(cartRes);
		assertEquals(200, resource.getContent().getStatus_code());
	}
	
	@Test
	public void getActiveCartTest1()
	{
		CartResponse cartRes= new CartResponse();
		Cart cart = new Cart();
		cartRes.setCart(cart);
		cartRes.setStatus_code(204);
		Resource<CartResponse> resource = hatOas.getActiveCart(cartRes);
		assertEquals(204, resource.getContent().getStatus_code());
	}
	
	@Test
	public void addToCartTest() {
		
		Response resource = new Response();
		resource.setStatus_code(200);
		Resource<Response> response = hatOas.addToCart(resource);
		assertEquals(200, response.getContent().getStatus_code());
	}
	
	@Test
	public void addToCartTest1() {
		
		Response resource = new Response();
		resource.setStatus_code(204);
		Resource<Response> response = hatOas.addToCart(resource);
		assertEquals(204, response.getContent().getStatus_code());
	}
	
	@Test
	public void removeCart() {
		
		Response resource = new Response();
		resource.setStatus_code(200);
		Resource<Response> response = hatOas.removeCart(resource);
		assertEquals(200, response.getContent().getStatus_code());
	}
	
	@Test
	public void removeCart1() {
		
		Response resource = new Response();
		resource.setStatus_code(204);
		Resource<Response> response = hatOas.removeCart(resource);
		assertEquals(204, response.getContent().getStatus_code());
	}
	
	@Test
	public void removeProduct() {
		
		Response resource = new Response();
		resource.setStatus_code(200);
		Resource<Response> response = hatOas.removeProduct(resource);
		assertEquals(200, response.getContent().getStatus_code());
	}
	
	@Test
	public void removeProduct1() {
		
		Response resource = new Response();
		resource.setStatus_code(204);
		Resource<Response> response = hatOas.removeProduct(resource);
		assertEquals(204, response.getContent().getStatus_code());
	}
}
