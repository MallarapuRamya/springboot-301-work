package com.mindtree;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SuppressWarnings("unused")
@RunWith(Suite.class)
@SuiteClasses({ DaoLayerTest.class, ServiceLayerTest.class, ControllerLayerTest.class,HateOasTest.class})
@SpringBootTest
public class SmmCartServiceApplicationTests {

}
