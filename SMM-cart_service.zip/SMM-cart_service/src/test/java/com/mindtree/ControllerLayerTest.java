package com.mindtree;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.CartServiceApplication;
import com.mindtree.cart.controller.CartController;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartService;
import com.mindtree.cart.service.impl.CartServiceHateoasImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CartServiceApplication.class })
public class ControllerLayerTest {
	
	@Mock
	CartService cartService;
	
	@Mock
	CartServiceHateoasImpl hateoas;
	
	@InjectMocks
	@Spy
	CartController cartController;
	
	@Value("${informationalSuccessCode}")
	private int informationalSuccessCode;

	@Value("${dataNotFoundCode}")
	private int dataNotFoundCode;

	@Value("${successResponseCode}")
	private int successResponseCode;

	@Value("${requestTypeErrorCode}")
	private int requestTypeErrorCode;
	
	@Value("${transactionNotPerformed}")
	private int transactionNotPerformed;
	
	@Test
	public void removeCartTest() {
		
		Response response = new Response();
		response.setStatus_code(dataNotFoundCode);
		response.setMessage("No active cart present for the user.");
		when(cartService.removeCart("user@mee.com")).thenReturn(response);
		when(hateoas.removeCart(cartService.removeCart("user@mindtree.com"))).thenReturn(new Resource<Response>(response));
		assertEquals(dataNotFoundCode, cartController.removeCart().getContent().getStatus_code());
	}

	@Test
	public void getActiveCartTest(){
		CartResponse cartresp = new CartResponse();
		cartresp.setStatus_code(successResponseCode);
		cartresp.setMessage("message");
		cartresp.setCart(new Cart());
		when(cartService.getCurrentUserName()).thenReturn("r@n.com");
		when(cartService.getActiveCart("r@n.com")).thenReturn(cartresp);
		when(hateoas.getActiveCart(cartService.getActiveCart("r@n.com"))).thenReturn(new Resource<CartResponse>(cartresp));
		assertEquals(successResponseCode, cartController.getActiveCart().getContent().getStatus_code());
	}
	
	@Test
	public void addToCartTest() {
		
		Response response = new Response();
		response.setStatus_code(transactionNotPerformed);
		response.setMessage("message");
		when(cartService.getCurrentUserName()).thenReturn("user@m.com");
		when(cartService.addToCart("user@m.com", 101, 1)).thenReturn(response);
		when(hateoas.addToCart((cartService.addToCart("user@m.com", 101, 1)))).thenReturn(new Resource<Response>(response));
		assertEquals(transactionNotPerformed, cartController.addToCart(101, 1).getContent().getStatus_code());
	}
	
	@Test
	public void removeProductTest() {
		
		Response response = new Response();
		response.setStatus_code(dataNotFoundCode);
		response.setMessage("message");
		when(cartService.getCurrentUserName()).thenReturn("user@m.com");
		when(cartService.removeProduct("user@m.com", 101, 1)).thenReturn(response);
		when(hateoas.removeProduct((cartService.removeProduct("user@m.com", 101, 1)))).thenReturn(new Resource<Response>(response));
		assertEquals(dataNotFoundCode, cartController.removeProduct(101, 1).getContent().getStatus_code());
	}
}
