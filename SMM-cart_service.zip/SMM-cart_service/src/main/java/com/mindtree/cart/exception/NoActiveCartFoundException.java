package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class NoActiveCartFoundException extends CartServiceException {

	public NoActiveCartFoundException(String string) {
		super(string);
	}

}
