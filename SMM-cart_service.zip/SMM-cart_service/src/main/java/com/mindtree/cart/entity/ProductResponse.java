package com.mindtree.cart.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational response to be shown for the request.")
public class ProductResponse {
	
	@ApiModelProperty(notes="price of the product")
	private double price;

	public ProductResponse() {

	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
