package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class DatabaseConnectionException extends CartServiceException {

	public DatabaseConnectionException(String string) {
		super(string);
	}

}
