package com.mindtree.cart.service;

import java.util.Optional;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.cart.entity.User;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;


@FeignClient(name="SMM-userService")
@RibbonClient(name="SMM-userService")
@Service
@RequestMapping("/user")
@Api(value = "Feign client of user service", description = "Used to help get user details from user service", tags = {
"Communication between Cart and User service" })
public interface UserServiceProxy {
	
	@ApiOperation(value="Fetch user specific details", authorizations = {
            @Authorization(value = "oauth2", scopes = {}),
            @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "Internal Use", value = "Functionality Used for Microservices Communication.")})},
	produces = "application/json", notes = "This functionality is used for microservices communication for getting user specific details. It will not be giving user friendly response.")
	@RequestMapping(value = "/username/{username}", method = RequestMethod.GET)
	public Optional<User> getByUsernameAdmin(@PathVariable(value="username") String username);

}
