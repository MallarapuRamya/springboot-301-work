package com.mindtree.cart.service;

import org.springframework.stereotype.Service;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;



@Service
public interface CartService {

	public CartResponse getActiveCart(String userName);

	public Response addToCart(String userName, int productId, int quantity);

	public Response removeCart(String userName);

	public Response removeProduct(String userName, int productId, int quantity);
	
	public double calculateTotalAmount(int productId, int quantity) throws Exception;
	
	public double getPriceByProductId(int productId) throws Exception;
	
	public String getCurrentUserName();

}
