package com.mindtree.cart.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;

@Service
public interface CartHateoasService {

	Resource<CartResponse> getActiveCart(CartResponse activeCart);

	Resource<Response> addToCart(Response addToCart);

	Resource<Response> removeCart(Response removeCart);

	Resource<Response> removeProduct(Response removeProduct);
	
}
