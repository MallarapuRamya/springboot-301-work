package com.mindtree.cart.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;

@Service
public class CartServiceHateoasImpl implements CartHateoasService {

	@Value("${baseurl}")
	String endpoint;

	@Override
	public Resource<CartResponse> getActiveCart(CartResponse activeCart) {
		Resource<CartResponse> resource = new Resource<CartResponse>(activeCart);

		if (activeCart.getStatus_code() != 204) {
			Link link1 = new Link(endpoint + "carts/addProduct");
			resource.add(link1);

			Link link2 = new Link(endpoint + "carts/remove");
			resource.add(link2);

			Link link3 = new Link(endpoint + "carts/removeProduct");
			resource.add(link3);
			return resource;
		}
		else{
		

		return resource;
		}

	}

	@Override
	public Resource<Response> addToCart(Response addToCart) {
		Resource<Response> resource = new Resource<Response>(addToCart);

		if (addToCart.getStatus_code() != 204) {
			
			Link link1 = new Link(endpoint + "carts/addProduct");
			resource.add(link1);

			Link link2 = new Link(endpoint + "carts/remove");
			resource.add(link2);

			Link link3 = new Link(endpoint + "carts/removeProduct");
			resource.add(link3);

			Link link4 = new Link(endpoint + "carts/active");
			resource.add(link4);

			return resource;
		}
		else {
			return resource;

		}

		
	}

	@Override
	public Resource<Response> removeCart(Response removeCart) {
		Resource<Response> resource = new Resource<Response>(removeCart);

		if (removeCart.getStatus_code() != 204) {
			
			Link link1 = new Link(endpoint + "carts/addProduct");
			resource.add(link1);

			return resource;
		}
		else {
			return resource;

		}
		
	}

	@Override
	public Resource<Response> removeProduct(Response removeProduct) {
		Resource<Response> resource = new Resource<Response>(removeProduct);

		if (removeProduct.getStatus_code() != 204) {
			
			Link link1 = new Link(endpoint + "carts/addProduct");
			resource.add(link1);

			Link link2 = new Link(endpoint + "carts/remove");
			resource.add(link2);

			Link link3 = new Link(endpoint + "carts/removeProduct");
			resource.add(link3);

			Link link4 = new Link(endpoint + "carts/active");
			resource.add(link4);

			return resource;
		}
		else {
			return resource;

		}
		
	}

}
