package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class QuantityMisMatchException extends CartServiceException {

	public QuantityMisMatchException(String string) {
		super(string);
	}

}
