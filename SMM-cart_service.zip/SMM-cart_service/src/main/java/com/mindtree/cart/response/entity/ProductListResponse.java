package com.mindtree.cart.response.entity;

import java.util.List;

import com.mindtree.cart.entity.Product;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational(List) response to be shown for the request.")
public class ProductListResponse {
	
	@ApiModelProperty(notes="List of product Details.")
	private List<Product> productList;

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	
	public ProductListResponse() {
	}
}
