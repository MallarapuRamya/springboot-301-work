package com.mindtree.cart.dao;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.cart.entity.Cart;

@Service
public interface CartDao {

	public Optional<Cart> getActiveCart(String userName);

	public double getTotalPrice(int productId, String userName);

	public Cart getCartById(int cartId) throws Exception;
	
	public Cart saveCart(Cart cart) throws Exception;

	public Cart createNewCart(Cart cart) throws Exception;
	
	public boolean addToCart(Cart cart) throws Exception;


}