package com.mindtree.cart.entity;

import io.swagger.annotations.ApiModelProperty;

public class Product {
	
	@ApiModelProperty(notes="Id attribute for Product identification.")
	private Integer productId;
	
	@ApiModelProperty(notes="Model name of the product")
	private String modelName;
	
	@ApiModelProperty(notes="price of the product")
	private double price;
	
	@ApiModelProperty(notes="type of the product")
	private String type;
	
	@ApiModelProperty(notes="Seller type of the product")
	private String sellerType;
	
	@ApiModelProperty(notes="Description of the product")
	private String description;
	
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSellerType() {
		return sellerType;
	}
	public void setSellerType(String sellerType) {
		this.sellerType = sellerType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Product() {

	}

	public Product(int productId, String modelName, double price, String type, String sellerType, String description) {
		super();
		this.productId = productId;
		this.modelName = modelName;
		this.price = price;
		this.type = type;
		this.sellerType = sellerType;
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", modelName=" + modelName + ", price=" + price + ", type=" + type
				+ ", sellerType=" + sellerType + ", description=" + description + "]";
	}
}
