package com.mindtree.cart.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.entity.User;
import com.mindtree.cart.exception.DatabaseConnectionException;
import com.mindtree.cart.exception.NoActiveCartFoundException;
import com.mindtree.cart.exception.QuantityMisMatchException;
import com.mindtree.cart.exception.ServiceNoActiveCartFoundException;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.ProductListResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartService;
import com.mindtree.cart.service.ProductServiceProxy;
import com.mindtree.cart.service.UserServiceProxy;

@Service
public class CartServiceImpl implements CartService {

	private final Logger LOG = Logger.getLogger(CartServiceImpl.class);

	@Autowired
	private ProductServiceProxy productServiceProxy;
	
	@Autowired
	private UserServiceProxy userServiceProxy;
	
	@Autowired
	private CartDao cartDao;

	@Override
	public CartResponse getActiveCart(String userName) {
		
		CartResponse cartResponse = new CartResponse();
		
			
		try {
			
			if(!checkUserEnable(userName)){
				return new CartResponse(204,"User with username "+userName+" is deactivated.",null);
			}
			Optional<Cart> cart = cartDao.getActiveCart(userName);

			try {

				if (!cart.isPresent() || !cart.get().isActive()) {
					throw new NoActiveCartFoundException("No active cart found");
				} else {
					cartResponse.setStatus_code(200);
					cartResponse.setMessage("Cart Found");
					cartResponse.setCart(cart.get());
				}

			} catch (NoActiveCartFoundException noActiveCartFoundException) {
				LOG.error(noActiveCartFoundException.getMessage() + "for username: " + userName);
				return new CartResponse(204, "No active cart found", null);
			}

		} catch (Exception exception) {
			LOG.error(exception.getMessage() + " Database issue ");
			return new CartResponse(204, "Something went wrong, try again later", null);
		}

		return cartResponse;

	}

	public boolean checkUserEnable(String username) {
		try
		{
			Optional<User> user = userServiceProxy.getByUsernameAdmin(username);
			if(!user.get().isEnable())
				return false;
		}catch(Exception exception){
			exception.printStackTrace();
			LOG.error( "Something went wrong in fetching username");
			throw exception;
		}
		return true;
	}

	@Override
	public Response removeCart(String userName) {
		Response response = new Response();
		
		try {
			if(!checkUserEnable(userName)){
				return new CartResponse(204,"User with username "+userName+" does not exist or is deactivated.",null);
			}
			
			Optional<Cart> cart = cartDao.getActiveCart(userName);
			if (!cart.isPresent()) {
				response.setStatus_code(204);
				response.setMessage("No active cart present for the user.");
			} else {
				Cart deactivatedCart = cart.get();
				deactivatedCart.setActive(false);
				deactivatedCart = cartDao.saveCart(deactivatedCart);

				if (deactivatedCart != null) {
					response.setStatus_code(200);
					response.setMessage("Cart deactivated Successfully.");
				} else {
					response.setStatus_code(204);
					response.setMessage("Failed to deactivate the cart. Please try again.");
				}
			}
		}
		catch (Exception e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new CartResponse(204, "Something went wrong, try again later", null);
		}

		return response;
	}

	@Override
	public Response addToCart(String userName, int productId, int quantity) {
		Response response = new Response();

		
		try {
			if(!checkUserEnable(userName)){
				return new CartResponse(204,"User with username "+userName+" does not exist or is deactivated.",null);
			}
			double productAmount = calculateTotalAmount(productId, quantity);
			Cart cart = beforeAddToCartHook(userName, productId, quantity, productAmount);
			boolean status = cartDao.addToCart(cart);
			if(status ==true)
			{
				response.setStatus_code(200); 
				response.setMessage("Product added successfully to cart.");
			}
			else{
				response.setStatus_code(204);
				response.setMessage("Failed to add product to cart.");
			}
			
		}catch(QuantityMisMatchException exception){
			return new CartResponse(204,"Please provide valid product quantity.",null);
		}
		catch(NullPointerException e)
		{
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new Response(204,"Please provide valid product id.");
		}
		catch (Exception e) {
			LOG.error("Something went wrong . Please refer Logs.");
			e.printStackTrace();
			return new Response(204,"Something went wrong please try later.");
		}
		return response;
	}

	@Override
	public Response removeProduct(String userName, int productId, int quantity) {
		Response response = new Response();
		double amount=0;
		
		try {
			
			if(!checkUserEnable(userName)){
				return new CartResponse(204,"User with username "+userName+" does not exist or is deactivated.",null);
			}
			
			Optional<Cart> ocart = cartDao.getActiveCart(userName);

			if (!ocart.isPresent()) {
				throw new ServiceNoActiveCartFoundException("No active cart found for username :" + userName);
			} else {
				Cart cart = ocart.get();
				Map<Integer, Integer> dbItems = cart.getItems();

				if (!dbItems.containsKey(productId)) {
					String message = "Product with id: " + productId + " Doesnt exist in cart:" + cart.getCartId();
					LOG.error(message);
					throw new ServiceNoActiveCartFoundException(message);
				}

				if (dbItems.get(productId) >= 1) {
					
					if(quantity>0)
					dbItems.replace(productId, dbItems.get(productId) - quantity);
					else
						throw new QuantityMisMatchException("Please enter valid quantity");

					if (dbItems.get(productId) <= 0) {
						dbItems.remove(productId);
						response.setStatus_code(200);
						response.setMessage("The item count was reduced to 0 . Product has been removed from cart.");
					}
					else{
						response.setStatus_code(200);
						response.setMessage("Product has been removed from cart.");	
					}
					cart.setItems(dbItems);
					amount=cart.getTotalAmount() - calculateTotalAmount(productId, quantity);
					
					if(amount<0)
						amount=0;
					cart.setTotalAmount(amount);
					Cart removedCart = cartDao.saveCart(cart);

					if (removedCart == null) {
						throw new DatabaseConnectionException("Cannot connect to database. Try again later");
					}
					
				}
			}

		} catch (ServiceNoActiveCartFoundException | DatabaseConnectionException e) {
			e.printStackTrace();
			response.setStatus_code(204);
			response.setMessage(e.getMessage());
			
		} catch(QuantityMisMatchException exception){
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(204,"Please provide valid product quantity.",null);
		}
		catch (Exception e) {
			e.printStackTrace();
			response.setStatus_code(204);
			response.setMessage("Something went wrong , please try again later.");
		}
		return response;
	}

	public Cart beforeAddToCartHook(String userName, int productId, int quantity, double productAmount)
			throws Exception, QuantityMisMatchException {
		LOG.debug("Total Amount is :" + productAmount);
		Optional<Cart> cartResponse = cartDao.getActiveCart(userName);
		LOG.debug("Cart Response is: " + cartResponse);
		Cart responseCart = new Cart();

		if (!cartResponse.isPresent()) {
			Cart cart = setFiltersAndReturnNewCart(userName, productId, quantity, productAmount);
			responseCart = cartDao.createNewCart(cart);
		} else {
			Cart cart = cartResponse.get();
			LOG.debug("Cart items" + cart);

			Map<Integer, Integer> dbItems = cart.getItems();

			if (dbItems.containsKey(productId)) {
				
				if(quantity>0)
				dbItems.replace(productId, dbItems.get(productId) + quantity);
				else
					throw new QuantityMisMatchException("Please enter valid product quantity");
				
			} else {
				if(quantity>0)
				dbItems.put(productId, quantity);
				else
					throw new QuantityMisMatchException("Please enter valid product quantity");
			}

			cart.setItems(dbItems);
			LOG.debug("Number of items in cart :" + cart.getItems().size());
			cart.setTotalAmount(cart.getTotalAmount() + productAmount);
			responseCart = cartDao.saveCart(cart);

			if (responseCart == null) {
				throw new DatabaseConnectionException("Cannot connect to database. Try again later");
			}
		}

		return responseCart;
	}

	public Cart setFiltersAndReturnNewCart(String userName, int productId, int quantity, double totalAmount) throws QuantityMisMatchException {
		Cart cart = new Cart();
		Map<Integer, Integer> items = cart.getItems();
		if(quantity>0){
		items.put(productId, quantity);
		cart.setActive(true);
		cart.setUserName(userName);
		cart.setTotalAmount(totalAmount);
	}
		else{
			throw new QuantityMisMatchException("Please enter valid product quantity");
		}
		return cart;
	}

	@Override
	public double calculateTotalAmount(int productId, int quantity) throws Exception {
		double amount = 0;
		amount = getPriceByProductId(productId);
		return (amount * quantity);
	}

	@Override
	public double getPriceByProductId(int productId) throws Exception {
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(productId);
		ProductListResponse listResponse = productServiceProxy.getByProductIds(itemList);
		return listResponse.getProductList().get(0).getPrice();
	}

	@Override
	public String getCurrentUserName() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		return currentPrincipalName;
	}

}