package com.mindtree.cart.entity;

import javax.persistence.Column;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Profile information of the user registered to the application.")
public class User {

	@ApiModelProperty(notes="Primary attribute for user identification.")
	private String username;

	@ApiModelProperty(notes="Name of the user.")
	private String name;

	@ApiModelProperty(notes="Password for authentication purpose.")
	private String password;

	@ApiModelProperty(notes="User addres details.")
    private UserAddress address;

	@ApiModelProperty(notes="Contact number of the user.")
	private long mobile;

	@Column(name = "ACCOUNT_ENABLED")
	@ApiModelProperty(notes="Account activation status.")
	private boolean enable = true;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	public UserAddress getAddress() {
		return address;
	}

	public void setAddress(UserAddress address) {
		this.address = address;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", name=" + name + ", password=" + password + ", address=" + address
				+ ", mobile=" + mobile + ", enable=" + enable + "]";
	}

}
