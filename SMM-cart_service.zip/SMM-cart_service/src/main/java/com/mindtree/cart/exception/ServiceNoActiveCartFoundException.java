package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class ServiceNoActiveCartFoundException extends CartServiceException {

	public ServiceNoActiveCartFoundException(String string) {
		super(string);
	}

}
