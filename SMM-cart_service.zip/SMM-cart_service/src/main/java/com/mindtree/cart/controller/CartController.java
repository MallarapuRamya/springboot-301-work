package com.mindtree.cart.controller;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;
import com.mindtree.cart.service.CartService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/carts")
@Api(value = "Everything about User Cart", description = "Cart services provided to the user", tags = { "Cart" })
public class CartController {
	
	@Autowired
	private CartService cartService;

	@Autowired
	private CartHateoasService refLinks;
	
	Logger LOG=Logger.getLogger(CartController.class);
	
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Informational", response = Response.class),
			@ApiResponse(code = 707, message = "Transaction not performed on Database", response = Response.class),
			@ApiResponse(code = 704, message = "Data not found", response = Response.class) })
	@ApiOperation(value = "Getting cart info for current user.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the cart.") }) }, produces = "application/json", notes = "Customer is able get active cart info by specifying username")
	@RequestMapping(value = "/active", method = RequestMethod.GET)
	
	public Resource<CartResponse> getActiveCart() {
		return refLinks.getActiveCart(cartService.getActiveCart(cartService.getCurrentUserName()));
	}
	
	
	
	
	@ApiResponses(value = { @ApiResponse(code = 701, message = "Request type error", response = Response.class),
			@ApiResponse(code = 201, message = "Non informational Successfull Response", response = Response.class),
			@ApiResponse(code = 707, message = "Transaction not performed on Database", response = Response.class) })
	@ApiOperation(value = "Adding products to cart.", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the cart.") }) }, produces = "application/json", notes = "Customer is able to add products to cart by specifying username, product Id (Parameter) and quantity(Parameter).")
	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	
	public Resource<Response> addToCart(@RequestParam int productId,
			@RequestParam int quantity) {
		return refLinks.addToCart(cartService.addToCart(cartService.getCurrentUserName(), productId, quantity));
	}
	
	
	
	
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Non informational Successfull Response", response = Response.class),
			@ApiResponse(code = 707, message = "Transaction not performed on Database", response = Response.class),
			@ApiResponse(code = 704, message = "Data not found", response = Response.class) })
	@ApiOperation(value = "Remove cart for current user.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the profile.") }) }, produces = "application/json", notes = "Customer is able to remove active cart.")
	@RequestMapping(value = "/remove", method = RequestMethod.DELETE)
	
	public Resource<Response> removeCart() {
		return refLinks.removeCart(cartService.removeCart(cartService.getCurrentUserName()));
	}
	
	
	
	
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Non informational Successfull Response", response = Response.class),
			@ApiResponse(code = 707, message = "Transaction not performed on Database", response = Response.class),
			@ApiResponse(code = 704, message = "Data not found", response = Response.class) })
	@ApiOperation(value = "Remove product from cart for current user.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "Customer is allowed to perform several operations on the profile.") }) }, produces = "application/json", notes = "Customer is able to remove product from his active cart by providing Product Id (Parameter) and quantity (Parameter).")
	@RequestMapping(value = "/removeProduct", method = RequestMethod.DELETE)
	
	public Resource<Response> removeProduct(@RequestParam int productId,
			@RequestParam int quantity) {
		return refLinks.removeProduct(cartService.removeProduct(cartService.getCurrentUserName(), productId, quantity));
	}

	
	@ApiOperation(value = "Getting cart info for current user.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "This Functionality is used for microservices communication only. It will not give user friendly response.") }) }, produces = "application/json", notes = "This Functionality is used for microservices communication only. It will not give user friendly response.")
	
	@RequestMapping(value = "/active/{userName}", method = RequestMethod.GET)
	
	public CartResponse getActiveCartForOrder(@PathVariable String userName) {
		return cartService.getActiveCart(userName);
	}
	
	
	@ApiOperation(value = "Deactivating cart for the user after placing an order.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "This Functionality is used for microservices communication only. It will not give user friendly response.") }) }, produces = "application/json", notes = "This Functionality is used for microservices communication only. It will not give user friendly response.")
	
	@RequestMapping(value = "/deactivate/{userName}", method = RequestMethod.DELETE)
	public Response deactivateCart(@PathVariable String userName){
		return cartService.removeCart(userName);
	}
}
