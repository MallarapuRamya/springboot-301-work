package com.mindtree.cart.utility;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.mindtree.cart.entity.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, String> {

	@Query(nativeQuery = true, value = "select * from smm_cart where user_name=LOWER(:userName) and is_Active=true")
	public Optional<Cart> getActiveCart(@Param("userName") String userName);
	
	@Query(nativeQuery = true, value = "select * from smm_cart where cart_id=LOWER(:cartId) and is_Active=true")
	public Optional<Cart> findById(@Param("cartId") int cartId);

	@Query(nativeQuery = true, value = "select total_amount from smm_cart inner join cart_items on cart_items.cart_cart_id=smm_cart.cart_id and cart_items.product_id=LOWER(:productId) and user_name=(:userName)")
	public Double getTotalPrice(@Param("productId")int productId, @Param("userName")String userName);

}
