 package com.mindtree.cart.dao.impl;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.utility.CartRepository;


@Service
public class CartDaoImpl implements CartDao {
	
	
	@Autowired
	private CartRepository cartRepository;
	
	@Override 
	public Cart createNewCart(Cart cart) {
		return cartRepository.save(cart);
	}

	@Override
	public Optional<Cart> getActiveCart(String userName) {
		return cartRepository.getActiveCart(userName);
	}

	@Override
	public boolean addToCart(Cart cart) throws Exception {
		 if(cartRepository.save(cart)!=null){
			 return true;
		 }
		 return false;
	}

	@Override
	public Cart getCartById(int cartId) throws Exception {
		Cart cart = cartRepository.findById(cartId).get();
		return cart;
	}

	@Override
	public Cart saveCart(Cart cart){
		return cartRepository.save(cart);
	}
	
	@Override
	public double getTotalPrice(int productId, String userName) {
		return cartRepository.getTotalPrice(productId,userName);		 
	}
}
