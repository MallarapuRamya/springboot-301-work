package com.mindtree.cart;

import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.controller.CartController;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CartControllerTest extends TestCase {

	@Autowired
	private CartController cartController;

	@Test
	public void getActiveCartTestCase2() {
		Resource<CartResponse> cart = cartController.getActiveCart("s7@gmail.com");
		assertNull(cart.getContent().getCart());
		assertEquals(204, cart.getContent().getStatus_code());
	}

	@Test
	public void getActiveCartTestCase3() {
		Resource<CartResponse> cart = cartController.getActiveCart("gagana7@gmail.com");
		//assertNull(cart.getContent().getCart());
		assertEquals(204, cart.getContent().getStatus_code());
	}
	
	@Test
	public void addToCartTestCase2() {
		Resource<Response> response = cartController.addToCart("shailu@gmail.com", 2345, -1);
		assertEquals(204, response.getContent().getStatus_code());
	}

	@Test
	public void removeCartTestcase2() {
		Resource<Response> response = cartController.removeCart("shailu@gmail.com");
		assertEquals(204, response.getContent().getStatus_code());
	}
	
	@Test
	public void removeCartTestcase3() {
		Resource<Response> response = cartController.removeCart("you@gmail.com");
		assertEquals(204, response.getContent().getStatus_code());
	}

	@Test
	public void deactivateCartTestCase2() {
		Response response = cartController.deactivateCart("shailu@gmail.com");
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void deactivateCartTestCase3() {
		Response response = cartController.deactivateCart("you@gmail.com");
		assertEquals(204, response.getStatus_code());
	}
}
