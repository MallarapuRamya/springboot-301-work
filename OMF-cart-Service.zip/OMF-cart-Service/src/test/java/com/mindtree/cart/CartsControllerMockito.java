package com.mindtree.cart;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.controller.CartController;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;
import com.mindtree.cart.service.CartService;
import com.mindtree.cart.service.CartServiceProxy;
import com.mindtree.cart.service.UserServiceProxy;


@RunWith(SpringRunner.class)
@SpringBootTest
public class CartsControllerMockito {

	@Mock
	CartService cartService;
	
	
	@Mock
	CartServiceProxy cartServiceProxy;

	@Mock
	UserServiceProxy userProxy;
	
	@Mock
	CartHateoasService hateoas;

	@InjectMocks
	@Spy
	CartController cartController;
	
	String username="shailu@gmail.com";
	Response response=new Response();
	Resource<Response> resource=new Resource<Response>(response);
	
	@Test
	public void removeCartTest()
	{
		response.setStatus_code(200);
		response.setMessage("message");
		resource.getContent().setStatus_code(200);
		resource.getContent().setMessage("meassage");
		when(cartService.checkIfUserExist(username)).thenReturn(true);
		when(cartService.removeCart(username)).thenReturn(response);
		when(hateoas.removeCart(response, username)).thenReturn(resource);
		//assertNotNull(cartController.getActiveCart(username));
	}
	
	
	}
