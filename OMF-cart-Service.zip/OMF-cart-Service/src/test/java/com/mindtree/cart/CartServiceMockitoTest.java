package com.mindtree.cart;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.entity.Items;
import com.mindtree.cart.entity.Response;
import com.mindtree.cart.exception.DataBaseConnectionException;
import com.mindtree.cart.exception.NoActiveCartFoundException;
import com.mindtree.cart.exception.QuantityMisMatchException;
import com.mindtree.cart.repository.CartRepository;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.ItemListResponse;
import com.mindtree.cart.service.CartServiceProxy;
import com.mindtree.cart.service.UserServiceProxy;
import com.mindtree.cart.service.impl.CartServiceimplementation;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CartServiceMockitoTest {

	@Mock
	CartDao cartdao;

	@Mock
	CartServiceProxy cartServiceProxy;

	@Mock
	UserServiceProxy userProxy;

	@Mock
	CartRepository repo;

	@InjectMocks
	@Spy
	CartServiceimplementation cartimpl;
	
	@Test
	public void getActiveCartTest()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		assertNotNull(cartimpl.getActiveCart(userName));
	}
	
	@Test
	public void getActiveCartTest1()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenThrow(new RuntimeException());
		assertNotNull(cartimpl.getActiveCart(userName));
	}
	
	@Test
	public void getActiveCartTest2()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(false);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		when(userProxy.getUserById(userName)).thenThrow(new RuntimeException());
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		assertNotNull(cartimpl.getActiveCart(userName));
	}
	
	@Test
	public void removeCartTest()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertNotNull(cartimpl.removeCart(userName));
		
		
	}
	
	@Test
	public void removeCartTest1()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		when(userProxy.getUserById(userName)).thenThrow(new RuntimeException());
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertNotNull(cartimpl.removeCart(userName));
		
		
	}
	
	@Test
	public void addToCartTest()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartServiceProxy.getByItemId(itemList)).thenReturn(itemListResponse);
		when(cartdao.createNewCart(cart)).thenReturn(cart);
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
			when(cartdao.addToCart(cart)).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.addToCart(userName, 12, 2));
		
		
	}
	
	@Test
	public void addToCartTest1()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenThrow(new RuntimeException());
		when(cartServiceProxy.getByItemId(itemList)).thenReturn(itemListResponse);
		when(cartdao.createNewCart(cart)).thenReturn(cart);
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
			when(cartdao.addToCart(cart)).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.addToCart(userName, 12, 2));
		
		
	}
	
	@Test
	public void beforeCartHookTest()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartimpl.setFiltersAndReturnNewCart(userName, 100, 2, 100)).thenReturn(cart);
		when(cartdao.createNewCart(cart)).thenReturn(cart);
		try {
			assertNotNull(cartimpl.beforeCartHook(userName, 100, 2, 100));
		} catch (QuantityMisMatchException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void beforeCartHookTest1()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(false);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		Optional<Cart> cartOp=Optional.of(cart);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartimpl.setFiltersAndReturnNewCart(userName, 100, 2, 100)).thenReturn(cart);
		when(cartdao.createNewCart(cart)).thenReturn(cart);
		try {
			assertNotNull(cartimpl.beforeCartHook(userName, 100, 2, 100));
		} catch (QuantityMisMatchException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void removeProductTest()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		assertNotNull(cartimpl.removeProduct(userName, 12, 2));
	}

	@Test
	public void removeProductTest1()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenThrow(new RuntimeException());
		assertNotNull(cartimpl.removeProduct(userName, 12, 2));
	}
	
	@Test
	public void removeProductTest2()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(12, -1);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartServiceProxy.getByItemId(itemList)).thenThrow(new RuntimeException());
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.removeProduct(userName, 12, 2));
	}
	
	@Test
	public void removeProductTest3()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(100, -1);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartServiceProxy.getByItemId(itemList)).thenReturn(itemListResponse);
		try {
			when(cartdao.saveCart(cart)).thenThrow(new DataBaseConnectionException(""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.removeProduct(userName, 100, 2));
	}
	
	@Test
	public void removeProductTest4()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(100, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartServiceProxy.getByItemId(itemList)).thenReturn(itemListResponse);
		try {
			when(cartdao.saveCart(cart)).thenThrow(new DataBaseConnectionException(""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.removeProduct(userName, 100, 2));
	}

	@Test
	public void removeProductTest5()
	{
		String userName="sush7@gmail.com";
		Response response=new Response();
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();
		map.put(100, 2);
		response.setStatus("message");
		response.setStatusCode(200);
		Cart cart=new Cart();
		cart.setActive(true);
		cart.setCartId(100);
		cart.setItems(map);
		cart.setUserName(userName);
		
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(100);
		
		Items item=new Items();
		item.setItemId(100);
		item.setItemName(userName);
		item.setItemPrice(100);
		
		List<Items> list=new ArrayList<Items>();
		list.add(item);
		
		Optional<Cart> cartOp=Optional.of(cart);
		Resource<Response> resource=new Resource<Response>(response);
		ItemListResponse itemListResponse=new ItemListResponse();
		itemListResponse.setItemList(list);
		
		when(userProxy.getUserById(userName)).thenReturn(resource);
		when(cartdao.getActiveCart(userName)).thenReturn(cartOp);
		when(cartServiceProxy.getByItemId(itemList)).thenReturn(itemListResponse);
		try {
			when(cartdao.saveCart(cart)).thenReturn(cart);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(cartimpl.removeProduct(userName, 100, 2));
	}

	
}
