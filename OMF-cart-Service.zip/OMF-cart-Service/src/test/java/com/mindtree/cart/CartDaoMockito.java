package com.mindtree.cart;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.dao.impl.CartDaoImplementation;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.repository.CartRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CartDaoMockito {
	
	@Mock
	CartRepository repo;
	
	@InjectMocks
	@Spy
	CartDaoImplementation daoImpl;
	
	@Test
	public void getActiveCart()
	{
		String userName="user@gmai.com";
		Cart cart=new Cart();
		Optional<Cart> cartOp = Optional.of(cart);
		when(repo.getActiveCart(userName)).thenReturn(cartOp);
		assertNotNull(daoImpl.getActiveCart(userName));
	}
	
	
	@Test
	public void saveCartTestCase1() throws Exception {
		Cart cart = new Cart();
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();

		cart.setCartId(1);
		cart.setUserName("ashwinsavaj1997@gmail.com");
		items.put(201, 2);
		cart.setItems(items);
		cart.setTotalPrice(150);
		try {
			when(repo.save(cart)).thenReturn(cart);
			assertNotNull(daoImpl.saveCart(cart));
		} catch (Exception exception) {
			assertThat(exception.getMessage(), is(exception.getMessage()));
		}
	}
	
	@Test
	public void saveCartTestCase2() throws Exception {
		Cart cart = new Cart();
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();

		cart.setCartId(97);
		cart.setUserName("gagana@gmail.com");
		items.put(877, 1);
		cart.setItems(items);
		cart.setTotalPrice(900);
		try {
			when(repo.save(cart)).thenReturn(cart);
			assertNotNull(daoImpl.saveCart(cart));
		} catch (Exception exception) {
			assertThat(exception.getMessage(), is(exception.getMessage()));
		}
	}
	
	@Test
	public void createCartTestCase1() throws Exception {
		Cart cart = new Cart();
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();

		cart.setCartId(1);
		cart.setUserName("shailu@gmail.com");
		items.put(201, 2);
		cart.setItems(items);
		cart.setTotalPrice(150);
		try {
			when(repo.save(cart)).thenReturn(cart);
			assertNotNull(daoImpl.createNewCart(cart));
		} catch (Exception exception) {
			assertThat(exception.getMessage(), is(exception.getMessage()));
		}

	}
	
	@Test
	public void createCartTestCase2() throws Exception {
		Cart cart = new Cart();
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();

		cart.setCartId(97);
		cart.setUserName("gagana@gmail.com");
		items.put(877, 1);
		cart.setItems(items);
		cart.setTotalPrice(900);
		try {
			when(repo.save(cart)).thenReturn(cart);
			assertNotNull(daoImpl.createNewCart(cart));
		} catch (Exception exception) {
			assertThat(exception.getMessage(), is(exception.getMessage()));
		}
	}

	@Test
	public void addToCartTestCase1() throws Exception {
		Cart cart = new Cart();
		Map<Integer, Integer> items = new HashMap<Integer, Integer>();

		cart.setCartId(1);
		cart.setUserName("shailu@gmail.com");
		items.put(201, 2);
		cart.setItems(items);
		cart.setTotalPrice(120);
		try {
			when(repo.save(cart)).thenReturn(cart);
			assertTrue(daoImpl.addToCart(cart));
		} catch (Exception exception) {
			assertThat(exception.getMessage(), is(exception.getMessage()));
		}
	}
}
