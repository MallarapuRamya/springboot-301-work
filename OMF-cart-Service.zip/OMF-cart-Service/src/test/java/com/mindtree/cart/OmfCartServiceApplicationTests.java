package com.mindtree.cart;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.boot.test.context.SpringBootTest;


@RunWith(Suite.class)
@SuiteClasses({CartDaoTest.class,CartServiceTest.class,CartControllerTest.class,CartDaoMockito.class,CartServiceMockitoTest.class,CartsControllerMockito.class})
@SpringBootTest
public class OmfCartServiceApplicationTests {

}
