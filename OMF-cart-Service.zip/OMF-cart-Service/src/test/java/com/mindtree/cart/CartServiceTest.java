package com.mindtree.cart;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.impl.CartServiceimplementation;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CartServiceTest {

	@Autowired
	CartServiceimplementation cartServiceimplementation;

	@Test
	public void getActiveCartTestCase2() {
		CartResponse cartResponse = cartServiceimplementation.getActiveCart("shailu@gmail.com");
		assertEquals(204, cartResponse.getStatus_code());

	}

	@Test
	public void getActiveCartTestCase4() {
		CartResponse cartResponse = cartServiceimplementation.getActiveCart("you@gmail.com");
		assertEquals(204, cartResponse.getStatus_code());

	}

	@Test
	public void removeCartTestCase1() {
		Response response = cartServiceimplementation.removeCart("ashwinsavaj1997@gmail.com");
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void removeCartTestCase2() {
		Response response = cartServiceimplementation.removeCart("shailu@gmail.com");
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void removeCartTestCase3() {
		Response response = cartServiceimplementation.removeCart("shailu@gmail.com");
		assertEquals(204, response.getStatus_code());
	}
	

	@Test
	public void addToCartTestCase2() {

		Response response = cartServiceimplementation.addToCart("shailu@gmail.com", 654, 1);
		assertEquals(204, response.getStatus_code());
	}
	
	@Test
	public void addToCartTestCase3() {

		Response response = cartServiceimplementation.addToCart("man@gmail.com", 654, 1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void addToCartTestCase4() {

		Response response = cartServiceimplementation.addToCart("shailu@gmail.com", 201, -1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void addToCartTestCase5() {

		Response response = cartServiceimplementation.addToCart("shailu@gmail.com", 201, 1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void setFiltersAndReturnNewCartTestCase1() {
		Cart cart = cartServiceimplementation.setFiltersAndReturnNewCart("ashwinsavaj1997@gmail.com", 201, 1, 150);
		assertNotNull(cart);
	}

	@Test
	public void setFiltersAndReturnNewCartTestCase2() {
		Cart cart = cartServiceimplementation.setFiltersAndReturnNewCart("shailu7@gmail.com", 201, 1, 150);
		assertNotNull(cart);
	}

	@Test
	public void setFiltersAndReturnNewCartTestCase3() {
		Cart cart = cartServiceimplementation.setFiltersAndReturnNewCart("shailu7@gmail.com", 201, -1, 150);
		assertNotNull(cart);
	}
	
	@Test
	public void setFiltersAndReturnNewCartTestCase4() {
		Cart cart = cartServiceimplementation.setFiltersAndReturnNewCart("stft7@gmail.com", 7545, -1, 150);
		assertNotNull(cart);
	}

	/*@Test
	public void removeProductTestCase1() {
		Response response = cartServiceimplementation.removeProduct("chandu.kopalli22@gmailcom", 201, 1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void removeProductTestCase2() {
		Response response = cartServiceimplementation.removeProduct("chandu.kopalli22@gmailcom", 6533, 1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void removeProductTestCase3() {
		Response response = cartServiceimplementation.removeProduct("chandu.kopalli22@gmailcom", 201, -1);
		assertEquals(204, response.getStatus_code());
	}
	
	@Test
	public void removeProductTestCase4() {
		Response response = cartServiceimplementation.removeProduct("chandu.kopalli22@gmailcom", 206, 1);
		assertEquals(204, response.getStatus_code());
	}

	@Test
	public void checkIfUserExistTestCase2() {
		assertFalse(cartServiceimplementation.checkIfUserExist("shailu7@gmailcom"));
	}*/
}
