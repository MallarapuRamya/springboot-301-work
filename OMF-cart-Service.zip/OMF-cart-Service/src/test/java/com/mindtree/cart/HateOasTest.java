package com.mindtree.cart;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HateOasTest {

	@Autowired
	CartHateoasService hateOas;

	@Test
	public void getActiveCartTest() {
		CartResponse cartResponse = new CartResponse();
		Cart cart = new Cart();
		cartResponse.setCart(cart);
		cartResponse.setStatus_code(200);
		Resource<CartResponse> resource = hateOas.getActiveCart(cartResponse);
		assertEquals(200, resource.getContent().getStatus_code());
	}

	@Test
	public void addToCart() {
		Response response = new Response();
		response.setStatus_code(200);
		Resource<Response> resource = hateOas.addToCart(response, "shailu@gmail.com");
		assertEquals(200, resource.getContent().getStatus_code());

	}

	@Test
	public void removeCart() {
		Response response = new Response();
		response.setStatus_code(200);
		Resource<Response> resource = hateOas.removeCart(response, "shailu@gmail.com");
		assertEquals(200, resource.getContent().getStatus_code());
	}
	
	@Test
	public void removeProduct()
	{
		Response response = new Response();
		response.setStatus_code(200);
		Resource<Response> resource = hateOas.removeProduct(response, "shailu@gmail.com");
		assertEquals(200, resource.getContent().getStatus_code());
	}
}
