package com.mindtree.cart.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;

@Service
public interface CartHateoasService {

	Resource<CartResponse> getActiveCart(CartResponse activeCart);

	Resource<Response> addToCart(Response addToCart, String username);

	Resource<Response> removeCart(Response addToCart, String username);

	Resource<Response> removeProduct(Response addToCart, String username);

}
