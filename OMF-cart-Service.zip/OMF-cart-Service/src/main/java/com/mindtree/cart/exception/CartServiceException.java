package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class CartServiceException extends Exception {

	public CartServiceException(String string) {
		super(string);
	}

}
