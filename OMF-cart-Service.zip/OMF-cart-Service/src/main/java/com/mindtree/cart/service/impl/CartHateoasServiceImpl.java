package com.mindtree.cart.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;

@Service
public class CartHateoasServiceImpl implements CartHateoasService {

	@Value("${endpoint}")
	private String endpoint;

	@Override
	public Resource<CartResponse> getActiveCart(CartResponse activeCart) {
		Resource<CartResponse> resource = new Resource<CartResponse>(activeCart);

		try{
		if (activeCart.getStatus_code() != 204) {
			Link link1 = new Link(endpoint + "cart/addProduct/" + activeCart.getCart().getUserName());
			resource.add(link1);
			Link link2 = new Link(endpoint + "cart/dump/" + activeCart.getCart().getUserName());
			resource.add(link2);
			Link link3 = new Link(endpoint + "cart/removeProduct/" + activeCart.getCart().getUserName());
			resource.add(link3);
			return resource;
		}
		}catch(Exception e)
		{
			
		}
		return resource;

	}

	@Override
	public Resource<Response> addToCart(Response addToCart, String username) {
		Resource<Response> resource = new Resource<Response>(addToCart);

		if (addToCart.getStatus_code() != 204) {
			Link link1 = new Link(endpoint + "cart/addProduct/" + username);
			resource.add(link1);
			Link link2 = new Link(endpoint + "cart/dump/" + username);
			resource.add(link2);
			Link link3 = new Link(endpoint + "cart/removeProduct/" + username);
			resource.add(link3);
			Link link4 = new Link(endpoint + "cart/active/" + username);
			resource.add(link4);
			return resource;
		}
		return resource;
	}

	@Override
	public Resource<Response> removeCart(Response removeCart, String username) {
		Resource<Response> resource = new Resource<Response>(removeCart);

		if (removeCart.getStatus_code() != 204) {
			Link link1 = new Link(endpoint + "cart/addProduct/" + username);
			resource.add(link1);
			return resource;
		}
		return resource;
	}

	@Override
	public Resource<Response> removeProduct(Response removeProduct, String username) {
		Resource<Response> resource = new Resource<Response>(removeProduct);

		if (removeProduct.getStatus_code() != 204) {
			Link link1 = new Link(endpoint + "cart/addProduct/" + username);
			resource.add(link1);
			Link link2 = new Link(endpoint + "cart/dump/" + username);
			resource.add(link2);
			Link link3 = new Link(endpoint + "cart/removeProduct/" + username);
			resource.add(link3);
			Link link4 = new Link(endpoint + "cart/active/" + username);
			return resource;
		}
		
		return resource;
	}
}
