package com.mindtree.cart.entity;

import java.util.HashMap;
import java.util.Map;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "omf_cart")
@ApiModel(description=" Profile information of the cart application")
public class Cart {
	
	@Id
	@ApiModelProperty(notes ="The cart id for the omf_cart table")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	
	@JoinColumn
	@ElementCollection
	@MapKeyColumn(name = "productId")
	@ApiModelProperty(notes ="Items details for cart_items table")
	private Map<Integer, Integer> items = new HashMap<Integer, Integer>();
	
	@ApiModelProperty(notes ="The total price for the cart")
	private double totalPrice;
	
	@ApiModelProperty(notes ="The username for the cart")
	private String userName;
	
	@ApiModelProperty(notes ="The activatation status for the cart")
	private boolean isActive;

	public Cart() {
		super();
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public Map<Integer, Integer> getItems() {
		return items;
	}

	public void setItems(Map<Integer, Integer> items) {
		this.items = items;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", items=" + items + ", totalPrice=" + totalPrice + ", userName=" + userName
				+ ", isActive=" + isActive + ", getCartId()=" + getCartId() + ", getItems()=" + getItems()
				+ ", getTotalPrice()=" + getTotalPrice() + ", getUserName()=" + getUserName() + ", isActive()="
				+ isActive() + "]";
	}

	
}
