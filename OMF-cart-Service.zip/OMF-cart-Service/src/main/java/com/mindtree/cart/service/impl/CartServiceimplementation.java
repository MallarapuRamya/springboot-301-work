package com.mindtree.cart.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.dao.impl.CartDaoImplementation;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.exception.DataBaseConnectionException;
import com.mindtree.cart.exception.NoActiveCartFoundException;
import com.mindtree.cart.exception.QuantityMisMatchException;
import com.mindtree.cart.exception.ServiceNoActiveCartFoundException;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.ItemListResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartService;
import com.mindtree.cart.service.CartServiceProxy;
import com.mindtree.cart.service.UserServiceProxy;

@Service
public class CartServiceimplementation implements CartService {
	private final Logger LOG = Logger.getLogger(CartDaoImplementation.class);

	@Autowired
	private CartDao cartDao;

	@Autowired
	private CartServiceProxy cartServiceProxy;

	@Autowired
	private UserServiceProxy userProxy;
	
	@Value("${successCode1}")
	private int successCode1;

	@Value("${successCode2}")
	private int successCode2;

	@Value("${dataBaseFail}")
	private int failCode1;

	@Value("${failCode2}")
	private int failCode2;

	@Value("${dataNotFound}")
	private int dataNotFound;

	@Override
	public CartResponse getActiveCart(String userName) {
		CartResponse cartResponse = new CartResponse();
		
		try {
			
			if(!checkIfUserExist(userName)){
				return new CartResponse(dataNotFound, "User with username " +userName+" Does not exist", null);
			}
			
			Optional<Cart> cart = cartDao.getActiveCart(userName);
			try {

				if (!cart.isPresent() || !cart.get().isActive()) {
					throw new NoActiveCartFoundException("No Active Cart Found");
				} else {

					cartResponse.setStatus_code(successCode1);
					cartResponse.setMessage("Cart found");
					cartResponse.setCart(cart.get());
				}

			} catch (NoActiveCartFoundException noActiveCartFoundException) {
				LOG.error(noActiveCartFoundException.getMessage() + "for username :" + userName);
				return new CartResponse(dataNotFound, "Cart not found", null);
			}

		} catch (Exception exception) {
			LOG.error(exception.getMessage() + " Database issue");
			return new CartResponse(failCode1, "Something went wrong, Try again later", null);
		}

		return cartResponse;
	}

	@Override
	public Response removeCart(String userName) {
		Response response = new Response();
		
		try {
			
			if(!checkIfUserExist(userName)){
				return new CartResponse(dataNotFound, "User with username " +userName+" Does not exist", null);
			}
			
			Optional<Cart> cart = cartDao.getActiveCart(userName);
			
			if (!cart.isPresent()) {
				response.setStatus_code(failCode1);
				response.setMessage("No active cart present for the user.");
			} else {
				Cart deactivatedCart = cart.get();
				deactivatedCart.setActive(false);
				deactivatedCart = cartDao.saveCart(deactivatedCart);

				if (deactivatedCart != null) {
					response.setStatus_code(successCode1);
					response.setMessage("Cart deactivated Successfully.");
				} else {
					response.setStatus_code(failCode1);
					response.setMessage("Failed to deactivate the cart,Please try again.");
				}
			}
		} catch (DataBaseConnectionException dataBaseConnectionException) {
			dataBaseConnectionException.printStackTrace();
			LOG.error(dataBaseConnectionException.getMessage() + "Database issue");
			return new CartResponse(dataNotFound, "Cannot connect to Database , please try again later.", null);
		} catch (Exception exception) {
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(dataNotFound, "No active cart present for the user.", null);
		}

		return response;
	}

	@Override
	public Response addToCart(String userName, int productId, int quantity) {
		Response response = new Response();
		
		try {
			
			if(!checkIfUserExist(userName)){
				return new CartResponse(dataNotFound, "User with username " +userName+" Does not exist", null);
			}
			
			double productAmount = calculateTotalAmount(productId, quantity);
		
			Cart cart = beforeCartHook(userName, productId, quantity, productAmount);
			boolean status = cartDao.addToCart(cart);
			if(status==true)
			{
				response.setStatus_code(successCode1);
				response.setMessage("Product added to cart Successfully.");
			}else{
				response.setStatus_code(failCode2);
				response.setMessage("Failed to add the product in the cart.");
			}
		}catch(QuantityMisMatchException exception)
		{
			return new CartResponse(dataNotFound,"Please provide valid product quantity",null);
		}
		catch(NullPointerException nullPointerException)
		{
			nullPointerException.printStackTrace();
			LOG.error(nullPointerException.getMessage());
			return new CartResponse(dataNotFound, "Please provide valid product id.", null);
		}
		catch (Exception exception) {
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(dataNotFound, "Something went wrong, Please try again later", null);
		}

		return response;

	}

	@Override
	public Cart beforeCartHook(String userName, int productId, int quantity, double productAmount) throws QuantityMisMatchException,Exception{
		LOG.debug("Total Amount is :" + productAmount);
		Optional<Cart> cartResponse = cartDao.getActiveCart(userName);
		LOG.debug("=============>Cart response is :" + cartResponse);
		Cart responseCart = new Cart();

		if (!cartResponse.isPresent()) {
			Cart cart = setFiltersAndReturnNewCart(userName, productId, quantity, productAmount);
			responseCart = cartDao.createNewCart(cart);
		} else {
			Cart cart = cartResponse.get();
			LOG.debug("Cart items" + cart);

			Map<Integer, Integer> dbItems = cart.getItems();
			
			if (dbItems.containsKey(productId)) {
				if(quantity>0)
				dbItems.replace(productId, dbItems.get(productId) + quantity);
				else 
					throw new QuantityMisMatchException("Please enter valid product quantity.");
			} else {
				dbItems.put(productId, quantity);
			}

			cart.setItems(dbItems);
			cart.setTotalPrice(cart.getTotalPrice() + productAmount);
			responseCart = cartDao.saveCart(cart);

			if (responseCart == null) {
				throw new DataBaseConnectionException("Cannot connect to database. Try again later");
			}
		}

		return responseCart;
	}

	@Override
	public Cart setFiltersAndReturnNewCart(String userName, int productId, int quantity, double productAmount) {
		Cart cart = new Cart();
		Map<Integer, Integer> items = cart.getItems();
		items.put(productId, quantity);
		cart.setActive(true);
		cart.setUserName(userName);
		cart.setTotalPrice(productAmount);
		return cart;
	}

	@Override
	public double calculateTotalAmount(int productId, int quantity) {
		double amount = 0;
		amount = getPriceByProductId(productId);
		return (amount * quantity);
	}

	@Override
	public double getPriceByProductId(int productId) {
		List<Integer> itemList = new ArrayList<Integer>();
		itemList.add(productId);
		LOG.debug("itemsList"+itemList);
		ItemListResponse listRepsonse = cartServiceProxy.getByItemId(itemList);
		LOG.debug("=========getpricebyid"+listRepsonse);
		return listRepsonse.getItemList().get(0).getItemPrice();
	}

	@Override
	public Response removeProduct(String userName, int productId, int quantity) {
		Response response = new Response();
		
		if(!checkIfUserExist(userName)){
			return new CartResponse(dataNotFound, "User with username "+userName+" Does not exist", null);
		}
		
		double amount = 0;

		try {
			Optional<Cart> cartResponse = cartDao.getActiveCart(userName);
			if (!cartResponse.isPresent()) {
				throw new ServiceNoActiveCartFoundException("No active cart found for username :" + userName);
			} else {
				Cart cart = cartResponse.get();
				Map<Integer, Integer> dbItems = cart.getItems();

				if (!dbItems.containsKey(productId)) {
					String message = "Product with id:" + productId + "doesnt exist in cart :" + cart.getCartId();
					LOG.error(message);
					throw new ServiceNoActiveCartFoundException(message);
				}

				if (dbItems.get(productId) >= 1) {
					if(quantity>0)
					{
					dbItems.replace(productId, dbItems.get(productId) - quantity);
					}else
					{
						throw new QuantityMisMatchException("Please enter valid product quantity.");
					}
					if (dbItems.get(productId) <= 0) {
						dbItems.remove(productId);
						response.setStatus_code(successCode1);
						response.setMessage("The item count was reduced to 0 . Product has been removed from cart.");
					} else {
						response.setStatus_code(successCode1);
						response.setMessage("Product has been removed from cart.");
					}
					cart.setItems(dbItems);
					amount = cart.getTotalPrice() - calculateTotalAmount(productId, quantity);
					if (amount < 0)
						amount = 0;
					cart.setTotalPrice(amount);
					Cart removedCart = cartDao.saveCart(cart);

					if (removedCart == null) {
						throw new DataBaseConnectionException("Cannot connect to database. Try again later");
					}
				}
			}
		} catch (DataBaseConnectionException dataBaseConnectionException) {
			dataBaseConnectionException.printStackTrace();
			LOG.error(dataBaseConnectionException.getMessage() + "Database issue");
			return new CartResponse(failCode2, "Something went wrong , Please try again", null);
		}
		catch (ServiceNoActiveCartFoundException exception) {
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(dataNotFound, "No product found for the given id.", null);
		}
		catch (QuantityMisMatchException exception) {
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(dataNotFound, "Please enter valid product quantity.", null);
		}
		catch (Exception exception) {
			exception.printStackTrace();
			LOG.error(exception.getMessage());
			return new CartResponse(dataNotFound, "No active cart present for the user.", null);
		}
			
		return response;
	}
	
	@Override
	public boolean checkIfUserExist(String userName) {
		try{
		if(userProxy.getUserById(userName).getContent().getStatusCode()==200){
			return true;
		}
		}catch(Exception e){
			LOG.error("Something went wrong while fetching user information !");
			e.printStackTrace();
			throw e;
		}
		return false;
	}

}
