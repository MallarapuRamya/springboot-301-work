package com.mindtree.cart.dao;

import java.util.Optional;
import org.springframework.stereotype.Service;
import com.mindtree.cart.entity.Cart;

@Service
public interface CartDao {

	Optional<Cart> getActiveCart(String userName);

	Cart saveCart(Cart deactivatedCart) throws Exception;

	Cart createNewCart(Cart cart);

	boolean addToCart(Cart cart) throws Exception;

}
