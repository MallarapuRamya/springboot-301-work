package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class QuantityMisMatchException extends Exception{
	
	public QuantityMisMatchException(String string) {
		super(string);
	}

}
