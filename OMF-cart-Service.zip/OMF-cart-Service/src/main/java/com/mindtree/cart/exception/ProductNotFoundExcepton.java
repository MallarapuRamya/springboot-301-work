package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class ProductNotFoundExcepton extends Exception{
	
	public ProductNotFoundExcepton(String message)
	{
		super(message);
	}

}
