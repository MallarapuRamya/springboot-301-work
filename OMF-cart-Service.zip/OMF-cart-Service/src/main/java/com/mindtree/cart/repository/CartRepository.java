package com.mindtree.cart.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mindtree.cart.entity.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, String> {

	@Query(nativeQuery = true, value = "select cart_id, is_active,total_price,user_name from omf_cart where user_name=LOWER(:userName) and is_active=true")
	public Optional<Cart> getActiveCart(@Param("userName") String userName);

	@Query(nativeQuery = true, value = "select * from omf_cart where cart_id=LOWER(:cartId) and is_active=true")
	public Optional<Cart> findById(@Param("cartId") int cartId);

	@Query(nativeQuery = true, value = "select total_price from omf_cart inner join cart_items on cart_items.cart_cart_id=omf_cart.cart_id and cart_items.productId=LOWE(:productId) and user_name=(:userName)")
	public void getPriceByProductId(@Param("productId")int productId,@Param("userName")String userName);

}