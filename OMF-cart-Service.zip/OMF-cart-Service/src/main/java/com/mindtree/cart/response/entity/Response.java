package com.mindtree.cart.response.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Non informational respose to be shown for the request")
public class Response {
	
	@ApiModelProperty(notes = "Status code for the operation")
	private int status_code;
	
	@ApiModelProperty(notes = "Status message for the operation")
	private String message;

	public int getStatus_code() {
		return status_code;
	}

	public void setStatus_code(int status_code) {
		this.status_code = status_code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Response(int status_code, String message) {
		super();
		this.status_code = status_code;
		this.message = message;
	}

	public Response() {
		
	}

	@Override
	public String toString() {
		return "Response [status_code=" + status_code + ", message=" + message + ", getStatus_code()="
				+ getStatus_code() + ", getMessage()=" + getMessage() + "]";
	}

}