package com.mindtree.cart.exception;

@SuppressWarnings("serial")
public class DataBaseConnectionException extends CartServiceException {

	public DataBaseConnectionException(String string) {
		super(string);
	}

}
