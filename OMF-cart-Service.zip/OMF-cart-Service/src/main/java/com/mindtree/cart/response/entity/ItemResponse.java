package com.mindtree.cart.response.entity;

public class ItemResponse {
	private double itemPrice;

	public ItemResponse() {
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

}
