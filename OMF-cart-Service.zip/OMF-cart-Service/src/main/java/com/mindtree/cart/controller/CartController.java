package com.mindtree.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;
import com.mindtree.cart.service.CartHateoasService;
import com.mindtree.cart.service.CartService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/cart")
@Api(value = "Cart Service", description = "Functionalities provided for Cart Service",tags = { "Cart" })
public class CartController {

	@Autowired
	private CartService cartService;
	
	@Autowired
	private CartHateoasService cartHateoasService;

	@ApiOperation(value="Fetch details of the cart using username", authorizations = {
    @Authorization(value = "oauth2", scopes = {}),
    @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
	@ExtensionProperty(name = "customer", value = "User is allowed to perform several operations on the cart.")})},
	produces = "application/json", notes = "Admin is able to view details of cart.")
	@ApiResponses(value={
	@ApiResponse(code = 200, message = "Successfully retrived the cart details"),
	@ApiResponse(code = 204, message = "No data found or something went wrong")
	})
	
	@RequestMapping(value = "/active/{userName}", method = RequestMethod.GET)
	public Resource<CartResponse> getActiveCart(@PathVariable String userName) {
		return cartHateoasService.getActiveCart(cartService.getActiveCart(userName));
	}

	
	@ApiOperation(value="Add new product to cart",authorizations = {
		    @Authorization(value = "oauth2", scopes = {}),
		    @Authorization(value = "Bearer")},
			extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "User is allowed add product into the cart")})},
			produces = "application/json", notes = "Admin is able to view details of cart.")
	@ApiResponses(value={
	@ApiResponse(code = 200, message = "Successfully added new product to cart"),
	@ApiResponse(code = 204, message = "No data found or something went wrong")	})
	
	
	@RequestMapping(value = "/addProduct/{userName}", method = RequestMethod.POST)
	public Resource<Response> addToCart(@PathVariable String userName, @RequestParam int productId,
			@RequestParam int quantity) {
		return cartHateoasService.addToCart(cartService.addToCart(userName, productId, quantity), userName);
	}

	@ApiOperation(value="Remove cart", authorizations = {
    @Authorization(value = "oauth2", scopes = {}),
    @Authorization(value = "Bearer")},
	extensions = {@Extension(name = "roles", properties = {
	@ExtensionProperty(name = "customer", value = "User is allowed to perform several operations on the cart.")})},
	produces = "application/json", notes = "User is able to remove his/her cart")
	@ApiResponses(value={
	@ApiResponse(code = 200, message = "Successfully removed the cart"),
	@ApiResponse(code = 204, message = "No data found or something went wrong")	})
	
	
	@RequestMapping(value = "/remove/{userName}", method = RequestMethod.DELETE)
	public Resource<Response> removeCart(@PathVariable String userName) {
		return cartHateoasService.removeCart(cartService.removeCart(userName), userName);
	}
	
	
	@ApiOperation(value="Remove product from cart" ,authorizations = {
		    @Authorization(value = "oauth2", scopes = {}),
		    @Authorization(value = "Bearer")},
			extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "User is allowed to remove from cart.")})},
			produces = "application/json", notes = "Admin is able to view details of cart.")
	@ApiResponses(value={
	@ApiResponse(code = 200, message = "Successfully removed  product from cart"),
	@ApiResponse(code = 204, message = "No data found or something went wrong")	})

	@RequestMapping(value = "/removeProduct/{userName}", method = RequestMethod.DELETE)
	public Resource<Response> removeProduct(@PathVariable String userName, @RequestParam int productId,
			@RequestParam int quantity) {
		return cartHateoasService.removeProduct(cartService.removeProduct(userName, productId, quantity), userName);
	}
	
	
	@ApiOperation(value="Deactive the user cart", authorizations = {
    @Authorization(value = "oauth2", scopes = {}),
    @Authorization(value = "Bearer")},extensions = {@Extension(name = "roles", properties = {
	@ExtensionProperty(name = "customer", value = "Functionality used for Microservices communication.")})},
    produces = "application/json",
    notes = "This functionality is used for Microservices communication for deactivating the user cart, "
    		+ "It will not be giving user friendly response. ")
	@ApiResponses(value={
	@ApiResponse(code = 200, message = "Successfully deactivated the user"),
	@ApiResponse(code = 204, message = "No data found or something went wrong")
	})
	
	@RequestMapping(value = "/deactivate/{userName}", method = RequestMethod.DELETE)
	public Response deactivateCart(@PathVariable String userName){
		return cartService.removeCart(userName);
		
	}	
}