package com.mindtree.cart.response.entity;

import com.mindtree.cart.entity.Cart;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational respose to be shown for the request")
public class CartResponse extends Response {
	
	@ApiModelProperty(notes = "Order details")
	private Cart cart;

	public CartResponse() {
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public CartResponse(int status_code,String message,Cart cart) {
		super(status_code,message);
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "CartResponse [cart=" + cart + ", getCart()=" + getCart() + "]";
	}
	
}