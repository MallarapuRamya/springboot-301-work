package com.mindtree.cart.service;



import org.springframework.stereotype.Service;

import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.exception.QuantityMisMatchException;
import com.mindtree.cart.response.entity.CartResponse;
import com.mindtree.cart.response.entity.Response;

@Service
public interface CartService {

	CartResponse getActiveCart(String userName);

	Response removeCart(String userName);

	Response addToCart(String userName, int productId, int quantity);

	double calculateTotalAmount(int productId, int quantity);

	double getPriceByProductId(int productId);

	Response removeProduct(String userName, int productId, int quantity);

	boolean checkIfUserExist(String userName);

	Cart setFiltersAndReturnNewCart(String userName, int productId, int quantity, double productAmount);

	Cart beforeCartHook(String userName, int productId, int quantity, double productAmount)
			throws QuantityMisMatchException, Exception;

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
	
	/*CartResponse getActiveCart(String cartId);

	Response addToCart(String userName, int productId, int quantity);

	Response removeCart(String userName);

	Response removeProduct(String userName, int productId, int quantity);

	Response deactivateCart(int cartId);

	double getPriceByProductId(int productId);
*/

