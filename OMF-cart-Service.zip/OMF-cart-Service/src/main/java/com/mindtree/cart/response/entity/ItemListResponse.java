package com.mindtree.cart.response.entity;

import java.util.List;

import com.mindtree.cart.entity.Items;

import io.swagger.annotations.ApiModel;

@ApiModel(description="Informational of itemslist respose to be shown for the request")
public class ItemListResponse {
	private List<Items> itemList;

	public List<Items> getItemList() {
		return itemList;
	}

	public void setItemList(List<Items> itemList) {
		this.itemList = itemList;
	}

}
