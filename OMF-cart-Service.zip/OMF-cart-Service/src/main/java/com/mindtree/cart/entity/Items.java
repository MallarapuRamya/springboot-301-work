package com.mindtree.cart.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Information of the items for the application")
public class Items {

	@ApiModelProperty(notes ="Item id for cart_items table")
	private int itemId;
	
	@ApiModelProperty(notes ="Item name for cart_items table")
	private String itemName;
	
	@ApiModelProperty(notes ="Item price for cart_items table")
	private double itemPrice;
	
	public Items() {
		
	}
	public Items(int itemId, String itemName, double itemPrice) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", getItemId()="
				+ getItemId() + ", getItemName()=" + getItemName() + ", getItemPrice()=" + getItemPrice() + "]";
	}
	
}
