package com.mindtree.cart.dao.impl;

import java.util.Optional;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.cart.dao.CartDao;
import com.mindtree.cart.entity.Cart;
import com.mindtree.cart.repository.CartRepository;

@Service
public class CartDaoImplementation implements CartDao {

	private final Logger LOG = Logger.getLogger(CartDaoImplementation.class);

	@Autowired
	private CartRepository cartRepository;

	@Override
	public Optional<Cart> getActiveCart(String userName) {
		return cartRepository.getActiveCart(userName);
	}

	@Override
	public Cart saveCart(Cart cart) throws Exception {
		return cartRepository.save(cart);
	}

	@Override
	public Cart createNewCart(Cart cart) {
		return cartRepository.save(cart);
	}

	@Override
	public boolean addToCart(Cart cart) throws Exception {
		if (cartRepository.save(cart) != null) {
			LOG.debug(cart);
			return true;
		}
		return false;
	}

}