package com.mindtree.authorization.service;

import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mindtree.authorization.entity.CustomUserDetails;
import com.mindtree.authorization.entity.User;

@Service
public class ClientUserDetailsService implements UserDetailsService {

	private final Logger LOG = Logger.getLogger(ClientUserDetailsService.class);

	@Autowired
	UserServiceProxy userProxy;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> userInfo = userProxy.getByUsernameAdmin(username);
		if (!userInfo.isPresent()) {
			LOG.error("User does not exist");
			throw new UsernameNotFoundException(username);
		}
		User user = userInfo.get();
		return new CustomUserDetails(user);
	}
}