package com.mindtree.authorization.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.mindtree.authorization.handler.CustomUrlAuthenticationSuccessHandler;

@EnableResourceServer
@Configuration
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
	private static final String RESOURCE_ID = "SMM_AuthorizationService";

	@Override
	public void configure(ResourceServerSecurityConfigurer resource) {
		resource.getTokenStore();
		resource.resourceId(RESOURCE_ID).stateless(false);
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests()
				.antMatchers("/oauth/**", "/callback", "/search/products/**", "/users/user/register","/reviews/review/getAllRatings","/reviews/review/getAllReviews")
				.permitAll().anyRequest().authenticated().and().oauth2Login().successHandler(myAuthenticationSuccessHandler());
	}

	@Bean
	public AuthenticationSuccessHandler myAuthenticationSuccessHandler() {
		return new CustomUrlAuthenticationSuccessHandler();
	}

}
