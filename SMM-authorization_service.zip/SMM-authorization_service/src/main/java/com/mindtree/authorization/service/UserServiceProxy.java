package com.mindtree.authorization.service;

import java.util.Optional;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.authorization.entity.User;

@FeignClient("SMM-userService")
@RibbonClient("SMM-userService")
@Service
@RequestMapping(value = "/user")
public interface UserServiceProxy {


	@RequestMapping(value = "/username/{username}")
	public Optional<User> getByUsernameAdmin(@PathVariable(name = "username") String username);
	
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public void registerUser(@RequestBody User user);
}