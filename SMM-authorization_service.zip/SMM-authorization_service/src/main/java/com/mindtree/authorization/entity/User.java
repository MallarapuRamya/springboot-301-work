package com.mindtree.authorization.entity;

import java.io.Serializable;


@SuppressWarnings("serial")
public class User implements Serializable{

	private String username;

	private String name;

	private String password;

	private long mobile;
	
	private boolean enable = true;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", name=" + name + ", password=" + password
				+ ", mobile=" + mobile + ", enable=" + enable + "]";
	}

}
