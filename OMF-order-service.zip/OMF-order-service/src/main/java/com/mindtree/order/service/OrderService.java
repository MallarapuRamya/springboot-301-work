package com.mindtree.order.service;

import javax.validation.Valid;

import org.springframework.hateoas.Resource;

import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;

public interface OrderService {

	public OrderResponse saveOrderDetails(String username);

	public OrderResponse getOrderById(int orderId);

	public OrderResponse deleteOrder(int orderId);

	public OrderResponse editAddress(int orderId, String address);

	public OrderListResponse getOrderByuserName(String userName);

}
