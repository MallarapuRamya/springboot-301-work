package com.mindtree.order.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@FeignClient(name="OMF-userService")
@RequestMapping("/user")
@Api( description = "For internal service communication only and it will not be giving user friendly response",tags={"User feign client"})
@Service
public interface UserServiceProxy {
	
	@ApiOperation(value = "Fetching the user details using username.",authorizations = {
		    @Authorization(value = "oauth2", scopes = {}),
		    @Authorization(value = "Bearer")},
			extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "User is allowed to get user address from user service.")})},
			produces = "application/json", notes = "Only admin can be used as an internal usage for servive communication.")
			@ApiResponses(value={
			@ApiResponse(code = 200, message = "Successfully retrived the item details"),
			@ApiResponse(code = 204, message = "No data found or something went wrong")
			})
	@GetMapping("/getUserAddress/{userName}")
	public String getUserAddress(@PathVariable(value = "userName") String userName);
	
}
