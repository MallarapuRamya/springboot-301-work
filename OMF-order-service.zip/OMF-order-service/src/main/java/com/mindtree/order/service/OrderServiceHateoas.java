package com.mindtree.order.service;

import org.springframework.hateoas.Resource;

import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;

public interface OrderServiceHateoas {

	Resource<OrderResponse> placeOrder(OrderResponse orderPlaceResponse);
	
	Resource<OrderResponse> viewOrderById(OrderResponse orderIdResponse);

	Resource<OrderResponse> cancelOrder(OrderResponse orderResponse);

	Resource<OrderListResponse> getOrderByuserName(OrderListResponse orderListResponse);

	Resource<OrderResponse> updateOrder(OrderResponse orderIdResponse);

}
