//package com.mindtree.order.entity;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.persistence.Column;
//import javax.persistence.ElementCollection;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Table(name = "omf_item")
//@Entity
//public class Item {
//	@Id
//	private int productId;
//	@Column(name = "productName")
//	private String productName;
//	@Column(name = "productPrice")
//	private double productPrice;
//	@Column(name = "productQuantity")
//	private int productQuantity;
//	
//
//	public Item() {
//
//	}
//
//	public int getProductId() {
//		return productId;
//	}
//
//	public void setProductId(int productId) {
//		this.productId = productId;
//	}
//
//	public String getProductName() {
//		return productName;
//	}
//
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}
//
//	public double getProductPrice() {
//		return productPrice;
//	}
//
//	public void setProductPrice(double productPrice) {
//		this.productPrice = productPrice;
//	}
//
//	public int getProductQuantity() {
//		return productQuantity;
//	}
//
//	public void setProductQuantity(int productQuantity) {
//		this.productQuantity = productQuantity;
//	}
//
//	public Item(int productId, String productName, double productPrice, int productQuantity) {
//		super();
//		this.productId = productId;
//		this.productName = productName;
//		this.productPrice = productPrice;
//		this.productQuantity = productQuantity;
//	}
//
//	
//}
