package com.mindtree.order.dao;

import java.util.List;
import java.util.Optional;

import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;

public interface OrderDao {

	public Order saveOrderDetails(Order order) throws DatabaseConnectivityException ;

	public Optional<Order> getOrderById(int orderId) throws  DatabaseConnectivityException ;

	public boolean deleteOrder(int orderId) throws DatabaseConnectivityException, ResourceNotFoundException;

	public Order editAddress(int orderId, String address) throws DatabaseConnectivityException, ResourceNotFoundException;

	public List<Order> getOrderListByuserName(String userName) throws DatabaseConnectivityException ;

}
