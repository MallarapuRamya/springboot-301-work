package com.mindtree.order.dao.impl;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.order.dao.OrderDao;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.repository.OrderNameRepo;
import com.mindtree.order.repository.OrderRepository;

@Service
public class OrderDaoImpl implements OrderDao {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderNameRepo orderNameRepo;

	private final Logger LOG = Logger.getLogger(OrderDaoImpl.class);

	@Override
	public Order saveOrderDetails(Order order) throws DatabaseConnectivityException {
		try {
			Order orderPlace = orderRepository.save(order);
			return orderPlace;
		} catch (Exception e) {
			throw new DatabaseConnectivityException("Could not connect to the Database.");
		}
	}

	@Override
	public Optional<Order> getOrderById(int orderId) throws DatabaseConnectivityException {
		try {
			Optional<Order> order = orderRepository.findById(orderId);
			return order;
		} catch (Exception e) {
			throw new DatabaseConnectivityException("Could not connect to the Database.");
		}

	}

	@Override
	public List<Order> getOrderListByuserName(String userName) throws DatabaseConnectivityException {
		try {
			List<Order> orderList = orderNameRepo.getOrderByuserName(userName);
			return orderList;
		} catch (Exception e) {
			throw new DatabaseConnectivityException("Could not connect to the Database.");
		}
	}

	@Override
	public Order editAddress(int orderId, String address)
			throws DatabaseConnectivityException, ResourceNotFoundException {
		Optional<Order> order;

			order = getOrderById(orderId);

			if (order.isPresent()) {
				Order getOrder = order.get();
				getOrder.setAddress(address);
				Order updatedOrder = saveOrderDetails(getOrder);
				return updatedOrder;
			} else {
				throw new ResourceNotFoundException("Could not find any order for id : " + orderId);
			}
	}

	@Override
	public boolean deleteOrder(int orderId) throws ResourceNotFoundException, DatabaseConnectivityException {
		boolean status = false;
		Optional<Order> order;

		try {
			order = orderRepository.findById(orderId);
		} catch (Exception e) {
			LOG.error("Could not connect to database");
			e.printStackTrace();
			throw new DatabaseConnectivityException("Could not connect to the Database.");
		}

		try {
			if (order.isPresent()) {
				orderRepository.deleteById(orderId);
				status = true;
			} else {
				throw new ResourceNotFoundException("No orders found for the given OrderId " + orderId);
			}
		} catch (ResourceNotFoundException e) {
			throw new ResourceNotFoundException(e.getMessage());
		}
		return status;
	}

}
