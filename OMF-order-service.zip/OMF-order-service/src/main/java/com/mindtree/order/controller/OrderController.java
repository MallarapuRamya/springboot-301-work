package com.mindtree.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.OrderServiceHateoas;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping("/order")
@Api(value = "Order Service", description = "Services provided for Order Service", tags = { "Order" })
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private OrderServiceHateoas orderServiceHateoas;

	/* Registering new order */
	@ApiOperation(value = "Place an order.", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "User is allowed to perform place order by getting the information from cart service.") }) }, produces = "application/json", notes = "Admin is able to view details of order.")
			@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully placed an order"),
			@ApiResponse(code = 204, message = "No data found or something went wrong") })

	@PostMapping("/placeOrder/{username}")
	public Resource<OrderResponse> createOrder(@PathVariable String username) {
		return orderServiceHateoas.placeOrder(orderService.saveOrderDetails(username));
	}

	/* Viewing a specific order based on its OrderID */
	@ApiOperation(value = "Fetch order details using its order Id", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "User is allowed see all his order details after placing the order.") }) }, produces = "application/json", notes = "Admin is able to view details of order.")
			@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved the order details"),
			@ApiResponse(code = 204, message = "No data found or something went wrong")

	})

	@GetMapping("/viewOrder/{orderId}")
	public Resource<OrderResponse> getOrderById(@PathVariable(value = "orderId") int orderId) {
		return orderServiceHateoas.viewOrderById(orderService.getOrderById(orderId));
	}

	/* Editing the address for an order */
	@ApiOperation(value = "Edit the existing order's address details.", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "User is allowed to edit the address before placing the order.") }) }, produces = "application/json", notes = "Admin is able to view details of cart.")
			@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully changed the order address details"),
			@ApiResponse(code = 204, message = "No data found or something went wrong") })

	@PutMapping("/editAddress/{orderId}")
	public Resource<OrderResponse> editAddress(@PathVariable(value = "orderId") int orderId,
			@RequestBody String address) {
		return orderServiceHateoas.updateOrder(orderService.editAddress(orderId, address));
	}

	/* Viewing order list by UserName */
	@ApiOperation(value = "Fetch order details list using its username", authorizations = {
			@Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "User is allowed to view all order details.") }) }, produces = "application/json", notes = "Admin is able to view details of cart.")
			@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved the list of order details "),
			@ApiResponse(code = 204, message = "No data found or something went wrong") })

	@GetMapping("/viewOrderList/{userName}")
	public Resource<OrderListResponse> getOrderByuserName(@PathVariable(value = "userName") String userName) {
		return orderServiceHateoas.getOrderByuserName(orderService.getOrderByuserName(userName));
	}

	/* Canceling an order */
	@ApiOperation(value = "Canceling the order", authorizations = { @Authorization(value = "oauth2", scopes = {}),
			@Authorization(value = "Bearer") }, extensions = { @Extension(name = "roles", properties = {
					@ExtensionProperty(name = "customer", value = "User is allowed to cancel his order after placing the order.") }) }, produces = "application/json", notes = "Admin is able to view details of cart.")
			@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully canceled an order "),
			@ApiResponse(code = 204, message = "No data found or something went wrong") })

	@DeleteMapping("/cancelOrder/{orderId}")
	public Resource<OrderResponse> deleteOrder(@PathVariable(value = "orderId") int orderId) {
		return orderServiceHateoas.cancelOrder(orderService.deleteOrder(orderId));
	}
	

}
