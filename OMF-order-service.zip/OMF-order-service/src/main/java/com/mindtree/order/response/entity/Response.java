package com.mindtree.order.response.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Informational respose to be shown for the request")
public class Response {

	@ApiModelProperty(notes = "Status code for the response")
	private int statusCode;
	@ApiModelProperty(notes = "Status message for the response")
	private String status;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Response(int statusCode, String status) {
		this.statusCode = statusCode;
		this.status = status;
	}

	public Response() {

	}

}
