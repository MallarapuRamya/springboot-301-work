package com.mindtree.order.response.entity;

import java.util.List;

import com.mindtree.order.entity.Order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Non informational respose to be shown for the request")
public class OrderListResponse extends Response {

	@ApiModelProperty(notes = "List of order details")
	private List<Order> orderList;

	public OrderListResponse(int statusCode, String status, List<Order> orderList) {
		super(statusCode, status);
		this.orderList = orderList;
	}

	public OrderListResponse() {
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

}