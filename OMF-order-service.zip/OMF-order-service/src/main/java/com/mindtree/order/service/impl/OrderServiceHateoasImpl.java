package com.mindtree.order.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.OrderServiceHateoas;

@Service
@PropertySource("classpath:application.properties")
public class OrderServiceHateoasImpl implements OrderServiceHateoas {

	@Value("${endpoint}")
	private String endpoint;

	@Override
	public Resource<OrderResponse> placeOrder(OrderResponse orderPlaceResponse) {
		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderPlaceResponse);

		try{
		if (orderPlaceResponse.getStatusCode()!=204)
		{
			Link link1= new Link(endpoint+"editAddress/"+orderPlaceResponse.getOrder().getOrderId());
			Link link2=new Link(endpoint+"viewOrderList/"+orderPlaceResponse.getOrder().getUserName());
			Link link3=new Link(endpoint+"cancelOrder/"+orderPlaceResponse.getOrder().getOrderId());
			resource.add(link1);
			resource.add(link2);
			resource.add(link3);
			return resource;
			
		}
		else{
			return resource;
		}
		}catch(Exception e){
			return resource;
		}
	}

	@Override
	public Resource<OrderResponse> viewOrderById(OrderResponse orderIdResponse) {
		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderIdResponse);

		try{
			
		if (orderIdResponse.getStatusCode() != 204) {
			Link link1=new Link(endpoint+"editAddress/"+orderIdResponse.getOrder().getOrderId());
			Link link2=new Link(endpoint+"viewOrderList/"+orderIdResponse.getOrder().getUserName());
			Link link3=new Link(endpoint+"cancelOrder/"+orderIdResponse.getOrder().getOrderId());
			resource.add(link1);
			resource.add(link2);
			resource.add(link3);
			return resource;
		}
		else{
		return resource;
		}
		}catch(Exception e){
			return resource;
		}
	}

	@Override
	public Resource<OrderResponse> cancelOrder(OrderResponse orderIdResponse) {
		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderIdResponse);

		try{
		if (orderIdResponse.getStatusCode() != 204) {
			Link link1=new Link(endpoint+"placeOrder/"+orderIdResponse.getOrder().getUserName());
			resource.add(link1);
			return resource;
		}else{
		
		return resource;
		}
		}catch(Exception e){
			return resource;
		}
	}

	@Override
	public Resource<OrderListResponse> getOrderByuserName(OrderListResponse orderListResponse) {
		Resource<OrderListResponse> resource = new Resource<OrderListResponse>(orderListResponse);
		try{
			if(orderListResponse.getStatusCode()!=204)
			{
				Link link1=new Link(endpoint+"placeOrder/"+orderListResponse.getOrderList().get(0).getUserName());
				resource.add(link1);
				return resource;
			}
			else{
		
		return resource;
			}
		}catch(Exception e){
			return resource;
		}
	
	}

	@Override
	public Resource<OrderResponse> updateOrder(OrderResponse orderIdResponse) {
		Resource<OrderResponse> resource = new Resource<OrderResponse>(orderIdResponse);
		
		try{
			
		if (orderIdResponse.getStatusCode() != 204) {
			Link link2 = new Link(endpoint+"viewOrderList/"+orderIdResponse.getOrder().getUserName());
			Link link3=new Link(endpoint+"cancelOrder/"+orderIdResponse.getOrder().getOrderId());
			resource.add(link2);
			resource.add(link3);
			return resource;
		}
		else{
		
		return resource;
		}
		}catch(Exception e){
			return resource;
		}
		
	}

}
