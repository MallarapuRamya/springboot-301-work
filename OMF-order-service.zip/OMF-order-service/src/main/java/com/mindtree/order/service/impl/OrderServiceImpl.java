package com.mindtree.order.service.impl;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.logging.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.order.dao.impl.OrderDaoImpl;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.CartServiceProxy;
import com.mindtree.order.service.OrderService;
import com.mindtree.order.service.UserServiceProxy;

@Service
@PropertySource("classpath:application.properties")
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDaoImpl orderDaoImpl;

	@Autowired
	private CartServiceProxy cartServiceProxy;

	@Autowired
	private UserServiceProxy userServiceProxy;

	@Value("${status.notFound}")
	private int notFoundStatus;

	@Value("${status.dbError}")
	private int dbError;

	private final Logger LOG = Logger.getLogger(OrderServiceImpl.class);

	/* Placing an order and storing the details into the database */
	@Override
	public OrderResponse saveOrderDetails(String username) {


		try {
			String address = getUserInfo(username);
			Cart cart = getCartForCurrentUser(username);

			if (cart.isActive() == true) {

				Order order = createOrderModel(cart, address);

				try {
					order = orderDaoImpl.saveOrderDetails(order);
				} catch (Exception e) {
					LOG.error("Could not save item. Please refer logs.");
					e.printStackTrace();
					return new OrderResponse(notFoundStatus, "Could not place order , please try again later!", null);
				}
				try {
					Response response=cartServiceProxy.deactivateCart(username);
					return new OrderResponse(response.getStatusCode(),"Order Successfully Placed , Order id is : " + order.getOrderId(),order);
				} catch (Exception e) {
					boolean isDeleted=orderDaoImpl.deleteOrder(order.getOrderId());
					LOG.info(isDeleted); 
					LOG.error("Could not save item. Please refer logs.");
					e.printStackTrace();
					return new OrderResponse(notFoundStatus, "Could not place order , please try again later!", null);
				}

			} else {
				throw new ResourceNotFoundException("No active cart for User with username " + username);
			}
		} catch (ResourceNotFoundException e) {
			e.getMessage();
			e.printStackTrace();
			return new OrderResponse(notFoundStatus, e.getMessage(), null);
		} catch (DatabaseConnectivityException e) {
			LOG.error("Something went wrong, Please try again later!");
			e.printStackTrace();
			return new OrderResponse(notFoundStatus, "Something went wrong. Please try again later", null);
		}

	}

	public Order createOrderModel(Cart cart, String address) {

		Order order = new Order();
		order.setAddress(address);
		order.setUserName(cart.getUserName());
		order.setItems(cart.getItems());
		order.setTotalPrice(cart.getTotalPrice());
		return order;

	}

	public Cart getCartForCurrentUser(String username) throws ResourceNotFoundException {

		Resource<CartResponse> activeCart = cartServiceProxy.getActiveCart(username);

		if (activeCart.getContent().getCart() == null) {
			throw new ResourceNotFoundException(
					"There is no active cart found for user : " + username + " Please add some items to the cart.");
		}

		Cart cart = new Cart();
		BeanUtils.copyProperties(activeCart.getContent().getCart(), cart);
		return cart;

	}

	public String getUserInfo(String username) throws DatabaseConnectivityException{
		try{
		return userServiceProxy.getUserAddress(username);
		}catch(Exception e)
		{
			throw new DatabaseConnectivityException("Could not connect to the Database.");
		}
	}

	@Override
	public OrderResponse getOrderById(int orderId) {
		OrderResponse orderResponse = new OrderResponse();

		try {
			Optional<Order> order = orderDaoImpl.getOrderById(orderId);

			if (order.isPresent()) {
				LOG.debug("Order information is present");
				orderResponse.setStatusCode(200);
				orderResponse.setStatus("Order information fetched successfully");
				orderResponse.setOrder(order.get());
			} else {
				throw new ResourceNotFoundException("No orders found for the given order ID :" + orderId);
			}

		} catch (ResourceNotFoundException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderResponse(notFoundStatus, e.getMessage(), null);
		}catch (DatabaseConnectivityException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderResponse(dbError, e.getMessage(), null);
		} 

		return orderResponse;
	}

	@Override
	public OrderListResponse getOrderByuserName(String userName) {
		OrderListResponse orderListResponse = new OrderListResponse();
		List<Order> orderList;

		try {
			orderList = orderDaoImpl.getOrderListByuserName(userName);
			LOG.debug("Fetching all the order details of a based on the UserName");

			if (!CollectionUtils.isEmpty(orderList)) {
				LOG.info("Status code for a successful fetch of a requested Order ID");
				orderListResponse.setOrderList(orderList);
				orderListResponse.setStatusCode(200);
				orderListResponse.setStatus("Found orders for username " + userName);
			} else {
				throw new ResourceNotFoundException("No orders found for the user");
			}

		} catch (DatabaseConnectivityException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderListResponse(dbError, e.getMessage(), null);

		} catch (ResourceNotFoundException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderListResponse(notFoundStatus, e.getMessage(), null);

		}
		return orderListResponse;
	}

	@Override
	public OrderResponse editAddress(int orderId, String address) {
		OrderResponse orderResponse = new OrderResponse();

		LOG.debug("Editing order address details after placing an order " + orderId);

		if (address.isEmpty()) {
			return new OrderResponse(204, "Please enter a valid address for performing address update", null);
		}
		try {
			Order order = orderDaoImpl.editAddress(orderId, address);
			LOG.debug("Status code for a successful fetch of a requested Order ID");
			orderResponse.setStatusCode(200);
			orderResponse.setStatus("Order Address successfully updated");
			orderResponse.setOrder(order);

		} catch (ResourceNotFoundException e) {
			return new OrderResponse(notFoundStatus, e.getMessage(), null);
		} catch (DatabaseConnectivityException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderResponse(dbError, e.getMessage(), null);
		} 

		return orderResponse;
	}

	@Override
	public OrderResponse deleteOrder(int orderId) {
		OrderResponse response = new OrderResponse();

		try {
			LOG.debug("Canceling the order based on the user's request for the given Order Id " + orderId);
			boolean status = orderDaoImpl.deleteOrder(orderId);

			if (status == true) {
				response.setStatusCode(200);
				response.setStatus("Order with id : " + orderId + " has been Canceled");
			} else {
				return new OrderResponse(notFoundStatus, "Could not cancel order. Please try again later", null);

			}

		} catch (ResourceNotFoundException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderResponse(dbError, e.getMessage(), null);
		}catch (DatabaseConnectivityException e) {
			LOG.error(e.getMessage());
			e.printStackTrace();
			return new OrderResponse(dbError, e.getMessage(), null);
		}
		return response;

	}
}
