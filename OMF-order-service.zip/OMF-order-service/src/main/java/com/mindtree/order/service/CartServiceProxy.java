package com.mindtree.order.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.Response;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@FeignClient(name = "OMF-cartService")
@Service
@Api(description = "For internal service communication only and it will not be giving user friendly response",tags={"Cart feign client"})
@RequestMapping("/cart")
public interface CartServiceProxy {
	
	@ApiOperation(value = "Fetching active cart using username.", authorizations = {
		    @Authorization(value = "oauth2", scopes = {}),
		    @Authorization(value = "Bearer")},
			extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "User is allowed to get active cart from the cart service.")})},
			produces = "application/json", notes = "Only admin can be used as an internal usage for servive communication.")
			@ApiResponses(value={
			@ApiResponse(code = 200, message = "Successfully retrived the item details"),
			@ApiResponse(code = 204, message = "No data found or something went wrong")
			})
	
	@RequestMapping(value = "/active/{userName}", method = RequestMethod.GET)
	public Resource<CartResponse> getActiveCart(@PathVariable(name = "userName") String userName);

	
	@ApiOperation(value = "Dactivating the cart using username.", authorizations = {
		    @Authorization(value = "oauth2", scopes = {}),
		    @Authorization(value = "Bearer")},
			extensions = {@Extension(name = "roles", properties = {
			@ExtensionProperty(name = "customer", value = "User is allowed to get deactivate cart from the cart service.")})},
			produces = "application/json", notes = "Only admin can be used as an internal usage for servive communication.")
			@ApiResponses(value={
			@ApiResponse(code = 200, message = "Successfully retrived the item details"),
			@ApiResponse(code = 204, message = "No data found or something went wrong")
			})
	@RequestMapping(value = "/deactivate/{userName}", method = RequestMethod.DELETE)
	public Response deactivateCart(@PathVariable(name = "userName") String userName);
}
