package com.mindtree.order.response.entity;

import com.mindtree.order.entity.Order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Non informational respose to be shown for the request")
public class OrderResponse extends Response {
	@ApiModelProperty(notes = "Order details")
	private Order order;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public OrderResponse(int statusCode, String status, Order order) {
		super(statusCode, status);
		this.order = order;
	}

	public OrderResponse() {

	}

}
