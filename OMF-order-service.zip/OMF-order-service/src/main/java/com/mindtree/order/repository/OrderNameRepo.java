package com.mindtree.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.order.entity.Order;

@Repository
public interface OrderNameRepo extends JpaRepository<Order, String> {

	public List<Order> getOrderByuserName(String userName);

}
