package com.mindtree.order.exception;

public class DatabaseConnectivityException extends Exception{
	
	public DatabaseConnectivityException() {
		super();
	}

	public DatabaseConnectivityException(final String message) {
		super(message);
	}
}
