package com.mindtree.order.entity;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;

import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })

@Table(name = "omf_order")
@Entity
public class Order {
	@Id
	@Column(name = "orderId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(notes ="The order id of the order")
	private int orderId;

	@Column(name = "userName")
	private String userName;
	
	@JoinColumn
	@ElementCollection
	@MapKeyColumn(name = "productId")
	@ApiModelProperty(notes ="Mapping the product id with the product quantity")
	private Map<Integer, Integer> items = new HashMap<Integer, Integer>();
	
	@Column(name = "TotalPrice")
	private double totalPrice;
	
	@Column(name = "OrderDateTime")
	@UpdateTimestamp
	private LocalDateTime updateDateTime;
	
	@Column(name = "Address")
	private String address;
	
	public Map<Integer, Integer> getItems() {
		return items;
	}

	public void setItems(Map<Integer, Integer> items) {
		this.items = items;
	}

	public Order() {

	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
