package com.mindtree.order;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;

import com.mindtree.order.dao.impl.OrderDaoImpl;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.CartServiceProxy;
import com.mindtree.order.service.UserServiceProxy;
import com.mindtree.order.service.impl.OrderServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class OrderServiceMockito {
	
	@Mock
	OrderDaoImpl dao;
	
	@Mock
	private CartServiceProxy cartServiceProxy;

	@Mock
	private UserServiceProxy userServiceProxy;
	
	@InjectMocks
	@Spy
	OrderServiceImpl serImpl;
	
	@Test
	public void editAddressTest()
	{
		Order order=new Order();
		int orderId=102;
		String address="Andhra Pradesh";
		
		try {
			when(dao.editAddress(orderId, address)).thenReturn(order);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.editAddress(orderId, address));
		
	}
	
	@Test
	public void editAddressTest1()
	{
		Order order=new Order();
		int orderId=102;
		String address="Andhra Pradesh";
		
		try {
			when(dao.editAddress(orderId, address)).thenThrow(new DatabaseConnectivityException());
		} catch (DatabaseConnectivityException | ResourceNotFoundException e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.editAddress(orderId, address));
		
	}
	
	@Test
	public void editAddressTest2()
	{
		Order order=new Order();
		int orderId=102;
		String address="Andhra Pradesh";
		
		try {
			when(dao.editAddress(orderId, address)).thenThrow(new ResourceNotFoundException());
		} catch (DatabaseConnectivityException | ResourceNotFoundException e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.editAddress(orderId, address));
		
	}
	
	@Test
	public void deleteOrderTest()
	{
		OrderResponse response = new OrderResponse();
		response.setStatusCode(200);
		int orderId=201;
		try {
			when(dao.deleteOrder(orderId)).thenReturn(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.deleteOrder(orderId));
	}
	
	@Test
	public void deleteOrderTest1()
	{
		OrderResponse response = new OrderResponse();
		response.setStatusCode(200);
		int orderId=201;
		try {
			when(dao.deleteOrder(orderId)).thenThrow(new DatabaseConnectivityException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.deleteOrder(orderId));
	}
	
	@Test
	public void deleteOrderTest2()
	{
		OrderResponse response = new OrderResponse();
		response.setStatusCode(200);
		int orderId=201;
		try {
			when(dao.deleteOrder(orderId)).thenThrow(new ResourceNotFoundException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.deleteOrder(orderId));
	}
		
	@Test
	public void getOrderByuserNameTest()
	{
		OrderListResponse orderList=new OrderListResponse();
		orderList.setStatusCode(200);
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		
		try {
			when(dao.getOrderListByuserName("sush@gmail.com")).thenReturn(list);
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getOrderByuserName("sush@gmail.com"));
				
	}
	
	@Test
	public void getOrderByuserNameTest1()
	{
		OrderListResponse orderList=new OrderListResponse();
		orderList.setStatusCode(200);
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		
		try {
			when(dao.getOrderListByuserName("sush@gmail.com")).thenThrow(new DatabaseConnectivityException());
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getOrderByuserName("sush@gmail.com"));
				
	}
	
	@Test
	public void getOrderByuserNameTest2()
	{
		OrderListResponse orderList=new OrderListResponse();
		orderList.setStatusCode(200);
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		
		try {
			when(dao.getOrderListByuserName("sush@gmail.com")).thenThrow(new ResourceNotFoundException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getOrderByuserName("sush@gmail.com"));
				
	}
	

	/*@Test
	public void saveOrderDetailsTest()
	{
		OrderResponse orderResponse = new OrderResponse();
		Response respnose=new Response();
		CartResponse cartres=new CartResponse();
		cartres.setStatusCode(200);
		cartres.setStatus("message");
		Resource<CartResponse> resourceCart=new Resource<CartResponse>(cartres);
		respnose.setStatusCode(200);
		
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		
		Cart cart = new Cart();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sush7@gmail.com");
		cart.setItems(items);
		resourceCart.getContent().setCart(cart);
		
		cartres.setCart(cart);
		orderResponse.setStatusCode(204);
		
		
			try {
			when(serImpl.getUserInfo("sush7@gmail.com")).thenReturn("andhra");
			when(userServiceProxy.getUserAddress("sush7@gmail.com")).thenReturn("andhra");
			when(cartServiceProxy.getActiveCart(cart.getUserName())).thenReturn(resourceCart);
			when(serImpl.createOrderModel(cart, "andhra")).thenReturn(order);
			when(dao.saveOrderDetails(order)).thenReturn(order);
			when(cartServiceProxy.deactivateCart(cart.getUserName())).thenReturn(respnose);
			when(dao.deleteOrder(order.getOrderId())).thenThrow(new RuntimeException());
			} catch (Exception e) {
				e.printStackTrace();
			}
			assertNotNull(serImpl.saveOrderDetails(order.getUserName()));
	}*/	
	
	@Test
	public void getByIdTest()
	{
		OrderResponse orderResponse = new OrderResponse();
		orderResponse.setStatusCode(200);
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		Optional<Order> or = Optional.of(order);
		try {
			when(dao.getOrderById(123)).thenReturn(or);
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
		assertNotNull(serImpl.getOrderById(order.getOrderId()));
		
	}
	@Test
	public void getByIdTest1()
	{
		OrderResponse orderResponse = new OrderResponse();
		orderResponse.setStatusCode(200);
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		Optional<Order> or = Optional.of(order);
		try {
			when(dao.getOrderById(123)).thenThrow(new DatabaseConnectivityException());
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
		assertNotNull(serImpl.getOrderById(order.getOrderId()));
		
	}
	
	@Test
	public void getCartForCurrentUserTest()
	{
		CartResponse cartres=new CartResponse();
		cartres.setStatusCode(200);
		cartres.setStatus("message");
		Resource<CartResponse> resourceCart=new Resource<CartResponse>(cartres);
		when(cartServiceProxy.getActiveCart("sush7@gmail.com")).thenReturn(resourceCart);
		try {
			assertNotNull(serImpl.getCartForCurrentUser("sush7@gmail.com"));
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getCartForCurrentUserTest2()
	{
		CartResponse cartres=new CartResponse();
		cartres.setStatusCode(200);
		cartres.setStatus("message");
		Resource<CartResponse> resourceCart=new Resource<CartResponse>(cartres);
		Cart cart = new Cart();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sush7@gmail.com");
		resourceCart.getContent().setCart(cart);
		when(cartServiceProxy.getActiveCart("sush7@gmail.com")).thenReturn(resourceCart);
		try {
			assertNotNull(serImpl.getCartForCurrentUser("sush7@gmail.com"));
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
