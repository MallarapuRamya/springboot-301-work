package com.mindtree.order;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.entity.Cart;
//import com.mindtree.order.entity.Item;
import com.mindtree.order.entity.Order;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.impl.OrderServiceImpl;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTests extends TestCase {

	@Autowired
	private OrderServiceImpl orderServiceImpl;

	Order order;
	Order orderDetails;
	Order orderEntity;
	OrderResponse orderResponse;
	
/*	@Test
	public void createOrderTest()
	{
		orderResponse=orderServiceImpl.saveOrderDetails("sush");
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("There is no active cart found for user : sush Please add some items to the cart.", orderResponse.getStatus());
	}
*/	
/*	@Test
	public void createOrderTest1()
	{
		orderResponse=orderServiceImpl.saveOrderDetails("sushmitha");
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("There is no active cart found for user : sushmitha Please add some items to the cart.", orderResponse.getStatus());
	}
*/	
	/*@Test
	public void getOrderByIdTest()
	{
		orderResponse=orderServiceImpl.getOrderById(0);
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("No orders found for the given order ID :0", orderResponse.getStatus());
	}
	*/
	@Test
	public void getOrderByIdTest1()
	{
		orderResponse=orderServiceImpl.getOrderById(10000);
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("No orders found for the given order ID :10000", orderResponse.getStatus());
	}
	
	@Test
	public void getOrderListTest()
	{
		OrderListResponse orderList=orderServiceImpl.getOrderByuserName("sush");
		assertEquals(204, orderList.getStatusCode());
		assertEquals("No orders found for the user", orderList.getStatus());
	}
	
	@Test
	public void getOrderListTest1()
	{
		OrderListResponse orderList=orderServiceImpl.getOrderByuserName("sushmitha");
		assertEquals(204, orderList.getStatusCode());
		assertEquals("No orders found for the user", orderList.getStatus());
	}
	
	@Test
	public void editAddressTest()
	{
		orderResponse = orderServiceImpl.editAddress(0, "andhra");
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("Could not find any order for id : 0", orderResponse.getStatus());
	}
	
	@Test
	public void editAddressTest1()
	{
		orderResponse = orderServiceImpl.editAddress(10000, "andhra");
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("Could not find any order for id : 10000", orderResponse.getStatus());
	}
	
	@Test
	public void editAddressTest3()
	{
		orderResponse = orderServiceImpl.editAddress(30000, "andhra");
		assertEquals(204, orderResponse.getStatusCode());
		assertEquals("Could not find any order for id : 30000", orderResponse.getStatus());
	}
	
	@Test
	public void cancelOrdertest()
	{
		orderResponse=orderServiceImpl.deleteOrder(0);
		assertEquals(204,orderResponse.getStatusCode());
		assertEquals("No orders found for the given OrderId 0", orderResponse.getStatus());
	}
	
	@Test
	public void cancelOrdertest1()
	{
		orderResponse=orderServiceImpl.deleteOrder(10000);
		assertEquals(204,orderResponse.getStatusCode());
		assertEquals("No orders found for the given OrderId 10000", orderResponse.getStatus());
	}
	
	@Test
	public void cancelOrdertest2()
	{
		orderResponse=orderServiceImpl.deleteOrder(20000);
		assertEquals(204,orderResponse.getStatusCode());
		assertEquals("No orders found for the given OrderId 20000", orderResponse.getStatus());
	}
	
	@Test
	public void createcartModel()
	{
		Cart cart=new Cart();
		order=orderServiceImpl.createOrderModel(cart,"andhra");
		assertEquals(cart.getUserName(), order.getUserName());
	}

}
