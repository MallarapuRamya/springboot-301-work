package com.mindtree.order;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.dao.OrderDao;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DaoLayerTests extends TestCase {
	
	@Autowired
	private OrderDao orderdao;

	Order order;
	@Test
	public void saveOrderDetails()
	{
		Order order1 = null;
		try {
			order = orderdao.saveOrderDetails(order1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNull(order);
	}
	
	@Test
	public void getOrderByIdTest()
	{
		Optional<Order> order = null;
		try {
			order=orderdao.getOrderById(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertFalse(order.isPresent());
	}
	
	@Test
	public void getOrderListByuserNameTest()
	{
		List<Order> order = null;
		
		try {
			order=orderdao.getOrderListByuserName("sush");
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(order);
	}
	
	@Test
	public void editAddressTest()
	{
		Order isPresent = null;
		try {
			isPresent=orderdao.editAddress(0, "andhra");
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNull(isPresent);
		
	}
	
	@Test
	public void deleteOrderTest()
	{
		boolean isPresent = false;
		try {
			isPresent=orderdao.deleteOrder(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertFalse(isPresent);
		
	}
	
	@Test
	public void deleteOrderTest1()
	{
		boolean isPresent = false;
		try {
			isPresent=orderdao.deleteOrder(0);
		} catch (DatabaseConnectivityException | ResourceNotFoundException e) {
			e.printStackTrace();
		}
		assertFalse(isPresent);
	}
}