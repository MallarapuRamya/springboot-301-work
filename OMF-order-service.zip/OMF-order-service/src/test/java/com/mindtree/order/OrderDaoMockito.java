package com.mindtree.order;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.dao.impl.OrderDaoImpl;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.repository.OrderNameRepo;
import com.mindtree.order.repository.OrderRepository;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class OrderDaoMockito {
	
	@Mock
	OrderRepository repo;
	
	@Mock
	OrderNameRepo nameRepo;
	
	@InjectMocks
	@Spy
	OrderDaoImpl daoImpl;
	
	@Test
	public void saveOrderDetails()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		when(repo.save(order)).thenReturn(order);
		try {
			assertEquals(order, daoImpl.saveOrderDetails(order));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void editAddressTest()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		Optional<Order> orderOp=Optional.of(order);
		
		when(repo.findById(100)).thenReturn(orderOp);
		when(repo.save(order)).thenReturn(order);
		try {
			assertEquals(order, daoImpl.editAddress(100, "andhara"));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getOrderByIdTest()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		Optional<Order> orderOp=Optional.of(order);
		
		when(repo.findById(100)).thenReturn(orderOp);
		try {
			assertEquals(orderOp, daoImpl.getOrderById(100));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
	}
	@Test
	public void getOrderByIdTest1()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		Optional<Order> orderOp=Optional.of(order);
		
		when(repo.findById(100)).thenThrow(new RuntimeException());
		try {
			assertEquals(orderOp, daoImpl.getOrderById(100));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
	}
	
	
	
	@Test
	public void getOrderListByuserNameTest()
	{
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		when(nameRepo.getOrderByuserName("sush@gmail.com")).thenReturn(list);
		try {
			assertEquals(list, daoImpl.getOrderListByuserName("sush@gmail.com"));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void getOrderListByuserNameTest1()
	{
		List<Order> list = new ArrayList<>();
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		list.add(order);
		when(nameRepo.getOrderByuserName("sush@gmail.com")).thenThrow(new RuntimeException());
		try {
			assertEquals(list, daoImpl.getOrderListByuserName("sush@gmail.com"));
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void deleteOrderTest()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		Optional<Order> orderOp=Optional.of(order);
		
		when(repo.findById(100)).thenReturn(orderOp);
		try {
			assertEquals(true, daoImpl.deleteOrder(100));
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void deleteOrderTest1()
	{
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		Map<Integer, Integer> items = new HashMap<>();
		items.put(12, 12);
		order.setItems(items);
		
		Optional<Order> orderOp=Optional.of(order);
		
		when(repo.findById(100)).thenThrow(new RuntimeException());
		try {
			assertEquals(true, daoImpl.deleteOrder(100));
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
	}


}
