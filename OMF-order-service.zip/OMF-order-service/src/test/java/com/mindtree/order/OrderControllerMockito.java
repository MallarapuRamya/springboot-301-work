package com.mindtree.order;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;

import com.mindtree.order.controller.OrderController;
import com.mindtree.order.entity.Cart;
import com.mindtree.order.entity.Order;
import com.mindtree.order.exception.DatabaseConnectivityException;
import com.mindtree.order.exception.ResourceNotFoundException;
import com.mindtree.order.response.entity.CartResponse;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.response.entity.Response;
import com.mindtree.order.service.CartServiceProxy;
import com.mindtree.order.service.OrderServiceHateoas;
import com.mindtree.order.service.UserServiceProxy;
import com.mindtree.order.service.impl.OrderServiceImpl;

@RunWith(MockitoJUnitRunner.Silent.class)
@SpringBootTest
public class OrderControllerMockito {
	
	@Mock
	OrderServiceImpl serImpl;
	
	@Mock
	OrderServiceHateoas hateoas;
	
	@Mock
	private CartServiceProxy cartServiceProxy;

	@Mock
	private UserServiceProxy userServiceProxy;

	
	@InjectMocks
	@Spy
	OrderController controller;
	
	@Test
	public void createOrderTest()
	{
		OrderResponse ordeResponse=new OrderResponse();
		CartResponse cartres=new CartResponse();
		Resource<OrderResponse> resource=new Resource<OrderResponse>(ordeResponse);
		Resource<CartResponse> resourceCart=new Resource<CartResponse>(cartres);
		Cart cart = new Cart();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sush@gmail.com");
	//	Order order=new Order();
		
		resource.getContent().setStatusCode(200);
		resourceCart.getContent().setCart(cart);
		ordeResponse.setStatusCode(200);
		
		
		try {
			when(userServiceProxy.getUserAddress(cart.getUserName())).thenReturn("andhra");
			when(serImpl.getUserInfo(cart.getUserName())).thenReturn("andhara");
			when(cartServiceProxy.getActiveCart(cart.getUserName())).thenReturn(resourceCart);
			when(serImpl.getCartForCurrentUser(cart.getUserName())).thenReturn(cart);
			when(serImpl.saveOrderDetails(cart.getUserName())).thenReturn(ordeResponse);
			when(hateoas.placeOrder(ordeResponse)).thenReturn(resource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, controller.createOrder(cart.getUserName()).getContent().getStatusCode());
	}

	@Test
	public void getOrderByIdTest()
	{
		OrderResponse ordeResponse=new OrderResponse();
		ordeResponse.setStatusCode(200);
		Resource<OrderResponse> resource=new Resource<OrderResponse>(ordeResponse);
		resource.getContent().setStatusCode(200);
		
		when(serImpl.getOrderById(1)).thenReturn(ordeResponse);
		when(hateoas.viewOrderById(ordeResponse)).thenReturn(resource);
		assertEquals(200, controller.getOrderById(1).getContent().getStatusCode());
	}
	
	@Test
	public void getOrderByUserName()
	{
		OrderListResponse ordeResponse=new OrderListResponse();
		ordeResponse.setStatusCode(200);
		Resource<OrderListResponse> resource=new Resource<OrderListResponse>(ordeResponse);
		resource.getContent().setStatusCode(200);
		when(serImpl.getOrderByuserName("sush7@gmail.com")).thenReturn(ordeResponse);
		when(hateoas.getOrderByuserName(ordeResponse)).thenReturn(resource);
		
		assertEquals(200, controller.getOrderByuserName("sush7@gmail.com").getContent().getStatusCode());
		
	}
	
	@Test
	public void createOrderTest1()
	{
		OrderResponse ordeResponse=new OrderResponse();
		Resource<OrderResponse> resource=new Resource<OrderResponse>(ordeResponse);
		resource.getContent().setStatusCode(200);
		ordeResponse.setStatusCode(200);
		Cart cart = new Cart();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sush@gmail.com");
		try {
			when(serImpl.saveOrderDetails(cart.getUserName())).thenReturn(ordeResponse);
			when(hateoas.placeOrder(ordeResponse)).thenReturn(resource);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		assertEquals(200, controller.createOrder(cart.getUserName()).getContent().getStatusCode());
	}
	
	/*@Test
	public void createOrderTest2()
	{
		OrderResponse ordeResponse=new OrderResponse();
		Resource<OrderResponse> resource=new Resource<OrderResponse>(ordeResponse);
		resource.getContent().setStatusCode(200);
		ordeResponse.setStatusCode(204);
		Cart cart = new Cart();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sush@gmail.com");
		try {
			when(serImpl.saveOrderDetails(cart.getUserName())).thenReturn(ordeResponse);
			when(hateoas.placeOrder(ordeResponse)).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNull(controller.createOrder("sush@gmail.com"));
	}*/
	
	@Test
	public void placeOrderTest()
	{
		Cart cart=new Cart();
		Map<Integer, Integer> items = new HashMap<>();
		cart.setActive(true);
		cart.setCartId(2);
		cart.setTotalPrice(100);
		cart.setUserName("sushmita.kopalli@gmail.com");
		cart.setItems(items);
		
		Order order=new Order();
		order.setAddress("andhra");
		order.setOrderId(123);
		order.setTotalPrice(100);
		order.setUpdateDateTime(null);
		order.setUserName("sush7@gmail.com");
		items.put(12, 12);
		order.setItems(items);
		
		
		OrderResponse response=new OrderResponse();
		CartResponse cartResponse=new CartResponse();
		Response response1= new Response();
		response.setStatusCode(204);
		cartResponse.setStatusCode(204);
		Resource<CartResponse> resource = new Resource<CartResponse>(cartResponse);
		resource.getContent().setStatusCode(200);
		Resource<OrderResponse> resource1 = new Resource<OrderResponse>(response);
		resource1.getContent().setStatusCode(204);
				
		try {
			when(userServiceProxy.getUserAddress(cart.getUserName())).thenReturn("andhra");
			when(cartServiceProxy.getActiveCart(cart.getUserName())).thenReturn(resource);
			when(cartServiceProxy.deactivateCart(cart.getUserName())).thenReturn(response1);
			when(serImpl.getUserInfo(cart.getUserName())).thenReturn("andhra");
			try {
				when(serImpl.getCartForCurrentUser(cart.getUserName())).thenReturn(cart);
			} catch (ResourceNotFoundException e) {
				e.printStackTrace();}
			when(serImpl.createOrderModel(cart, "address")).thenReturn(order);
			when(serImpl.saveOrderDetails(cart.getUserName())).thenReturn(response);
			when(hateoas.placeOrder(response)).thenReturn(resource1);
		} catch (DatabaseConnectivityException e) {
			e.printStackTrace();
		}
		
		assertEquals(204, controller.createOrder(cart.getUserName()).getContent().getStatusCode());
	}
}
