package com.mindtree.order;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.entity.Order;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;
import com.mindtree.order.service.impl.OrderServiceHateoasImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HateOasMockito {

	@Autowired
	OrderServiceHateoasImpl orderServceHateOas;
	
	@Test
	public void placeOrder()
	{
		OrderResponse orderPlaceResponse=new OrderResponse();
		orderPlaceResponse.setStatusCode(200);
		Order order=new Order();
		orderPlaceResponse.setOrder(order);
		Resource<OrderResponse> resource = orderServceHateOas.placeOrder(orderPlaceResponse);
		assertEquals(200, resource.getContent().getStatusCode());
	}
	
	@Test
	public void viewOrderById()
	{
		OrderResponse orderPlaceResponse=new OrderResponse();
		orderPlaceResponse.setStatusCode(200);
		Order order=new Order();
		orderPlaceResponse.setOrder(order);
		Resource<OrderResponse> resource = orderServceHateOas.viewOrderById(orderPlaceResponse);
		assertEquals(200, resource.getContent().getStatusCode());
	}
	
	@Test
	public void cancelOrder()
	{
		OrderResponse orderPlaceResponse=new OrderResponse();
		orderPlaceResponse.setStatusCode(200);
		Order order=new Order();
		orderPlaceResponse.setOrder(order);
		Resource<OrderResponse> resource = orderServceHateOas.cancelOrder(orderPlaceResponse);
		assertEquals(200, resource.getContent().getStatusCode());
	}
	
	@Test
	public void getOrderByuserName()
	{
		OrderListResponse orderPlaceResponse=new OrderListResponse();
		orderPlaceResponse.setStatusCode(200);
		Resource<OrderListResponse> resource = orderServceHateOas.getOrderByuserName(orderPlaceResponse);
		assertEquals(200, resource.getContent().getStatusCode());
	}
	
	@Test
	public void updateOrder()
	{
		OrderResponse orderPlaceResponse=new OrderResponse();
		orderPlaceResponse.setStatusCode(200);
		Order order=new Order();
		orderPlaceResponse.setOrder(order);
		Resource<OrderResponse> resource = orderServceHateOas.updateOrder(orderPlaceResponse);
		assertEquals(200, resource.getContent().getStatusCode());
	}
}