package com.mindtree.order;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.order.controller.OrderController;
//import com.mindtree.order.entity.Item;
import com.mindtree.order.entity.Order;
import com.mindtree.order.response.entity.OrderListResponse;
import com.mindtree.order.response.entity.OrderResponse;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerLayerTests extends TestCase {

	@Autowired
	private OrderController orderController;

	Order order;
	Order orderDetails;
	Order orderEntity;
	OrderResponse orderResponse;

	/*@Test
	public void placeOdrerTest1()
	{
		Resource<OrderResponse> test = orderController.createOrder("qwertyuiop");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("There is no active cart found for user : qwertyuiop Please add some items to the cart.", test.getContent().getStatus());
	}
	*/
	/*@Test
	public void placeOdrerTest2()
	{
		Resource<OrderResponse> test = orderController.createOrder("sush");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("There is no active cart found for user : sush Please add some items to the cart.", test.getContent().getStatus());
	}
	*/
	/*@Test
	public void placeOdrerTest3()
	{
		Resource<OrderResponse> test = orderController.createOrder("suqwertyuiasdfghj");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("There is no active cart found for user : suqwertyuiasdfghj Please add some items to the cart.", test.getContent().getStatus());
	}
	*/
	@Test
	public void getOdrerById()
	{
		Resource<OrderResponse> test = orderController.getOrderById(0);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given order ID :0", test.getContent().getStatus());
	}
	
	@Test
	public void getOdrerByIdTest4()
	{
		Resource<OrderResponse> test = orderController.getOrderById(100000);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given order ID :100000", test.getContent().getStatus());
	}
	
	@Test
	public void getOdrerByIdTest()
	{
		Resource<OrderResponse> test = orderController.getOrderById(1);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given order ID :1", test.getContent().getStatus());
	}
	
	@Test
	public void getOdrerByIdTest6()
	{
		Resource<OrderResponse> test = orderController.getOrderById(100000);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given order ID :100000", test.getContent().getStatus());
	}
	
	@Test
	public void getOrderList()
	{
		Resource<OrderListResponse> test = orderController.getOrderByuserName("sush");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the user", test.getContent().getStatus());
	}
		
	@Test
	public void getOrderList1()
	{
		Resource<OrderListResponse> test = orderController.getOrderByuserName("123");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the user", test.getContent().getStatus());
	}
	
	@Test
	public void editAddressTest()
	{
		Resource<OrderResponse> test=orderController.editAddress(10000, "andhra");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("Could not find any order for id : 10000", test.getContent().getStatus());
		
	}
	
	@Test
	public void editAddressTest1()
	{
		Resource<OrderResponse> test=orderController.editAddress(10000, "andhra");
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("Could not find any order for id : 10000", test.getContent().getStatus());
		
	}
	
	@Test
	public void deleteOrderTest()
	{
		Resource<OrderResponse> test=orderController.deleteOrder(0);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given OrderId 0", test.getContent().getStatus());
	}
	
	@Test
	public void deleteOrderTest1()
	{
		Resource<OrderResponse> test=orderController.deleteOrder(10000);
		assertEquals(204, test.getContent().getStatusCode());
		assertEquals("No orders found for the given OrderId 10000", test.getContent().getStatus());
	}
	
}
