package com.mindtree.search.exception;

@SuppressWarnings("serial")
public class RestaurantNotFoundException extends Exception {

	public RestaurantNotFoundException(String message) {
		super(message);
	}
}
