package com.mindtree.search.controller;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.search.hateoas.service.SearchHateoasService;
import com.mindtree.search.response.entity.ItemListResponse;
import com.mindtree.search.response.entity.RestaurantListResponse;
import com.mindtree.search.service.SearchService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/restaurant")
@Api(value = "Search Service", description = "List of Services available for getting restaurants and item information.", tags = { "Search Service" })
public class SearchController {

	private Logger LOG = Logger.getLogger(SearchController.class);

	@Autowired
	private SearchService searchService;

	@Autowired
	private SearchHateoasService searchHateoasService;

	@ApiOperation(value = " All information of the restaurants (This is only used for internal service communication)")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetched the restaurants information"),
			@ApiResponse(code = 204, message = "No infomation found or something went wrong") })

	@RequestMapping(value = "/getAllRestaurants", method = RequestMethod.GET)
	public Resource<RestaurantListResponse> getAllRestaurants() {
		
		LOG.debug("====Get all restaurants====");
		RestaurantListResponse restaurantListResposne = searchService.getAllRestaurants();
		return searchHateoasService.getAllRestaurants(restaurantListResposne);
		
	}

	@ApiOperation(value = "Restaurant and its items information of specified restaurant name")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched the restaurant information using restuarant name"),
			@ApiResponse(code = 204, message = "No infomation found or something went wrong") })

	@RequestMapping(value = "/restaurantName/{restaurantName}", method = RequestMethod.GET)
	public Resource<RestaurantListResponse> findRestaurantByName(
			@PathVariable @Value(value = "restaurantName") String restaurantName) {
		
		LOG.debug("=======Get by Restaurant name=====");
		RestaurantListResponse restaurantListResponse = searchService.findRestaurantByName(restaurantName);
		return searchHateoasService.findRestaurantByName(restaurantListResponse);
		
	}

	@ApiOperation(value = "All restaurant and items information based on requested location")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched the restaurant information using location"),
			@ApiResponse(code = 204, message = "No infomation found or something went wrong") })

	@RequestMapping(value = "/location/{location}", method = RequestMethod.GET)
	public Resource<RestaurantListResponse> findRestaurantByLocation(
			@PathVariable @Value(value = "location") String location) {
		
		LOG.debug("=====Get by restaurant location=====");
		RestaurantListResponse restaurantListResponse = searchService.findRestaurantByLocation(location);
		return searchHateoasService.findRestaurantByLocation(restaurantListResponse);
		
	}

	@ApiOperation(value = "All restaurant and items information based on the requested item name")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched the restaurant information using item name"),
			@ApiResponse(code = 204, message = "No infomation found or something went wrong") })

	@RequestMapping(value = "/itemName/{itemName}", method = RequestMethod.GET)
	public Resource<RestaurantListResponse> findByItemName(@PathVariable(value = "itemName") String itemName) {
		
		LOG.debug("====Get by Item name====");
		RestaurantListResponse restaurantListResponse = searchService.getRestaurant(itemName);
		return searchHateoasService.getRestaurant(restaurantListResponse);

	}

	@ApiOperation(value = "Get item details by item id (This is only used for internal service communication)")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully fetched the restaurant information using item name"),
			@ApiResponse(code = 204, message = "No infomation found or something went wrong") })
	
	@RequestMapping(value = "/getItemByItemId", method = RequestMethod.POST)
	public ItemListResponse getByItemId(@RequestBody List<Integer> itemId) {
		
		return searchService.getItems(itemId);
		
	}
		
}