package com.mindtree.search.service.impl;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.mindtree.search.dao.SearchDao;
import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.exception.ItemNotFoundException;
import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.response.entity.ItemListResponse;
import com.mindtree.search.response.entity.RestaurantListResponse;
import com.mindtree.search.service.SearchService;

@Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	private SearchDao searchDao;

	@Value("${successcode}")
	private int successcode;

	@Value("${failedcode}")
	private int failedcode;

	private Logger LOG = Logger.getLogger(SearchServiceImpl.class);

	@Override
	public RestaurantListResponse getAllRestaurants() {

		RestaurantListResponse restaurantListResponse = new RestaurantListResponse();
		List<Restaurant> restaurantList;
		try {
			restaurantList = searchDao.getAllRestaurants();
			if (!CollectionUtils.isEmpty(restaurantList)) {

				restaurantListResponse.setStatusCode(successcode);
				restaurantListResponse.setStatus("All restaurants list");
				restaurantListResponse.setRestaurantList(restaurantList);

			}
		} catch (RestaurantNotFoundException e) {

			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse.setStatus("No restaurant found with the specified name");
			restaurantListResponse.setRestaurantList(null);

		} 
		catch (Exception e){
		restaurantListResponse.setStatusCode(failedcode);
		restaurantListResponse.setStatus("Something went wrong in the connection to database! Please try again later.");
		restaurantListResponse.setRestaurantList(null);

	}
		return restaurantListResponse;
	}

	public RestaurantListResponse findRestaurantByName(String restaurantName) {

		RestaurantListResponse restaurantListResponse = new RestaurantListResponse();
		List<Restaurant> restaurantList;

		try {

			restaurantList = searchDao.findRestaurantByName(restaurantName);
			if (!CollectionUtils.isEmpty(restaurantList)) {

				restaurantListResponse.setStatusCode(successcode);
				restaurantListResponse.setStatus("Restaurant found");
				restaurantListResponse.setRestaurantList(restaurantList);

			}
		} catch (RestaurantNotFoundException e) {

			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse.setStatus("No restaurant found");
			restaurantListResponse.setRestaurantList(null);

		} catch (Exception e) {
			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse
					.setStatus("Something went wrong in the connection to database! Please try again later.");
			restaurantListResponse.setRestaurantList(null);

		}
		return restaurantListResponse;
	}

	public RestaurantListResponse findRestaurantByLocation(String location) {

		RestaurantListResponse restaurantListResponse = new RestaurantListResponse();
		List<Restaurant> restaurantList;

		try {
			restaurantList = searchDao.findRestaurantByLocation(location);

			if (!CollectionUtils.isEmpty(restaurantList)) {

				restaurantListResponse.setStatusCode(successcode);
				restaurantListResponse.setStatus("Restaurant found");
				restaurantListResponse.setRestaurantList(restaurantList);

			}
		} catch (RestaurantNotFoundException e) {

			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse.setStatus("No restaurant available in this location");
			restaurantListResponse.setRestaurantList(null);
			e.printStackTrace();

		} catch (Exception e) {
			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse
					.setStatus("Something went wrong in the connection to database! Please try again later.");
			restaurantListResponse.setRestaurantList(null);
			e.printStackTrace();
		}
		return restaurantListResponse;
	}

	public RestaurantListResponse getRestaurant(String itemName) {

		List<Restaurant> restaurantList;
		RestaurantListResponse restaurantListResponse = new RestaurantListResponse();
		
		try {
			restaurantList = searchDao.getRestaurant(itemName);

			if (!CollectionUtils.isEmpty(restaurantList)) {

				restaurantListResponse.setStatusCode(successcode);
				restaurantListResponse.setStatus("Restaurant found");
				restaurantListResponse.setRestaurantList(restaurantList);

			}
		} catch (RestaurantNotFoundException e) {

			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse.setStatus("No restaurant available for this item name");
			restaurantListResponse.setRestaurantList(null);
			e.printStackTrace();

		} catch (Exception e) {
			restaurantListResponse.setStatusCode(failedcode);
			restaurantListResponse
					.setStatus("Something went wrong in the connection to database! Please try again later.");
			restaurantListResponse.setRestaurantList(null);
			e.printStackTrace();
		}
		return restaurantListResponse;
	}

	@Override
	public ItemListResponse getItems(List<Integer> itemIds) {
		ItemListResponse itemListResponse = new ItemListResponse();
		List<Items> itemList;;
		
		try {
			itemList = searchDao.getItemById(itemIds);
			if (!CollectionUtils.isEmpty(itemList)) {
				LOG.info("================itemslist"+itemList);
				System.out.println("In side if statement");
				itemListResponse.setStatusCode(successcode);
				itemListResponse.setStatus("Item found");
				itemListResponse.setItemList(itemList);
				
			}
			else
			{
				itemListResponse.setStatusCode(failedcode);
				itemListResponse.setStatus("No items available for itemId");
				itemListResponse.setItemList(null);
			}
		} catch (ItemNotFoundException e) {
			
			itemListResponse.setStatusCode(failedcode);
			itemListResponse.setStatus("No items available for itemId");
			itemListResponse.setItemList(null);
			e.printStackTrace();
			
		} catch (Exception e) {
			
			LOG.error(e.getMessage());
			e.printStackTrace();
			itemListResponse.setStatusCode(failedcode);
			itemListResponse.setStatus("Something went wrong in the connection to database! Please try again later.");
			itemListResponse.setItemList(null);

		}
		return itemListResponse;
	}
	
	
	public List<Restaurant> getAllRestaurantsFeign()
	{
	try {
		return searchDao.getAllRestaurants();
	} catch (Exception e) {
		e.printStackTrace();
		return null;
	}
	}

}
