package com.mindtree.search.repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.search.entity.Restaurant;

@Repository
public interface SearchRepository extends MongoRepository<Restaurant, String> {

	public List<Restaurant> findByRestaurantName(String restaurantName);

	public List<Restaurant> findRestaurantByLocation(String location);

	@Query("{'Items.itemName':?0}")
	public List<Restaurant> getRestaurant(String items);

	@Query(value="{'Items.itemId':?0}")
	public List<Restaurant> getItemById(int items);
}
