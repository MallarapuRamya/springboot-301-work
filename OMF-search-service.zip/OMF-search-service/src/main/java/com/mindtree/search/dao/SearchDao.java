package com.mindtree.search.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;

@Service
public interface SearchDao {

	public List<Restaurant> getAllRestaurants()throws Exception;

	public  List<Restaurant> findRestaurantByName(String restaurantName) throws Exception;

	public  List<Restaurant> getRestaurant(String itemName) throws Exception;

	public  List<Restaurant> findRestaurantByLocation(String location) throws Exception;
	
	public List<Items> getItemById(List<Integer> itemId) throws Exception;

	
}
