package com.mindtree.search.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.search.dao.SearchDao;
import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.repository.SearchRepository;

@Service
public class SearchDaoImpl implements SearchDao {

	@Autowired
	private SearchRepository searchRepository;

	private Logger LOG = Logger.getLogger(SearchDaoImpl.class);

	public List<Restaurant> getAllRestaurants() throws RestaurantNotFoundException {

		List<Restaurant> restaurantList = searchRepository.findAll();
		if (restaurantList.isEmpty()) {
			throw new RestaurantNotFoundException("No Restaurant Available ");
		}
		return restaurantList;
	}

	public List<Restaurant> findRestaurantByName(String restaurantName) throws RestaurantNotFoundException {

		List<Restaurant> restaurantList = searchRepository.findByRestaurantName(restaurantName);
		if (restaurantList.isEmpty()) {
			throw new RestaurantNotFoundException("No Restaurant Available ");
		}
		return restaurantList;
	}

	public List<Restaurant> findRestaurantByLocation(String location) throws RestaurantNotFoundException {

		List<Restaurant> restaurantList = searchRepository.findRestaurantByLocation(location);
		if (restaurantList.isEmpty()) {
			throw new RestaurantNotFoundException("No Restaurant Available In This Location ");
		}
		return restaurantList;
	}

	public List<Restaurant> getRestaurant(String itemName) throws RestaurantNotFoundException {

		List<Restaurant> restaurantList = searchRepository.getRestaurant(itemName);
		if (restaurantList.isEmpty()) {
			throw new RestaurantNotFoundException("No Restaurant Available For This Item Name ");
		}
		return restaurantList;
	}

	@Override
	public List<Items> getItemById(List<Integer> itemIds) throws Exception {

		List<Items> itemList = new ArrayList<Items>();
		int itemIdentifier = 0;
		for (int itemId : itemIds) {
			try {
				itemIdentifier = itemId;
				LOG.info("Itemid --------->" + itemId);
				List itemsList = searchRepository.getItemById(itemId).get(0).getItems().stream()
						.filter(id -> id.getItemId() == itemId).collect(Collectors.toList());
				Items item = (Items) itemsList.get(0);
				itemList.add(item);
			} catch (IndexOutOfBoundsException e) {
				LOG.error("Item not found for id :" + itemIdentifier);
			}
		}
		return itemList;
	}

}
