package com.mindtree.search.exception;

@SuppressWarnings("serial")
public class RestaurantServiceException extends Exception {

	public RestaurantServiceException(String message) {
		super(message);

	}
}
