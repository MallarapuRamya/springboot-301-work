package com.mindtree.search.entity;

import java.util.List;
import javax.persistence.Entity;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Document(collection = "Restaurant")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@ApiModel(description = "Information of the restaurants and items")
public class Restaurant extends ResourceSupport {

	@ApiModelProperty(notes = "The restaurantId for the  service")
	private int restaurantId;

	@ApiModelProperty(notes = "Restaurant name")
	private String restaurantName;

	@ApiModelProperty(notes = "Location of the restaurant")
	private String location;

	@ApiModelProperty(notes = "List of items")
	private List<Items> items;

	public int getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}
}