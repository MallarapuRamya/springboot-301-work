package com.mindtree.search.hateoas.service;

import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;
import com.mindtree.search.response.entity.RestaurantListResponse;

@Service
public interface SearchHateoasService   {

	public Resource<RestaurantListResponse> getAllRestaurants(RestaurantListResponse allData);
	
	public Resource<RestaurantListResponse> findRestaurantByName(RestaurantListResponse restaurantList);

	public Resource<RestaurantListResponse> findRestaurantByLocation(RestaurantListResponse locationList);

	public Resource<RestaurantListResponse> getRestaurant(RestaurantListResponse  itemName);
}
