package com.mindtree.search.hateoas.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.hateoas.service.SearchHateoasService;
import com.mindtree.search.response.entity.RestaurantListResponse;

@Service
@PropertySource("classpath:application.properties")
public class SearchServiceHateoas implements SearchHateoasService {

	@Value("${endpoint}")
	private String endpoint;

	public Resource<RestaurantListResponse> getAllRestaurants(RestaurantListResponse allData) {

		Resource<RestaurantListResponse> resource = new Resource<RestaurantListResponse>(allData);

		try {
			for (Restaurant restaurant : allData.getRestaurantList()) {

				Link selflink = new Link(endpoint + "restaurant/restaurantName/"
						+ restaurant.getRestaurantName().replaceAll(" ", "%20"));
				resource.add(selflink);

				Link selfLink1 = new Link(
						endpoint + "restaurant/location/" + restaurant.getLocation().replaceAll(" ", "%20"));
				resource.add(selfLink1);

				for (Items item : restaurant.getItems()) {

					Link selflink1 = new Link(
							endpoint + "restaurant/" + restaurant.getRestaurantName().replaceAll(" ", "%20") + "/"
									+ item.getItemName().replaceAll(" ", "%20"));
					resource.add(selflink1);
				}
			}
		} catch (Exception e) {
		}
		return resource;
	}

	public Resource<RestaurantListResponse> findRestaurantByName(RestaurantListResponse restaurantList) {

		Resource<RestaurantListResponse> resource = new Resource<RestaurantListResponse>(restaurantList);

		try {
			for (Restaurant restaurant : restaurantList.getRestaurantList()) {

				for (Items item : restaurant.getItems()) {
					Link selfLink2 = new Link(
							endpoint + "restaurant/itemName/" + item.getItemName().replaceAll(" ", "%20"));
					resource.add(selfLink2);
				}
			}
		} catch (Exception e) {

		}
		return resource;
	}

	@Override
	public Resource<RestaurantListResponse> findRestaurantByLocation(RestaurantListResponse locationlist) {

		Resource<RestaurantListResponse> resource = new Resource<RestaurantListResponse>(locationlist);

		try {
			for (Restaurant restaurant : locationlist.getRestaurantList()) {

				Link selflink = new Link(endpoint + "restaurant/restaurantName/"
						+ restaurant.getRestaurantName().replaceAll(" ", "%20"));
				resource.add(selflink);
			}
		} catch (Exception e) {

		}
		return resource;
	}

	@Override
	public Resource<RestaurantListResponse> getRestaurant(RestaurantListResponse itemName) {

		Resource<RestaurantListResponse> resource = new Resource<RestaurantListResponse>(itemName);

		try {
			for (Restaurant restaurant : itemName.getRestaurantList()) {

				for (Items item : restaurant.getItems()) {

					Link selflink1 = new Link(
							endpoint + "restaurant/" + restaurant.getRestaurantName().replaceAll(" ", "%20") + "/"
									+ item.getItemName().replaceAll(" ", "%20"));
					resource.add(selflink1);
				}
			}
		} catch (Exception e) {

		}
		return resource;
	}
}
