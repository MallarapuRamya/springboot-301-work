package com.mindtree.search.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.search.response.entity.ItemListResponse;
import com.mindtree.search.response.entity.RestaurantListResponse;

@Service
public interface SearchService {

	public RestaurantListResponse getAllRestaurants();

	public RestaurantListResponse findRestaurantByName(String restaurantName);

	public RestaurantListResponse findRestaurantByLocation(String location);

	public RestaurantListResponse getRestaurant(String itemName);

	public ItemListResponse getItems(List<Integer> itemIds);

}
