package com.mindtree.search.response.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Non informational respose to be shown for the request")
public class Response {

	@ApiModelProperty(notes = "Status code for the operation")
	private int statusCode;

	@ApiModelProperty(notes = "Status message for the operation")
	private String status;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
