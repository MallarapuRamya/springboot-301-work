package com.mindtree.search.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.search.entity.Items;

@Repository
public interface ItemRepository extends MongoRepository<Items, Integer> {
	
	@Query("{'items.itemId':?0}")
	public Items getItemById(Integer items);
	
}
