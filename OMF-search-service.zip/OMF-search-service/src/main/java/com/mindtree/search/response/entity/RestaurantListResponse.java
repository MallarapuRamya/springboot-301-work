package com.mindtree.search.response.entity;

import java.util.List;
import com.mindtree.search.entity.Restaurant;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Informational(List) respose to be shown for the request")
public class RestaurantListResponse extends Response {

	@ApiModelProperty(notes = "List of restaurants details")
	private List<Restaurant> restaurantList;

	public List<Restaurant> getRestaurantList() {
		return restaurantList;
	}

	public void setRestaurantList(List<Restaurant> restaurantList) {
		this.restaurantList = restaurantList;
	}
}
