package com.mindtree.search.response.entity;

import com.mindtree.search.entity.Restaurant;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Informational respose to be shown for the request")
public class RestaurantResponse extends Response {

	@ApiModelProperty(notes = "Restaurant details")
	private Restaurant restaurant;

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

}
