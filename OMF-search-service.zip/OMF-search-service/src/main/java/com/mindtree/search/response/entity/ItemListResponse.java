package com.mindtree.search.response.entity;

import java.util.List;

import com.mindtree.search.entity.Items;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Informational(List) respose to be shown for the request")
public class ItemListResponse extends Response {

	@ApiModelProperty(notes = "List of items details")
	private List<Items> itemList;

	public List<Items> getItemList() {
		return itemList;
	}

	public void setItemList(List<Items> itemList) {
		this.itemList = itemList;
	}

}
