package com.mindtree.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.controller.SearchController;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.response.entity.ItemListResponse;
import com.mindtree.search.response.entity.RestaurantListResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerLayerTest {
	@Autowired
	SearchController searchController;

	
	
	@Test
	public void RestaurantNameTest() {
		Resource<RestaurantListResponse> restaurantListResponse = searchController.findRestaurantByName("zzzzzzz");
		assertEquals(restaurantListResponse.getContent().getStatusCode(),204);
	}
	
	@Test
	public void RestaurantNameByLocationTest() {
		Resource<RestaurantListResponse> restaurantListResponse = searchController.findRestaurantByLocation("kota");
		assertEquals(restaurantListResponse.getContent().getStatusCode(),204);	
	}
	
	@Test
	public void RestaurantNameByItemNameTest()  {
		Resource<RestaurantListResponse> restaurantListResponse = searchController.findByItemName("fish masala");
		assertEquals(restaurantListResponse.getContent().getStatusCode(),204);
	}

	@Test
	public void getByitemId()
	{
		List<Integer> items=new ArrayList<>();
		items.add(0);
		ItemListResponse itemListResonse=searchController.getByItemId(items);
		assertEquals(204, itemListResonse.getStatusCode());
	}
	

}