package com.mindtree.search;

import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;
import com.mindtree.search.dao.impl.SearchDaoImpl;
import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.response.entity.RestaurantListResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
@SuppressWarnings("unused")
public class DaoLayerTest {

	@Autowired
	SearchDaoImpl searchDaoImpl;

	@Test(expected = RestaurantNotFoundException.class)
	public void findRestaurantByRestaurantNameTest() throws Exception  {
		List<Restaurant> restaurants = new ArrayList<>();
		List<Restaurant> restaurantList =  searchDaoImpl.findRestaurantByName("zzzzzzz");
		assertFalse(!restaurantList.isEmpty());

	}
	
	@Test(expected = RestaurantNotFoundException.class)
	public void findRestaurantByLocationTest() throws Exception {
		List<Restaurant> restaurants = new ArrayList<>();
		List<Restaurant> restaurantList = searchDaoImpl.findRestaurantByLocation("kota");
		assertFalse(!restaurantList.isEmpty());

	}
	
	@Test
	public void getItemByIdTest() throws Exception
	{
		List<Integer> itemIds  = new ArrayList<Integer>();
		List<Items> items=searchDaoImpl.getItemById(itemIds);
		assertTrue(items.isEmpty());
		
	}
	
}
