package com.mindtree.search;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.entity.Items;
import com.mindtree.search.entity.Restaurant;
import com.mindtree.search.hateoas.service.SearchHateoasService;
import com.mindtree.search.response.entity.RestaurantListResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HateOasTest {

	@Autowired
	SearchHateoasService hateoas;
	
	@Test
	public void getAllRestaurantsTest()
	{
		RestaurantListResponse list=new RestaurantListResponse();
		List<Restaurant> listRes=new ArrayList<Restaurant>();
		Restaurant restaurant = new Restaurant();
		restaurant.setLocation("andhra");
		restaurant.setRestaurantId(010);
		restaurant.setRestaurantName("123");
		List<Items> items=new ArrayList<Items>();
		Items item=new Items();
		item.setItemId(100);
		item.setItemName("234");
		item.setItemPrice(100);
		items.add(item);
		restaurant.setItems(items);
		listRes.add(restaurant);
		list.setRestaurantList(listRes);
		
		Resource<RestaurantListResponse> resource = hateoas.getAllRestaurants(list);
		assertNotNull(hateoas.getAllRestaurants(list));	
		}
	
	@Test
	public void findRestaurantByNameTest()
	{
		RestaurantListResponse list=new RestaurantListResponse();
		List<Restaurant> listRes=new ArrayList<Restaurant>();
		Restaurant restaurant = new Restaurant();
		restaurant.setLocation("andhra");
		restaurant.setRestaurantId(010);
		restaurant.setRestaurantName("123");
		List<Items> items=new ArrayList<Items>();
		Items item=new Items();
		item.setItemId(100);
		item.setItemName("234");
		item.setItemPrice(100);
		items.add(item);
		restaurant.setItems(items);
		listRes.add(restaurant);
		list.setRestaurantList(listRes);
		
		assertNotNull(hateoas.findRestaurantByName(list));
	}
	
	@Test
	public void findRestaurantByLocationTest()
	{
		RestaurantListResponse list=new RestaurantListResponse();
		List<Restaurant> listRes=new ArrayList<Restaurant>();
		Restaurant restaurant = new Restaurant();
		restaurant.setLocation("andhra");
		restaurant.setRestaurantId(010);
		restaurant.setRestaurantName("123");
		List<Items> items=new ArrayList<Items>();
		Items item=new Items();
		item.setItemId(100);
		item.setItemName("234");
		item.setItemPrice(100);
		items.add(item);
		restaurant.setItems(items);
		listRes.add(restaurant);
		list.setRestaurantList(listRes);
		
		assertNotNull(hateoas.findRestaurantByLocation(list));
	}
	
	@Test
	public void getRestaurantTest()
	{
		RestaurantListResponse list=new RestaurantListResponse();
		List<Restaurant> listRes=new ArrayList<Restaurant>();
		Restaurant restaurant = new Restaurant();
		restaurant.setLocation("andhra");
		restaurant.setRestaurantId(010);
		restaurant.setRestaurantName("123");
		List<Items> items=new ArrayList<Items>();
		Items item=new Items();
		item.setItemId(100);
		item.setItemName("234");
		item.setItemPrice(100);
		items.add(item);
		restaurant.setItems(items);
		listRes.add(restaurant);
		list.setRestaurantList(listRes);
		
		assertNotNull(hateoas.getRestaurant(list));
	}
}
