package com.mindtree.search;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.search.dao.SearchDao;
import com.mindtree.search.entity.Items;
import com.mindtree.search.exception.ItemNotFoundException;
import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.service.impl.SearchServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceMockitoTest {
	
	@Mock
	SearchDao dao;
	
	@InjectMocks
	@Spy
	SearchServiceImpl serImpl;
	
	@Test
	public void getAllRestaurantsTest()
	{
		try {
			when(dao.getAllRestaurants()).thenThrow(new RestaurantNotFoundException("Restaurant List not found."));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getAllRestaurants());
	}
	
	@Test
	public void getAllRestaurantsTest1()
	{
		try {
			when(dao.getAllRestaurants()).thenThrow(new Exception());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getAllRestaurants());
	}
	
	@Test
	public void findRestaurantByNameTest()
	{
		try {
			when(dao.getRestaurant("9876543")).thenThrow(new RestaurantNotFoundException("Restaurant not found."));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getRestaurant("9876543"));
	}
	
	@Test
	public void findRestaurantByNameTest1()
	{
		try {
			when(dao.getRestaurant("9876543")).thenThrow(new RuntimeException());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getRestaurant("9876543"));
	}
	
	@Test
	public void getItemsTest()
	{
		List<Integer> itemId = new ArrayList<>();
		itemId.add(100);
		List<Items> item=new ArrayList<>();
		try {
			when(dao.getItemById(itemId)).thenThrow(new ItemNotFoundException("Item not found."));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getItems(itemId));
	}
	
	@Test
	public void getItemsTest1()
	{
		List<Integer> itemId = new ArrayList<>();
		itemId.add(100);
		List<Items> item=new ArrayList<>();
		try {
			when(dao.getItemById(itemId)).thenThrow(new Exception());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.getItems(itemId));
	}
	
	@Test
	public void findRestaurantByLocationTest()
	{
		try {
			when(dao.findRestaurantByLocation("andhra")).thenThrow(new Exception());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.findRestaurantByLocation("andhra"));
	}
	
	@Test
	public void findRestaurantByNameTest2()
	{
		try {
			when(dao.getRestaurant("9876543")).thenThrow(new Exception());
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertNotNull(serImpl.findRestaurantByName("9876543"));
	}
	
	
}
