package com.mindtree.search;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.Resource;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.mindtree.search.exception.RestaurantNotFoundException;
import com.mindtree.search.response.entity.RestaurantListResponse;
import com.mindtree.search.service.impl.SearchServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServiceLayerTest {

	@Autowired
	SearchServiceImpl searchServiceImpl;


	@Test
	public void getAllRestaurants()
	{
		RestaurantListResponse restaurants = searchServiceImpl.getAllRestaurants();
		assertNotNull(restaurants);
	}

	@Test
	public void SearchRestaurantNameTest2() throws RestaurantNotFoundException {
		RestaurantListResponse restaurantList = new RestaurantListResponse();
		RestaurantListResponse restaurants = searchServiceImpl.findRestaurantByName("mangorestaunat");
		assertEquals(restaurantList.getRestaurantList(), restaurants.getRestaurantList());
		assertEquals(204, restaurants.getStatusCode());

	}

	@Test
	public void SearchRestaurantNameByLocationTest2() throws RestaurantNotFoundException {
		RestaurantListResponse restaurantList = new RestaurantListResponse();
		RestaurantListResponse restaurants = searchServiceImpl.findRestaurantByLocation("kota");
		assertEquals(restaurantList.getRestaurantList(), restaurants.getRestaurantList());
		assertEquals(204, restaurants.getStatusCode());

	}

	@Test
	public void SearchRestaurantNameByItemNameTest2() throws RestaurantNotFoundException {
		RestaurantListResponse restaurantList = new RestaurantListResponse();
		RestaurantListResponse restaurants = searchServiceImpl.findRestaurantByLocation("fish masala");
		assertEquals(restaurantList.getRestaurantList(), restaurants.getRestaurantList());
		assertEquals(204, restaurants.getStatusCode());

	}
	

}
