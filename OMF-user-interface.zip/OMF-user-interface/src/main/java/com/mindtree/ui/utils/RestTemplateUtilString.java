package com.mindtree.ui.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.client.RestTemplate;

import com.mindtree.ui.exception.InvalidCredentialsException;

@Service
@PropertySource("classpath:application.properties")
public class RestTemplateUtilString {

	private RestTemplate restTemplate = new RestTemplate();

	private final Log logger = LogFactory.getLog(this.getClass());

	ResponseEntity<String> exchange;

	public ResponseEntity<String> restTemplateConfigure(HttpHeaders headers, String url, HttpMethod method,
			MultiValueMap<String, String> body)
			throws InvalidCredentialsException, InternalServerError, NullPointerException {
		logger.info("url parsing is--------->" + url);
		try {
			HttpEntity<?> httpEntity = new HttpEntity<Object>(body, headers);
			logger.info("HttpEntity---------->" + httpEntity);
			exchange = restTemplate.exchange(url, method, httpEntity, String.class);
		} catch (HttpClientErrorException e) {
			throw new InvalidCredentialsException("Invalid Credentials");
		}
		logger.info("Exchange ----------->" + exchange);
		return exchange;
	}

}
