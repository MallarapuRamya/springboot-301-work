package com.mindtree.ui.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.ui.exception.InvalidCredentialsException;
import com.mindtree.ui.model.Restaurant;
import com.mindtree.ui.model.User;
import com.mindtree.ui.response.entity.RestaurantListResponse;
import com.mindtree.ui.service.UserInterfaceService;
import com.mindtree.ui.utils.RestTemplateUtilMap;
import com.mindtree.ui.utils.RestTemplateUtilSearch;
import com.mindtree.ui.utils.RestTemplateUtilString;
import com.mindtree.ui.utils.RestTemplateUtilUser;

@Service
@PropertySource("classpath:application.properties")
public class UserInterfaceServiceImpl implements UserInterfaceService {

	private HttpHeaders headers = new HttpHeaders();

	private final Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private RestTemplateUtilString restTemplateUtil;

	@Autowired
	private RestTemplateUtilUser restTemplateUtilUser;

	@Autowired
	private RestTemplateUtilMap restTemplateUtilMap;

	@Autowired
	private RestTemplateUtilSearch restTemplateUtilSearch;

	@Value("${url.baseUrl}")
	private String baseUrl;

	@Value("${url.authorizationService.port}")
	private String authorizationServicePort;

	@Value("${url.userservice.port}")
	private String userServicePort;

	@Value("${url.token}")
	private String generateTokenUrl;

	@Value("${url.newuser}")
	private String newUserUrl;

	@Value("${url.getusername}")
	private String getUsernameUrl;

	@Value("${url.deactiveUser}")
	private String deactivateUser;

	@Value("${url.getuserprofile}")
	private String getUserprofileUrl;

	@Value("${url.updateProfile}")
	private String updateProfileUrl;

	@Value("${url.searchService.port}")
	private String searchServicePort;

	@Value("${url.getAllRestaurant}")
	private String getAllRestaurantsUrl;

	@Value("${url.getRestaurantName}")
	private String getByRestaurantNameUrl;

	@Value("${url.restaurantLocation}")
	private String getByRestaurantLocationUrl;

	@Value("${url.restaurantItem}")
	private String getByRestaurantItemUrl;

	@Override
	public ModelAndView personalLoginUser(String username, String password) {

		headers.set("Content-Type", "application/x-www-form-urlencoded");
		headers.set("authorization", "Basic YXV0aG9yaXphdGlvbkNsaWVudDpwYXNzd29yZA==");

		StringBuffer url = new StringBuffer(baseUrl);
		url.append(authorizationServicePort);
		url.append(generateTokenUrl);
		HttpMethod method = HttpMethod.POST;

		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
		body.add("username", username);
		body.add("password", password);
		body.add("scope", "read");
		body.add("client_id", "authorizationClient");
		body.add("grant_type", "password");

		ResponseEntity<Map> responseEntity;
		ModelAndView model = new ModelAndView();

		try {
			responseEntity = restTemplateUtilMap.restTemplateConfigure(headers, url.toString(), method, body);

			if (responseEntity.getStatusCode().is2xxSuccessful()
					&& (!(responseEntity.getBody().get("access_token").toString().isEmpty()))) {
				model = getAllRestaurants();
				model.addObject("oauth_token", responseEntity.getBody().get("access_token").toString());
				model.setViewName("/home");
				model.addObject("username", getUsername(responseEntity.getBody().get("access_token").toString()));
				return model;
			}

		} catch (InvalidCredentialsException | NullPointerException e) {
			e.printStackTrace();
			model.setViewName("/login");
			model.addObject("badcredentials", "Please give valid credentials");
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			model.setViewName("/login");
			model.addObject("badcredentials", "Login Failed..Try again");
			return model;
		}

		model.setViewName("/login");
		model.addObject("badcredentials", "Something went wrong ..try again");
		return model;

	}

	@Override
	public ModelAndView registerUser(User user) {
		logger.info(user.getUserName() + " " + user.getNumber() + " " + user.getPassword() + " " + user.getAddress());
		headers.set("Content-Type", "application/json");

		StringBuffer url = new StringBuffer(baseUrl);
		url.append(userServicePort);
		url.append(newUserUrl);

		Map<String, String> body = new HashMap<String, String>();
		body.put("name", user.getName());
		body.put("userName", user.getUserName());
		body.put("password", user.getPassword());
		body.put("address", user.getAddress());
		body.put("number", user.getNumber());

		HttpMethod method = HttpMethod.POST;

		logger.info("Register user user url------>" + url);

		ModelAndView model = new ModelAndView();
		model.setViewName("/index");

		try {
			ResponseEntity<Map> responseEntity = restTemplateUtilUser.restTemplateConfigure(headers, url.toString(),
					method, body);

			if (responseEntity.getStatusCode().is2xxSuccessful()) {

				if (responseEntity.getBody().get("status").equals("User with username already exsits")) {
					model.addObject("failureMessage", "User is already exists! try to Sign in");
					return model;
				} else if (responseEntity.getBody().get("status").equals(204)
						&& (!responseEntity.getBody().get("status").equals("User with username already exsits"))) {
					model.addObject("failureMessage", "Something went wrong..Try Again");
					return model;
				}
			}

		} catch (NullPointerException | InvalidCredentialsException e) {
			e.printStackTrace();
			model.addObject("failureMessage", "Registration Failed..Try Again");
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			model.addObject("failureMessage", "Something went wrong..Try Again");
			return model;
		}

		model.addObject("successMessage", "Registration Successfully");
		return model;
	}

	@Override
	public ModelAndView socialLoginUser(String token) {

		ModelAndView model = new ModelAndView();

		if (token.isEmpty() || token.equals(null)) {
			return new ModelAndView("/login");
		}
		model = getAllRestaurants();
		return model;

	}

	@Override
	public ModelAndView deactivateUser(String token) {

		headers.set("Content-Type", "application/x-www-form-urlencoded");
		headers.set("authorization", "Basic YXV0aG9yaXphdGlvbkNsaWVudDpwYXNzd29yZA==");

		String username = getUsername(token);
		logger.info("username is-------------> " + username);
		if (username.isEmpty()) {
			return new ModelAndView("/login");
		} else {
			StringBuffer url = new StringBuffer(baseUrl);
			url.append(userServicePort);
			url.append(deactivateUser);
			url.append(username);
			url.append("?access_token=" + token);

			logger.info("Deactive user url------>" + url);

			HttpMethod method = HttpMethod.PUT;
			MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();

			ResponseEntity<Map> responseEntity;
			ModelAndView model = new ModelAndView();
			try {
				responseEntity = restTemplateUtilMap.restTemplateConfigure(headers, url.toString(), method, body);
				logger.info("Deactive user response en------------------>" + responseEntity);

				if (responseEntity.getStatusCode().is2xxSuccessful()) {
					model.addObject("deactiveMessage", "Account deactivated");
					model.setViewName("/login");
					return model;
				}

			} catch (InvalidCredentialsException | NullPointerException e) {
				e.printStackTrace();
				model.setViewName("/login");
				model.addObject("deactiveMessage", "Something went wrong..Try again");
				return model;
			} catch (Exception e) {
				model.setViewName("/login");
				model.addObject("badcredentials", "Process failed..Try again");
			}

			return model;

		}

	}

	@Override
	public ModelAndView userProfile(String token) {
		logger.info("inside service impl token value is---->" + token);

		headers.set("Content-Type", "application/json");

		String username = getUsername(token);

		StringBuffer url = new StringBuffer(baseUrl);
		url.append(userServicePort);
		url.append(getUserprofileUrl);
		url.append(username);
		url.append("?access_token=" + token);

		HttpMethod method = HttpMethod.GET;
		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();

		ResponseEntity<Map> responseEntity;
		ModelAndView model = new ModelAndView();

		try {
			responseEntity = restTemplateUtilMap.restTemplateConfigure(headers, url.toString(), method, body);
			logger.info("Repsonse entity for userProfile---->" + responseEntity);
			ObjectMapper mapper = new ObjectMapper();
			User user = mapper.convertValue(responseEntity.getBody().get("user"), User.class);

			if (responseEntity.getStatusCode().is2xxSuccessful()) {

				model.setViewName("/profile");
				model.addObject("username", user.getUserName());
				model.addObject("name", user.getName());
				model.addObject("number", user.getNumber());
				model.addObject("address", user.getAddress());
				model.addObject("password", null);
				return model;
			}

		} catch (InvalidCredentialsException | NullPointerException e) {
			model.setViewName("/error");
			return model;
		}

		return model;
	}

	@Override
	public ModelAndView updateProfile(String token, User user) {
		ModelAndView model = new ModelAndView();
		model.setViewName("/login");
		if (token.isEmpty()) {

			model.addObject("session", "Session expired..Try login again");
			return model;
		} else {
			headers.set("Content-Type", "application/json");

			String username = getUsername(token);
			user.setUserName(username);
			StringBuffer url = new StringBuffer(baseUrl);
			url.append(userServicePort);
			url.append(updateProfileUrl);
			url.append(username);
			url.append("?access_token=" + token);

			logger.info("Update profile url is-------->" + url);
			Map<String, String> body = new HashMap<String, String>();
			body.put("username", user.getUserName());
			body.put("password", user.getPassword());
			body.put("number", user.getNumber());
			body.put("address", user.getAddress());
			body.put("name", user.getName());

			HttpMethod method = HttpMethod.PUT;

			ResponseEntity<Map> responseEntity;
			try {
				responseEntity = restTemplateUtilUser.restTemplateConfigure(headers, url.toString(), method, body);
				if (responseEntity.getStatusCode().is2xxSuccessful()) {
					model.setViewName("/profile");
					model.addObject("username", user.getUserName());
					model.addObject("password", user.getPassword());
					model.addObject("number", user.getNumber());
					model.addObject("address", user.getAddress());
					model.addObject("name", user.getName());
					model.addObject("updatedMessage", "Profile successfully updated");
					return model;
				}
			} catch (NullPointerException | InvalidCredentialsException | InternalServerError e) {
				e.printStackTrace();
				model.setViewName("/profile");
				model.addObject("updatedMessage", "profile is not updated..try again");
				return model;
			}

			logger.info("response entity for update profile is------->" + responseEntity);

		}

		model.setViewName("/login");
		model.addObject("badMessage", "Something went wrong..try again");
		return model;

	}

	public String getUsername(String token) {
		headers.set("Content-Type", "application/json");

		StringBuffer url = new StringBuffer(baseUrl);
		url.append(userServicePort);
		url.append(getUsernameUrl);
		url.append("?access_token=" + token);
		logger.info("get username is  url------->" + url);
		HttpMethod method = HttpMethod.GET;
		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();

		ResponseEntity<String> responseEntity;
		try {
			responseEntity = restTemplateUtil.restTemplateConfigure(headers, url.toString(), method, body);
			if (responseEntity.getStatusCode().is2xxSuccessful()) {
				logger.info("Response entity for username------>" + responseEntity);
				return responseEntity.getBody().toString();
			}
		} catch (InternalServerError | NullPointerException | InvalidCredentialsException e) {
			e.printStackTrace();
		}

		return "";
	}

	@Override
	public ModelAndView getAllRestaurants() {

		headers.set("Content-Type", "application/json");

		StringBuffer url = new StringBuffer(baseUrl);
		url.append(searchServicePort);
		url.append(getAllRestaurantsUrl);
		logger.info("get username is  url------->" + url);

		HttpMethod method = HttpMethod.GET;

		ModelAndView model = new ModelAndView();

		Map<String, String> body = new HashMap<String, String>();

		ResponseEntity<RestaurantListResponse> responseEntity = null;
		try {
			responseEntity = restTemplateUtilSearch.restTemplateConfigure(headers, url.toString(), method, body);
			List<Restaurant> restaurantList = responseEntity.getBody().getRestaurantList();
			logger.info("Response entity for all restaurant ------>" + responseEntity);

			if (responseEntity.getStatusCode().is2xxSuccessful()) {
				model.setViewName("/home");
				model.addObject("restaurantData", restaurantList);
				return model;
			}
		} catch (NullPointerException | InvalidCredentialsException | InternalServerError e) {
			e.printStackTrace();
			model.setViewName("/login");
			model.addObject("badMessage", "Login Failed..try again");
		} catch (Exception e) {
			model.setViewName("/login");
			model.addObject("badMessage", "Something went wrong..Try again");
			return model;
		}

		return model;
	}

	@Override
	public ModelAndView searchByResturantName(String searchValue) {

		ModelAndView model = new ModelAndView();
		model.setViewName("/home");

		if (searchValue.isEmpty()) {
			return model;

		} else {

			headers.set("Content-Type", "application/json");

			StringBuffer url = new StringBuffer(baseUrl);
			url.append(searchServicePort);
			url.append(getByRestaurantNameUrl);
			url.append(searchValue);

			logger.info("SearchByRestaurantName is  url------->" + url);

			Map<String, String> body = new HashMap<String, String>();

			HttpMethod method = HttpMethod.GET;

			ResponseEntity<RestaurantListResponse> responseEntity;

			try {
				responseEntity = restTemplateUtilSearch.restTemplateConfigure(headers, url.toString(), method, body);
				List<Restaurant> restaurantList = responseEntity.getBody().getRestaurantList();
				logger.info("Response entity for SearchByRestaurantName ------>" + responseEntity);

				if (!(searchValue.equals("") || searchValue.equals(null))) {
					model.setViewName("/home");
					model.addObject("restaurantData", restaurantList);
					return model;
				}
			} catch (NullPointerException | InvalidCredentialsException | InternalServerError e) {
				e.printStackTrace();
				model.setViewName("/home");
				return model;
			} catch (Exception e) {
				model.setViewName("/home");
				return model;
			}
		}

		return model;
	}

	@Override
	public ModelAndView searchByRestaurantItem(String searchValue) {

		ModelAndView model = new ModelAndView();
		model.setViewName("/home");

		if (searchValue.isEmpty()) {
			return model;
		} else {
			headers.set("Content-Type", "application/json");

			StringBuffer url = new StringBuffer(baseUrl);
			url.append(searchServicePort);
			url.append(getByRestaurantItemUrl);
			url.append(searchValue);
			logger.info("SearchRestaurantByItemName  is  url------->" + url);

			Map<String, String> body = new HashMap<String, String>();

			HttpMethod method = HttpMethod.GET;

			ResponseEntity<RestaurantListResponse> responseEntity;
			try {
				responseEntity = restTemplateUtilSearch.restTemplateConfigure(headers, url.toString(), method, body);
				List<Restaurant> restaurantList = responseEntity.getBody().getRestaurantList();
				logger.info("Response entity for SearchRestaurantByItemName ------>" + responseEntity);

				if (responseEntity.getStatusCode().is2xxSuccessful()) {
					model.setViewName("/home");
					model.addObject("restaurantData", restaurantList);
					return model;
				}
			} catch (NullPointerException | InvalidCredentialsException | InternalServerError e) {
				e.printStackTrace();
				model.setViewName("/home");
				return model;
			} catch (Exception e) {
				model.setViewName("/home");
				return model;
			}
		}

		return model;

	}

	@Override
	public ModelAndView searchByRestaurantLocation(String searchValue) {

		ModelAndView model = new ModelAndView();
		model.setViewName("/home");
		if (searchValue.isEmpty()) {
			return model;
		} else {
			headers.set("Content-Type", "application/json");

			StringBuffer url = new StringBuffer(baseUrl);
			url.append(searchServicePort);
			url.append(getByRestaurantLocationUrl);
			url.append(searchValue);
			logger.info("SearchRestaurantByLocation is  url------->" + url);

			Map<String, String> body = new HashMap<String, String>();

			HttpMethod method = HttpMethod.GET;

			ResponseEntity<RestaurantListResponse> responseEntity;
			try {
				responseEntity = restTemplateUtilSearch.restTemplateConfigure(headers, url.toString(), method, body);
				List<Restaurant> restaurantList = responseEntity.getBody().getRestaurantList();
				logger.info("Response entity for SearchRestaurantByLocation ------>" + responseEntity);
				if (responseEntity.getStatusCode().is2xxSuccessful()) {
					model.setViewName("/home");
					model.addObject("restaurantData", restaurantList);
					return model;
				}
			} catch (NullPointerException | InvalidCredentialsException | InternalServerError e) {
				e.printStackTrace();
				model.setViewName("/home");
				return model;
			}

			catch (Exception e) {
				model.setViewName("/home");
				return model;
			}

		}

		return model;

	}

	@Override
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView model = new ModelAndView();
		session = request.getSession();
		session.invalidate();
		model.setViewName("/login");
		model.addObject("logout", "Logout successfully");
		return model;

	}

}
