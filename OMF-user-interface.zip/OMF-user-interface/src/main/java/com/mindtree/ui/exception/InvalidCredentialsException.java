package com.mindtree.ui.exception;

@SuppressWarnings("serial")
public class InvalidCredentialsException extends Exception {

	public InvalidCredentialsException(String string) {
		super(string);
	}

}
