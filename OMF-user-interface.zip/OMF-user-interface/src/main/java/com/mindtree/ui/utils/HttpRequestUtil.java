/*package com.mindtree.ui.utils;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Service
public class HttpRequestUtil {
	
	
	public MultiValueMap<String, String> httpRequestBodySetter(String...name)
	{
		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
		for (String string : name) {
			
			body.add("username", username);
			body.add("password", password);
			body.add("scope", "read");
			body.add("client_id", "authorizationClient");
			body.add("grant_type", "password");
			
		}
		
		return body;
	}

}
*/