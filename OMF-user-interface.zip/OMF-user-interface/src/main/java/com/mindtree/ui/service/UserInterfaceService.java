package com.mindtree.ui.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;

import com.mindtree.ui.model.User;

public interface UserInterfaceService {

	public ModelAndView registerUser(User user);

	public ModelAndView personalLoginUser(String username, String password);

	public ModelAndView socialLoginUser(String token);

	public ModelAndView deactivateUser(String token);

	public ModelAndView userProfile(String token);

	public ModelAndView updateProfile(String token, User user);

	public ModelAndView getAllRestaurants();

	public ModelAndView searchByResturantName(String searchValue);

	public ModelAndView searchByRestaurantItem(String searchValue);

	public ModelAndView searchByRestaurantLocation(String searchValue);

	public ModelAndView logout( HttpServletRequest request,HttpSession session);

}
