package com.mindtree.ui.response.entity;

import java.util.List;

import com.mindtree.ui.model.Items;

public class ItemListResponse extends Response {

	private List<Items> itemList;

	public List<Items> getItemList() {
		return itemList;
	}

	public void setItemList(List<Items> itemList) {
		this.itemList = itemList;
	}

}
