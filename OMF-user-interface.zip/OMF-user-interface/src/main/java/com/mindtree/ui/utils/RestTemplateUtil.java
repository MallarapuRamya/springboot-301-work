package com.mindtree.ui.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.mindtree.ui.exception.InvalidCredentialsException;

@Service
@PropertySource("classpath:application.properties")
public class RestTemplateUtil {

	private RestTemplate restTemplate = new RestTemplate();

	private final Log logger = LogFactory.getLog(this.getClass());


	public ResponseEntity<String> restTemplateConfigure(HttpHeaders headers, String url, HttpMethod method,
			MultiValueMap<String, String> body)  {
		logger.info("url parsing is--------->" + url);
		HttpEntity<?> httpEntity = new HttpEntity<Object>(body, headers);
		logger.info("HttpEntity---------->"+httpEntity);
		ResponseEntity<String> exchange = restTemplate.exchange(url, method, httpEntity, String.class);
		logger.info("Exchange ----------->" + exchange);
		return exchange;
	}

}
