package com.mindtree.ui.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.ui.model.User;
import com.mindtree.ui.service.impl.UserInterfaceServiceImpl;

@RestController
@CrossOrigin
@SessionScope
public class UserInterfaceController {

	private final Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private UserInterfaceServiceImpl userInterfaceServiceImpl;

	@RequestMapping("/index")
	public ModelAndView indexPage(@ModelAttribute("userInfo") User user) {
		ModelAndView registerUser = userInterfaceServiceImpl.registerUser(user);
		return registerUser;
	}

	@RequestMapping("/login")
	public ModelAndView loginViewPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("/login");
		return model;
	}

	@RequestMapping(value = { "/getLogin", "/home" })
	public ModelAndView getLoginView() {
		ModelAndView model = new ModelAndView();
		model.setViewName("/login");
		return model;
	}

	@RequestMapping(value = "/home", method = RequestMethod.POST)
	public ModelAndView personalLoginView(@ModelAttribute("userInfo") User user, HttpSession session) {
		ModelAndView personalLoginUser = userInterfaceServiceImpl.personalLoginUser(user.getUserName(),
				user.getPassword());
		if (personalLoginUser.getModel().get("oauth_token") != null) {
			String token = personalLoginUser.getModel().get("oauth_token").toString();
			session.setAttribute("token", token);
			return personalLoginUser;
		} else {
			personalLoginUser.setViewName("/login");
		}
		return personalLoginUser;

	}

	@RequestMapping(value = "/home/{auth}")
	public ModelAndView homePage(@PathVariable(value = "auth") String tokenValue, HttpSession session) {
		logger.info("Generating token is ---------->" + tokenValue);
		session.setAttribute("token", tokenValue);
		ModelAndView socialLoginUser = userInterfaceServiceImpl
				.socialLoginUser(session.getAttribute("token").toString());
		return socialLoginUser;
	}

	@RequestMapping("/deactiveAccount")
	public ModelAndView deactiveUser(HttpSession session) {
		ModelAndView deactivateUser = userInterfaceServiceImpl.deactivateUser(session.getAttribute("token").toString());
		return deactivateUser;
	}

	@RequestMapping("/profile")
	public ModelAndView userProfile(HttpSession session) {
		ModelAndView userProfile = userInterfaceServiceImpl.userProfile(session.getAttribute("token").toString());
		return userProfile;
	}

	@RequestMapping(value = "/profileUpdated", method = RequestMethod.POST)
	public ModelAndView profileUpdated(@ModelAttribute("updateUserDetails") User user, HttpSession session) {
		return userInterfaceServiceImpl.updateProfile(session.getAttribute("token").toString(), user);
	}

	@RequestMapping("/searchByRestaurant/{restaurantName}")
	public ModelAndView searchByRestaurant(@RequestParam("searchData") String restaurantName) {
		return userInterfaceServiceImpl.searchByResturantName(restaurantName);
	}

	@RequestMapping("/searchByItem")
	public ModelAndView searchByItem(String itemName) {
		return userInterfaceServiceImpl.searchByRestaurantItem(itemName);
	}

	@RequestMapping("/searchByLocation")
	public ModelAndView searchByLocation(String location) {
		return userInterfaceServiceImpl.searchByRestaurantLocation(location);
	}

	@RequestMapping("/result")
	public ModelAndView getView(@RequestParam("searchByCategory") String searchCategory,
			@RequestParam("searchData") String searchdata) {

		if (searchCategory.equals("Item")) {
			return userInterfaceServiceImpl.searchByRestaurantItem(searchdata);
		} else if (searchCategory.equals("Restaurant")) {
			return userInterfaceServiceImpl.searchByResturantName(searchdata);
		} else {
			return userInterfaceServiceImpl.searchByRestaurantLocation(searchdata);
		}
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		return userInterfaceServiceImpl.logout(request, session);
	}

	@RequestMapping("/underconstruction")
	public ModelAndView progressPage() {
		return new ModelAndView("/underconstruction");
	}
}
