package com.mindtree.ui.utils;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;
import org.springframework.web.client.RestTemplate;

import com.mindtree.ui.exception.InvalidCredentialsException;
import com.mindtree.ui.response.entity.RestaurantListResponse;

@Service
@PropertySource("classpath:application.properties")
public class RestTemplateUtilSearch {

	private RestTemplate restTemplate = new RestTemplate();

	private final Log logger = LogFactory.getLog(this.getClass());

	ResponseEntity<RestaurantListResponse> exchange;

	public ResponseEntity<RestaurantListResponse> restTemplateConfigure(HttpHeaders headers, String url,
			HttpMethod method, Map<String, String> body)
			throws InvalidCredentialsException, NullPointerException, InternalServerError {
		
		logger.info("restTemplateConfigure Url is------>" + url);
		HttpEntity<?> httpEntity = new HttpEntity<Object>(body, headers);
		logger.info("HttpEntity for url ----->" + httpEntity);
		try {
			exchange = restTemplate.exchange(url, method, httpEntity, RestaurantListResponse.class);
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
			throw new InvalidCredentialsException("Please provide valid credentials!!");

		}

		logger.info("Response entity from rest template------>" + exchange.getBody());
		return exchange;
	}
}
