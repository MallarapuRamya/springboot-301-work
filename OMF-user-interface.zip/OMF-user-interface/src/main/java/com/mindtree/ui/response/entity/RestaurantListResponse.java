package com.mindtree.ui.response.entity;

import java.util.List;

import com.mindtree.ui.model.Restaurant;


public class RestaurantListResponse extends Response {

	
	private List<Restaurant> restaurantList;

	public List<Restaurant> getRestaurantList() {
		return restaurantList;
	}

	public void setRestaurantList(List<Restaurant> restaurantList) {
		this.restaurantList = restaurantList;
	}
}
